# import pybullet as p
import importlib
import numpy as np
import time

import rospy
from std_msgs.msg import Header
from sensor_msgs.msg import JointState
from exo_msgs.msg import JointData
from exo_msgs.msg import FootRangeSensors, ForceTorqueSensor, ForceTorqueSensors

p = None
humanoid = None
jointIds = []
jointNames = []
paramIds = []

def command_callback(in_msg):
    global jointIds, paramIds, humanoid, p
    for i in range(len(jointIds)):
        p.setJointMotorControl2(humanoid, jointIds[i], p.POSITION_CONTROL, in_msg.positions[i], force= 5*240)

def get_foot_range_sensors():
    global jointIds, paramIds, humanoid, p

    left_contacts = p.getContactPoints(linkIndexB=jointIds[5])
    right_contacts = p.getContactPoints(linkIndexB=jointIds[11])

    foot_range_sensors = FootRangeSensors()
    for i in range(4):
        foot_range_sensors.left[i] = 0
        foot_range_sensors.right[i] = 0
        if (i < len(left_contacts)):
            foot_range_sensors.left[i] = int(left_contacts[i][9]) # normal force
        if (i < len(right_contacts)):
            foot_range_sensors.right[i] = int(right_contacts[i][9]) # normal force
    return foot_range_sensors

def get_joint_states():
    global jointIds, jointNames, paramIds, humanoid, p
    states = p.getJointStates(humanoid, jointIds[:])
    joint_states = JointState()
    for idx, joint_state in enumerate(states):
        joint_states.name.append(jointNames[idx])
        joint_states.position.append(joint_state[0])
        joint_states.velocity.append(joint_state[1])
        joint_states.effort.append(joint_state[3])
    return joint_states

def simulator_loop():
    global jointIds, paramIds, humanoid, p

    rospy.init_node('pybullet_interface_node')
    print(rospy.get_param_names())
    if rospy.has_param('/pybullet_interface/robot_path') == False:
        rospy.loginfo('robot_path is not provided.')
        return
    if ~rospy.has_param('/pybullet_interface/data_path') == False:
        rospy.loginfo('data_path is not provided.')
        return

    robot_path = rospy.get_param('/pybullet_interface/robot_path')
    data_path = rospy.get_param('/pybullet_interface/data_path')
    print (data_path)

    p = importlib.import_module('pybullet')
    p.connect(p.GUI)
    p.setPhysicsEngineParameter(allowedCcdPenetration=0.0)
    p.loadURDF(data_path+"/plane.urdf")
    obUids = p.loadURDF(robot_path,[0,0,1])
    humanoid = obUids

    gravId = p.addUserDebugParameter("gravity", -9.81, 10, -10)

    p.setPhysicsEngineParameter(numSolverIterations=10)
    for j in range(p.getNumJoints(humanoid)):
        p.changeDynamics(humanoid, j, linearDamping=0, angularDamping=0)
        info = p.getJointInfo(humanoid, j)
        jointName = info[1]
        jointType = info[2]
        if (jointType == p.JOINT_PRISMATIC or jointType == p.JOINT_REVOLUTE):
            jointIds.append(j)
            jointNames.append(jointName)
            paramIds.append(p.addUserDebugParameter(jointName.decode("utf-8"), -4, 4, 0))
            p.setJointMotorControl2(humanoid, j, p.POSITION_CONTROL, 0., force=5*240)

    p.setRealTimeSimulation(1)

    rospy.Subscriber("/joints/command", JointData, command_callback)
    foot_range_sensors_publisher_ = rospy.Publisher('/robot/sensors/foot/range', FootRangeSensors, queue_size=1)
    force_torque_sensors_publisher = rospy.Publisher('/robot/sensors/foot/force', ForceTorqueSensors, queue_size=1)
    joint_state_publisher_ = rospy.Publisher('/robot/joints', JointState, queue_size=1)

    rate = rospy.Rate(100)
    header = Header()
    while not rospy.is_shutdown():
        p.setGravity(0, 0, p.readUserDebugParameter(gravId))
        # pub.publish(hello_str)
        foot_range_sensors = get_foot_range_sensors()
        joint_states = get_joint_states()
        header.stamp = rospy.Time.now()
        foot_range_sensors.header = header
        joint_states.header = header
        foot_range_sensors_publisher_.publish(foot_range_sensors)
        joint_state_publisher_.publish(joint_states)
        rate.sleep()
