# import pybullet as p
import importlib
import numpy as np
import time

import rospy
from exo_msgs.msg import JointData
from exo_msgs.msg import FootRangeSensors, ForceTorqueSensor, ForceTorqueSensors

p = None
humanoid = None
jointIds = []
paramIds = []

def command_callback(in_msg):
    global jointIds, paramIds, humanoid, p
    for i in range(len(jointIds)):
        p.setJointMotorControl2(humanoid, jointIds[i], p.POSITION_CONTROL, in_msg.positions[i], force=5 * 240.)

def get_foot_range_sensors():
    global jointIds, paramIds, humanoid, p

    left_contacts = p.getContactPoints(linkIndexB=jointIds[5])
    right_contacts = p.getContactPoints(linkIndexB=jointIds[11])

    foot_range_sensors = FootRangeSensors()
    for i in range(4):
        foot_range_sensors.left[i] = 0
        foot_range_sensors.right[i] = 0
        if (i < len(left_contacts)):
            foot_range_sensors.left[i] = int(left_contacts[i][9]) # normal force
        if (i < len(right_contacts)):
            foot_range_sensors.right[i] = int(right_contacts[i][9]) # normal force
    return foot_range_sensors

def simulator_loop():
    global jointIds, paramIds, humanoid, p

    p = importlib.import_module('pybullet')
    p.connect(p.GUI)
    p.loadURDF("/home/faraz/workspace/humaninmotion_ws/thirdparties/bullet3/data/plane.urdf")
    obUids = p.loadURDF("/home/faraz/workspace/humaninmotion_ws/src/exo_models/simple_biped/urdf/simple_biped.urdf",[0,0,1])
    humanoid = obUids

    gravId = p.addUserDebugParameter("gravity", -10, 10, -10)

    p.setPhysicsEngineParameter(numSolverIterations=10)
    for j in range(p.getNumJoints(humanoid)):
        p.changeDynamics(humanoid, j, linearDamping=0, angularDamping=0)
        info = p.getJointInfo(humanoid, j)
        jointName = info[1]
        jointType = info[2]
        if (jointType == p.JOINT_PRISMATIC or jointType == p.JOINT_REVOLUTE):
            jointIds.append(j)
            paramIds.append(p.addUserDebugParameter(jointName.decode("utf-8"), -4, 4, 0))

    p.setRealTimeSimulation(1)

    rospy.init_node('pybullet_interface_node')
    rospy.Subscriber("/joints/command", JointData, command_callback)
    foot_range_sensors_publisher_ = rospy.Publisher('/robot/sensors/foot/range', FootRangeSensors, queue_size=1)
    force_torque_sensors_publisher = rospy.Publisher('/robot/sensors/foot/force', ForceTorqueSensors, queue_size=1)

    rate = rospy.Rate(100)
    while not rospy.is_shutdown():
        p.setGravity(0, 0, p.readUserDebugParameter(gravId))
        # pub.publish(hello_str)
        foot_range_sensors = get_foot_range_sensors()
        foot_range_sensors_publisher_.publish(foot_range_sensors)
        rate.sleep()
