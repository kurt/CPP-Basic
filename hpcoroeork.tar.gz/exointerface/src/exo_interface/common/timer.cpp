// C++ Headers
#include <time.h>
#include <errno.h>
#include <sys/timerfd.h>
#include <stdint.h>
#include <cstring>
#include <cstdio>
#include <unistd.h>

// Specific Headers
#include <exo_interface/common/timer.h>

const double SECONDTONANO = 1000000000;

namespace exo_interface {

Timer::Timer(double rate) {
    timer_fd_ = timerfd_create(CLOCK_MONOTONIC, 0);

    itimerspec timespc;
    memset(&timespc, 0, sizeof(timespc));

    timespc.it_interval.tv_sec = 0;
    timespc.it_interval.tv_nsec = (long)(rate * SECONDTONANO);
    timespc.it_value.tv_sec = 0;
    timespc.it_value.tv_nsec = 1;

    if(timerfd_settime(timer_fd_, 0, &timespc, 0) != 0) {
        perror("timerfd_settime");
        abort();
    }
}

Timer::~Timer() {
    close(timer_fd_);
}

long unsigned int Timer::sleep() {
    int result;
    uint64_t expirations;

    do {
        result = read(timer_fd_, &expirations, sizeof(expirations));
    } while (result == EINTR);

    if (result < 0) {
        perror("read");
        return -1;
    }

    return expirations;
}

}
