#include <exo_interface/common/data_conversion.h>
#include <exo_interface/robot/packet.h>
#include <iostream>

namespace exo_interface {
	void mat3b3_vec3(double res[3], double mat[3][3], double vec[3])
	{

		for(int row = 0; row<3; row++)
		{
			res[row] = 0;
			
			for(int i = 0; i < 3; i++)
			{

				res[row] = res[row] + mat[row][i]*vec[i];

			}

		}

	}

	void mat3b3_mat3b3(double res[3][3], double mat1[3][3], double mat2[3][3])
	{

		for(int i = 0; i<3; i++)
		{
			
			for(int j = 0; j < 3; j++)
			{
				res[i][j] = 0;
				for(int k = 0; k < 3; k++)
				{

					res[i][j] = res[i][j] + mat1[i][k]*mat2[k][j];

				}

			}

		}

	}

	void transpose_mat3b3(double res[3][3], double mat[3][3])
	{

		for(int i = 0; i<3; i++)
		{
			
			for(int j = 0; j < 3; j++)
			{

				res[j][i] = mat[i][j];

			}

		}

	}

	void arbitrary_axis_rot(double  R[3][3], double th, double kx, double ky, double kz)
	{

		double sth = sin(th);
		double cth = cos(th);

		R[0][0] = kx*kx + (1 - kx*kx)*cth;
		R[0][1] = kx*ky - kx*ky*cth - kz*sth;
		R[0][2] = kx*kz - kx*kz*cth + ky*sth;

		R[1][0] = kx*ky - kx*ky*cth + kz*sth;
		R[1][1] = ky*ky + (1 - ky*ky)*cth;
		R[1][2] = ky*kz - ky*kz*cth - kx*sth;

		R[2][0] = kx*kz - kx*kz*cth - ky*sth;
		R[2][1] = ky*kz - ky*kz*cth + kx*sth;
		R[2][2] = kz*kz + (1 - kz*kz)*cth;

	}


	void Hybrid_FK_mat(double R0_3[3][3], double angles[3], double Pmtoc1wM[3], double P0toMw0[3], double P0toc2w2[3], double Lb, double v1w0[3], double v2w1[3], double v3w2[3], double vMw0[3])
	{
		double R0_1[3][3];
		arbitrary_axis_rot(R0_1,angles[0],v1w0[0],v1w0[1],v1w0[2]);

		double R0_M[3][3];
		arbitrary_axis_rot(R0_M,angles[1],vMw0[0],vMw0[1],vMw0[2]);

		double th1bA = atan2(v2w1[0], v2w1[2]);
		double th1bB = atan2(v2w1[1], sqrt(v2w1[0]*v2w1[0] + v2w1[2]*v2w1[2]));

		double c1A = cos(th1bA);
		double s1A = sin(th1bA);

		double R1_1bA[3][3];
		R1_1bA[0][0] = c1A;
		R1_1bA[0][1] = 0;
		R1_1bA[0][2] = s1A;
		R1_1bA[1][0] = 0;
		R1_1bA[1][1] = 1;
		R1_1bA[1][2] = 0;
		R1_1bA[2][0] = -s1A;
		R1_1bA[2][1] = 0;
		R1_1bA[2][2] = c1A;

		double c1B = cos(th1bB);
		double s1B = sin(th1bB);
		
		double R1_1bB[3][3];
		R1_1bB[0][0] = 1;
		R1_1bB[0][1] = 0;
		R1_1bB[0][2] = 0;
		R1_1bB[1][0] = 0;
		R1_1bB[1][1] = c1B;
		R1_1bB[1][2] = -s1B;
		R1_1bB[2][0] = 0;
		R1_1bB[2][1] = s1B;
		R1_1bB[2][2] = c1B;

		double R1_1b[3][3];
		mat3b3_mat3b3(R1_1b, R1_1bA, R1_1bB);

		double R0_1b[3][3];
		mat3b3_mat3b3(R0_1b, R0_1, R1_1b);

		double Pmtoc1w0[3];
		mat3b3_vec3(Pmtoc1w0, R0_M, Pmtoc1wM);

		double P0toc1w0[3];
		P0toc1w0[0] = P0toMw0[0] + Pmtoc1w0[0];
		P0toc1w0[1] = P0toMw0[1] + Pmtoc1w0[1];
		P0toc1w0[2] = P0toMw0[2] + Pmtoc1w0[2];	

		double P0toc1w1b[3];
		double R0_1bT[3][3];
		transpose_mat3b3(R0_1bT, R0_1b);
		mat3b3_vec3(P0toc1w1b, R0_1bT, P0toc1w0);

		double P0toc2w2b[3];
		double R1_1bT[3][3];

		transpose_mat3b3(R1_1bT, R1_1b);

		mat3b3_vec3(P0toc2w2b, R1_1bT, P0toc2w2);

		double E = -2*P0toc1w1b[0]*P0toc2w2b[0] - 2*P0toc1w1b[1]*P0toc2w2b[1];
		double F = -2*P0toc1w1b[0]*P0toc2w2b[1] - 2*P0toc1w1b[1]*P0toc2w2b[0];
		double G = P0toc1w1b[0]*P0toc1w1b[0] + P0toc1w1b[1]*P0toc1w1b[1] + (P0toc2w2b[2] - P0toc1w1b[2])*(P0toc2w2b[2] - P0toc1w1b[2]) + P0toc2w2b[0]*P0toc2w2b[0] + P0toc2w2b[1]*P0toc2w2b[1] - Lb*Lb;

		//printf("M: %f\n", -E/F);
		//printf("N: %f\n", -G/F);	

		double A2 = (-E/F)*(-E/F) + 1;
		double B2 = 2*(-E/F)*(-G/F);
		double C2 = (-G/F)*(-G/F) - 1;

		double cp2 = (-B2 + sqrt(B2*B2 - 4*A2*C2))/(2*A2);
		double sp2 = (-E/F)*cp2 + (-G/F);

		double thp2 = atan2(sp2, cp2);

		double R1b_2b[3][3];
		R1b_2b[0][0] = cp2;
		R1b_2b[0][1] = -sp2;
		R1b_2b[0][2] = 0;
		R1b_2b[1][0] = sp2;
		R1b_2b[1][1] = cp2;
		R1b_2b[1][2] = 0;
		R1b_2b[2][0] = 0;
		R1b_2b[2][1] = 0;
		R1b_2b[2][2] = 1;

		double R0_2b[3][3];
		mat3b3_mat3b3(R0_2b, R0_1b, R1b_2b);

		double R0_2[3][3];

		mat3b3_mat3b3(R0_2, R0_2b, R1_1bT);

		double R2_3[3][3];
		arbitrary_axis_rot(R2_3,angles[2],v3w2[0],v3w2[1],v3w2[2]);

		mat3b3_mat3b3(R0_3, R0_2, R2_3);


	}

	void Simplified_IK(double angles[3], double R0_3[3][3])
	{

		double s2 = R0_3[1][0];
		double c2 = sqrt(1 - s2*s2);

		double s1 = -R0_3[2][0]/c2;
		double c1 = R0_3[0][0]/c2;

		double s3 = -R0_3[1][2]/c2;
		double c3 = R0_3[1][1]/c2;

		angles[0] = atan2(s1, c1);
		angles[1] = atan2(s2, c2);
		angles[2] = atan2(s3, c3);

	}



	void Hip_mech(double inp[9],double outp[4],int dir)
	{
		double L1,L2,L3,L4;
		double const1,const2,const3,const4;
		double a,b,c;
		double d[4];
		double sai,phi;
		double k1;
		double o1,o2,o3,o4;
		double ac,as,cq,sq;
		double a_m[6];
		double mid[4];
		double mid_inv[4];
		double p_inv[6];
		double b_m[3];
		double det;
		int sg;

		memset(&outp[0],0xFF,4*sizeof(double));

		double lh1 = 100.0/1000.0;
		double lh2 = 174.13/1000.0;
		double lh3 = 307.9/1000.0;
		double lh4 = 307.99/1000.0;
		double uy = cos(50.0/180.0*3.14159265359);
		double uz = sin(50.0/180.0*3.14159265359);
		
		//printf("%f %f\n", uy, uz);

		L1=lh1;
		L2=lh2;
		L3=lh3;
		L4=lh4;

		if (dir==1)
		{
		    L1=-L1;
		}
		// index 2
		const1=1.704088191041846;//1/(1-uy^2);
		const2= -1.704088191041846;//-1/(1-uy^2);
		const3=2.030853223771491;//1/(uy*uz);
		const4=-1.305407289332279;//(-1/uz);

		a = (inp[4]*const1)+(inp[7]*const3);
		b = (inp[5]*const2)-(inp[8]*const3);
		c = -const2;;//%1/(1-uy^2);

		sai = atan2(b,a);
		k1=(a*a)+(b*b)-(c*c);
		if(k1<0)
		{
	        printf("Invalid state for hip ik!!! it should not happen\n");
	        exit(0);
		}

	    phi = atan2(sqrt(k1),c);
	    o3 = sai + phi;

		// index 1
		ac=cos(o3);
		as=sin(o3);

		a = const4*((inp[1]*ac)-(inp[2]*as));
		b = (-const3)*(inp[7]*ac-inp[8]*as)+1;
		o2 = atan2(a,b);


		// index3
		ac=cos(o2);
		as=sin(o2);

		a_m[0]=ac;
		a_m[1]=-uy*as;
		a_m[2]=uz*as;
		a_m[3]=uy*uz*(ac - 1);
		a_m[4]=-uy*as;
		a_m[5]=-(((1 - ac)*uz*uz) + ac);

		b_m[0]= inp[0];
		b_m[1]= inp[3];
		b_m[2]= inp[6];

		//calculate a_m'*a_m
		mid[0]=(a_m[0]*a_m[0])+(a_m[2]*a_m[2])+(a_m[4]*a_m[4]);
		mid[1]=(a_m[0]*a_m[1])+(a_m[2]*a_m[3])+(a_m[4]*a_m[5]);
		mid[2]=mid[1];
		mid[3]=(a_m[1]*a_m[1])+(a_m[3]*a_m[3])+(a_m[5]*a_m[5]);

		//finding inverse matrix
		det=(mid[0]*mid[3])-(mid[1]*mid[2]);
		mid_inv[0]=mid[3]/det;
		mid_inv[1]=-mid[1]/det;
		mid_inv[2]=-mid[2]/det;
		mid_inv[3]=mid[0]/det;

		//calculating pesudo inverse matrix
		//pa=mid_inv*A';
		p_inv[0]=(mid_inv[0]*a_m[0])+(mid_inv[1]*a_m[1]);
		p_inv[1]=(mid_inv[0]*a_m[2])+(mid_inv[1]*a_m[3]);
		p_inv[2]=(mid_inv[0]*a_m[4])+(mid_inv[1]*a_m[5]);
		p_inv[3]=(mid_inv[2]*a_m[0])+(mid_inv[3]*a_m[1]);
		p_inv[4]=(mid_inv[2]*a_m[2])+(mid_inv[3]*a_m[3]);
		p_inv[5]=(mid_inv[2]*a_m[4])+(mid_inv[3]*a_m[5]);


		//x = pa*b;
		a=(p_inv[0]*b_m[0])+(p_inv[1]*b_m[1])+(p_inv[2]*b_m[2]);
		b=(p_inv[3]*b_m[0])+(p_inv[4]*b_m[1])+(p_inv[5]*b_m[2]);

		o4 = atan2(b,a);

		// index 0
		ac=cos(o4);
		as=sin(o4);

		cq=cos(o2);
		sq=sin(o2);
		d[0]=(ac*L1*cq)-(uz*sq*L2)-(as*L1*uy*sq);
		d[1]=(uz*sq*ac*L1)+(L2*(cq+uy*uy*(1-cq)))-(uy*uz*(1-cq)*as*L1);
		d[2]=-(uy*sq*ac*L1)+(uy*uz*(1-cq)*L2)-((cq+uz*uz*(1-cq))*as*L1);
		d[3]=1;

		// finding sign (-L1)
		if(L1>0)
			sg=-1;
		else if (L1<0)
			sg=1;
		else
			sg=0;
		a = sg*2*L1*d[0];
		b = sg*2*L1*(L3-d[2]);
		c = sg*((L1*L1) + (L2*L2) + (L3*L3) - (L4*L4) - (2*L2*d[1]) - (2*L3*d[2]) + (d[0]*d[0]) + (d[1]*d[1]) + (d[2]*d[2]));

		sai = atan2(b,a);
		k1 = (a*a)+(b*b)-(c*c);

		if (k1<0)
		{
	        printf("Invalid state for hip ik!!! It should not happen \n");
	        exit(0);
		}

		phi = atan2(sqrt(k1),c);
		o1 = sai + phi;
		outp[0]=o1;
		outp[1]=o2;
		outp[2]=o3;
		outp[3]=o4;

	}

	void Hip_Joints_IK(double R[3][3],double outp[4],int side)
	{
		double mech_input[9];
		
		mech_input[0]=R[0][0];
		mech_input[1]=R[0][1];
		mech_input[2]=R[0][2];
		mech_input[3]=R[1][0];
		mech_input[4]=R[1][1];
		mech_input[5]=R[1][2];
		mech_input[6]=R[2][0];
		mech_input[7]=R[2][1];
		mech_input[8]=R[2][2];
		
		Hip_mech(mech_input,outp,side);

	}

	void fast_inv(double inp[16],double outp[16])
	{
		// this function calculate inverse of 4*4 matrix if the last row is [0 0 0 1]
		double a,b,c,d,e,f,g,h,i,j,k,l;
		double mydet,det_p1,det_p2,det_p3;

		a=inp[0];
		b=inp[1];
		c=inp[2];
		d=inp[3];

		e=inp[4];
		f=inp[5];
		g=inp[6];
		h=inp[7];

		i=inp[8];
		j=inp[9];
		k=inp[10];
		l=inp[11];

		det_p1=a*(f*k-j*g);
		det_p2=b*(e*k-i*g);
		det_p3=c*(e*j-i*f);
		mydet=1/(det_p1-det_p2+det_p3);


		outp[0]=((f*k)-(g*j))*mydet;  	//index 0
		outp[4]=(-(e*k)+(g*i))*mydet; 	//index 4
		outp[8]=((e*j)-(i*f))*mydet;  	//index 8
		outp[12]=0;		            	//index 12

		outp[1]=(-(b*k)+(c*j))*mydet;   //index 1
		outp[5]=((a*k)-(c*i))*mydet;    //index 5
		outp[9]=(-(a*j)+(b*i))*mydet;   //index 9
		outp[13]=0;     		        //index 13

		outp[2]=((b*g)-(f*c))*mydet;    //index 2
		outp[6]=(-(a*g)+(c*e))*mydet;   //index 6
		outp[10]=((a*f)-(b*e))*mydet;   //index 10
		outp[14]=0;              		//index 14

		outp[3]=(-(b*((g*l)-(k*h)))+(c*((f*l)-(h*j)))-(d*((f*k)-(g*j))))*mydet;  //index3
		outp[7]=((a*((g*l)-(k*h)))-(c*((e*l)-(i*h)))+(d*((e*k)-(g*i))))*mydet;   //index7
		outp[11]=(-(a*((f*l)-(h*j)))+(b*((e*l)-(h*i)))-(d*((e*j)-(f*i))))*mydet;  //index11
		outp[15]=((a*((f*k)-(g*j)))-(b*((e*k)-(g*i)))+(c*((e*j)-(f*i))))*mydet;   //index15
	}

	void Simplified_FK(double R[3][3], double angles[3])
	{
		double sx = sin(angles[2]);
		double cx = cos(angles[2]);

		double Rx[3][3];
		Rx[0][0] = 1;
		Rx[0][1] = 0;
		Rx[0][2] = 0;
		Rx[1][0] = 0; 
		Rx[1][1] = cx;
		Rx[1][2] = -sx;
		Rx[2][0] = 0;
		Rx[2][1] = sx;
		Rx[2][2] = cx;

		double sy = sin(angles[1]);
		double cy = cos(angles[1]);

		double Ry[3][3];
		Ry[0][0] = cy;
		Ry[0][1] = 0;
		Ry[0][2] = sy;
		Ry[1][0] = 0; 
		Ry[1][1] = 1;
		Ry[1][2] = 0;
		Ry[2][0] = -sy;
		Ry[2][1] = 0;
		Ry[2][2] = cy;

		double sz = sin(angles[0]);
		double cz = cos(angles[0]);

		double Rz[3][3];
		Rz[0][0] = cz;
		Rz[0][1] = -sz;
		Rz[0][2] = 0;
		Rz[1][0] = sz; 
		Rz[1][1] = cz;
		Rz[1][2] = 0;
		Rz[2][0] = 0;
		Rz[2][1] = 0;
		Rz[2][2] = 1;

		double RzRy[3][3];
		mat3b3_mat3b3(RzRy, Rz, Ry);

		mat3b3_mat3b3(R, RzRy, Rx);

	}

	void realToSimRight(double qOut[3], double Enc[3])
	{
		double pi_con = 3.14159265359;
		double R[3][3];
		double Pmtoc1wM[3];
		double P0toMw0[3];
		double P0toc2w2[3];
		double Lb;
		double v1w0[3];
		double v2w1[3];
		double v3w2[3];
		double vMw0[3];
		double angles[3];

		Pmtoc1wM[0] = -100.0;
		Pmtoc1wM[1] = 0.0;
		Pmtoc1wM[2] = 0.0;

		P0toMw0[0] = 0.0;
		P0toMw0[1] = 307.9;
		//P0toMw0[1] = 307.99;
		P0toMw0[2] = -174.13;
		//P0toMw0[2] = -174.13;

		P0toc2w2[0] = -100.0;
		P0toc2w2[1] = 0.0;
		//P0toc2w2[2] = -174.13;
		P0toc2w2[2] = -174.13;

		Lb = 307.99;
		//Lb = 307.9;

		v1w0[0] = 0;
		v1w0[1] = -sin(50.0/180.0*pi_con);
		v1w0[2] = cos(50.0/180.0*pi_con);
		
		v2w1[0] = 0;
		v2w1[1] = 0;
		v2w1[2] = 1;

		v3w2[0] = 1.0;
		v3w2[1] = 0.0;
		v3w2[2] = 0.0;

		vMw0[0] = 0.0;
		vMw0[1] = 0.0;
		vMw0[2] = 1.0;

		angles[0] = -Enc[1];
		angles[1] = -Enc[0];
		angles[2] = Enc[2];

		Hybrid_FK_mat(R, angles, Pmtoc1wM, P0toMw0, P0toc2w2, Lb, v1w0, v2w1, v3w2, vMw0);

		double angles_sim[3];

		Simplified_IK(angles_sim, R);

		qOut[0] = angles_sim[0];
		qOut[1] = angles_sim[1];
		qOut[2] = angles_sim[2];

	}


	void realToSimLeft(double qOut[3], double Enc[3])
	{
		double pi_con = 3.14159265359;
		double R[3][3];
		double Pmtoc1wM[3];
		double P0toMw0[3];
		double P0toc2w2[3];
		double Lb;
		double v1w0[3];
		double v2w1[3];
		double v3w2[3];
		double vMw0[3];
		double angles[3];

		Pmtoc1wM[0] = 100.0;
		Pmtoc1wM[1] = 0.0;
		Pmtoc1wM[2] = 0.0;

		P0toMw0[0] = 0.0;
		P0toMw0[1] = 307.9;
		//P0toMw0[1] = 307.99;
		P0toMw0[2] = -174.13;
		//P0toMw0[2] = -174.13;

		P0toc2w2[0] = 100.0;
		P0toc2w2[1] = 0.0;
		//P0toc2w2[2] = -174.13;
		P0toc2w2[2] = -174.13;

		Lb = 307.99;
		//Lb = 307.9;

		v1w0[0] = 0;
		v1w0[1] = -sin(50.0/180.0*pi_con);
		v1w0[2] = cos(50.0/180.0*pi_con);
		
		v2w1[0] = 0;
		v2w1[1] = 0;
		v2w1[2] = 1;

		v3w2[0] = 1.0;
		v3w2[1] = 0.0;
		v3w2[2] = 0.0;

		vMw0[0] = 0.0;
		vMw0[1] = 0.0;
		vMw0[2] = 1.0;

		angles[0] = -Enc[1];
		angles[1] = -Enc[0];
		angles[2] = Enc[2];

		Hybrid_FK_mat(R, angles, Pmtoc1wM, P0toMw0, P0toc2w2, Lb, v1w0, v2w1, v3w2, vMw0);

		double angles_sim[3];

		Simplified_IK(angles_sim, R);

		qOut[0] = angles_sim[0];
		qOut[1] = angles_sim[1];
		qOut[2] = angles_sim[2];

	}

	void simToRealRight(double qOut[3], double qIn[3])
	{
		
		double qInadj[3];
		qInadj[0] = qIn[0];
		qInadj[1] = -qIn[1];
		qInadj[2] = qIn[2];


		double Rout[3][3];
		Simplified_FK(Rout, qInadj);

		double outp[4];

		Hip_Joints_IK(Rout,outp,1);

		qOut[0] = outp[0];
		qOut[1] = outp[1];
		qOut[2] = outp[2];
	}

	void simToRealLeft(double qOut[3], double qIn[3])
	{
		
		double qInadj[3];
		qInadj[0] = qIn[0];
		qInadj[1] = -qIn[1];
		qInadj[2] = qIn[2];


		double Rout[3][3];
		Simplified_FK(Rout, qInadj);

		double outp[4];

		Hip_Joints_IK(Rout,outp,0);

		qOut[0] = outp[0];
		qOut[1] = outp[1];
		qOut[2] = outp[2];
	}

	void YPR_to_RPY(double rpy[3], double ypr[3])
	{
		//Using: X->Forward, Y->Left, Z-> Up
		/*
			double R[3][3];

			double sx = sin(ypr[2]);
			double cx = cos(ypr[2]);

			double Rx[3][3];
			Rx[0][0] = 1;
			Rx[0][1] = 0;
			Rx[0][2] = 0;
			Rx[1][0] = 0; 
			Rx[1][1] = cx;
			Rx[1][2] = -sx;
			Rx[2][0] = 0;
			Rx[2][1] = sx;
			Rx[2][2] = cx;

			double sy = sin(ypr[1]);
			double cy = cos(ypr[1]);

			double Ry[3][3];
			Ry[0][0] = cy;
			Ry[0][1] = 0;
			Ry[0][2] = sy;
			Ry[1][0] = 0; 
			Ry[1][1] = 1;
			Ry[1][2] = 0;
			Ry[2][0] = -sy;
			Ry[2][1] = 0;
			Ry[2][2] = cy;

			double sz = sin(ypr[0]);
			double cz = cos(ypr[0]);

			double Rz[3][3];
			Rz[0][0] = cz;
			Rz[0][1] = -sz;
			Rz[0][2] = 0;
			Rz[1][0] = sz; 
			Rz[1][1] = cz;
			Rz[1][2] = 0;
			Rz[2][0] = 0;
			Rz[2][1] = 0;
			Rz[2][2] = 1;

			double RzRy[3][3];
			mat3b3_mat3b3(RzRy, Rz, Ry);

			mat3b3_mat3b3(R, RzRy, Rx);

			double s2 = -R[2][0];
			double c2 = sqrt(1 - s2*s2);

			double s1 = R[1][0]/c2;
			double c1 = R[0][0]/c2;

			double s3 = R[2][1]/c2;
			double c3 = R[2][2]/c2;

			double th1 = atan2(s1, c1);
			double th2 = atan2(s2, c2);
			double th3 = atan2(s3, c3);
			
			rpy[0] = th1;
			rpy[1] = th2;
			rpy[2] = th3;
		*/

		//std::cout << ypr[0] << " " << ypr[1] << " " << ypr[2] << std::endl;

		double R[3][3];

		double sx = sin(ypr[2]);
		double cx = cos(ypr[2]);

		double Rx[3][3];
		Rx[0][0] = 1;
		Rx[0][1] = 0;
		Rx[0][2] = 0;
		Rx[1][0] = 0; 
		Rx[1][1] = cx;
		Rx[1][2] = -sx;
		Rx[2][0] = 0;
		Rx[2][1] = sx;
		Rx[2][2] = cx;

		double sy = sin(ypr[1]);
		double cy = cos(ypr[1]);

		double Ry[3][3];
		Ry[0][0] = cy;
		Ry[0][1] = 0;
		Ry[0][2] = sy;
		Ry[1][0] = 0; 
		Ry[1][1] = 1;
		Ry[1][2] = 0;
		Ry[2][0] = -sy;
		Ry[2][1] = 0;
		Ry[2][2] = cy;

		double sz = sin(ypr[0]);
		double cz = cos(ypr[0]);

		double Rz[3][3];
		Rz[0][0] = cz;
		Rz[0][1] = -sz;
		Rz[0][2] = 0;
		Rz[1][0] = sz; 
		Rz[1][1] = cz;
		Rz[1][2] = 0;
		Rz[2][0] = 0;
		Rz[2][1] = 0;
		Rz[2][2] = 1;

		double RzRy[3][3];
		mat3b3_mat3b3(RzRy, Rz, Ry);

		mat3b3_mat3b3(R, RzRy, Rx);
		/*
		std::cout << "R" << std::endl;
		std::cout << R[0][0] << " " << R[0][1] << " " << R[0][2] << std::endl;
		std::cout << R[1][0] << " " << R[1][1] << " " << R[1][2] << std::endl;
		std::cout << R[2][0] << " " << R[2][1] << " " << R[2][2] << std::endl;
		*/
		double RI_P[3][3];
		RI_P[0][0] = 0.0;
		RI_P[0][1] = -1.0;
		RI_P[0][2] = 0.0;
		RI_P[1][0] = 0.0;
		RI_P[1][1] = 0.0;
		RI_P[1][2] = 1.0;
		RI_P[2][0] = -1.0;
		RI_P[2][1] = 0.0;
		RI_P[2][2] = 0.0;
		
		double RLI_II[3][3];
		RLI_II[0][0] = 1.0;
		RLI_II[0][1] = 0.0;
		RLI_II[0][2] = 0.0;
		RLI_II[1][0] = 0.0;
		RLI_II[1][1] = -1.0;
		RLI_II[1][2] = 0.0;
		RLI_II[2][0] = 0.0;
		RLI_II[2][1] = 0.0;
		RLI_II[2][2] = -1.0;

		/*
		double RLI_II[3][3];
		RI_P[0][0] = -1.0;
		RI_P[0][1] = 0.0;
		RI_P[0][2] = 0.0;
		RI_P[1][0] = 0.0;
		RI_P[1][1] = 1.0;
		RI_P[1][2] = 0.0;
		RI_P[2][0] = 0.0;
		RI_P[2][1] = 0.0;
		RI_P[2][2] = -1.0;
		*/

		double Rc1[3][3];
		mat3b3_mat3b3(Rc1, RLI_II, R);
		/*
		std::cout << "Rc1" << std::endl;
		std::cout << Rc1[0][0] << " " << Rc1[0][1] << " " << Rc1[0][2] << std::endl;
		std::cout << Rc1[1][0] << " " << Rc1[1][1] << " " << Rc1[1][2] << std::endl;
		std::cout << Rc1[2][0] << " " << Rc1[2][1] << " " << Rc1[2][2] << std::endl;
		*/
		double Rc[3][3];
		mat3b3_mat3b3(Rc, Rc1, RI_P);
		/*
		std::cout << "Rc" << std::endl;
		std::cout << Rc[0][0] << " " << Rc[0][1] << " " << Rc[0][2] << std::endl;
		std::cout << Rc[1][0] << " " << Rc[1][1] << " " << Rc[1][2] << std::endl;
		std::cout << Rc[2][0] << " " << Rc[2][1] << " " << Rc[2][2] << std::endl;
		*/
		double s2 = -Rc[2][0];
		double c2 = sqrt(1 - s2*s2);

		double s1 = Rc[1][0]/c2;
		double c1 = Rc[0][0]/c2;

		double s3 = Rc[2][1]/c2;
		double c3 = Rc[2][2]/c2;

		double th1 = atan2(s1, c1);
		double th2 = atan2(s2, c2);
		double th3 = atan2(s3, c3);

		//Or if convention of LIPM is Y-P-R
		rpy[0] = th3;
		rpy[1] = th2;
		rpy[2] = th1;
	}

	void IMU_Conversion(double rpy[3], double ypr[3], double RI_P[3][3], double RLI_II[3][3])
	{
		//Using: X->Forward, Y->Left, Z-> Up
		/*
			double R[3][3];

			double sx = sin(ypr[2]);
			double cx = cos(ypr[2]);

			double Rx[3][3];
			Rx[0][0] = 1;
			Rx[0][1] = 0;
			Rx[0][2] = 0;
			Rx[1][0] = 0; 
			Rx[1][1] = cx;
			Rx[1][2] = -sx;
			Rx[2][0] = 0;
			Rx[2][1] = sx;
			Rx[2][2] = cx;

			double sy = sin(ypr[1]);
			double cy = cos(ypr[1]);

			double Ry[3][3];
			Ry[0][0] = cy;
			Ry[0][1] = 0;
			Ry[0][2] = sy;
			Ry[1][0] = 0; 
			Ry[1][1] = 1;
			Ry[1][2] = 0;
			Ry[2][0] = -sy;
			Ry[2][1] = 0;
			Ry[2][2] = cy;

			double sz = sin(ypr[0]);
			double cz = cos(ypr[0]);

			double Rz[3][3];
			Rz[0][0] = cz;
			Rz[0][1] = -sz;
			Rz[0][2] = 0;
			Rz[1][0] = sz; 
			Rz[1][1] = cz;
			Rz[1][2] = 0;
			Rz[2][0] = 0;
			Rz[2][1] = 0;
			Rz[2][2] = 1;

			double RzRy[3][3];
			mat3b3_mat3b3(RzRy, Rz, Ry);

			mat3b3_mat3b3(R, RzRy, Rx);

			double s2 = -R[2][0];
			double c2 = sqrt(1 - s2*s2);

			double s1 = R[1][0]/c2;
			double c1 = R[0][0]/c2;

			double s3 = R[2][1]/c2;
			double c3 = R[2][2]/c2;

			double th1 = atan2(s1, c1);
			double th2 = atan2(s2, c2);
			double th3 = atan2(s3, c3);
			
			rpy[0] = th1;
			rpy[1] = th2;
			rpy[2] = th3;
		*/

		double R[3][3];

		double sx = sin(ypr[2]);
		double cx = cos(ypr[2]);

		double Rx[3][3];
		Rx[0][0] = 1;
		Rx[0][1] = 0;
		Rx[0][2] = 0;
		Rx[1][0] = 0; 
		Rx[1][1] = cx;
		Rx[1][2] = -sx;
		Rx[2][0] = 0;
		Rx[2][1] = sx;
		Rx[2][2] = cx;

		double sy = sin(ypr[1]);
		double cy = cos(ypr[1]);

		double Ry[3][3];
		Ry[0][0] = cy;
		Ry[0][1] = 0;
		Ry[0][2] = sy;
		Ry[1][0] = 0; 
		Ry[1][1] = 1;
		Ry[1][2] = 0;
		Ry[2][0] = -sy;
		Ry[2][1] = 0;
		Ry[2][2] = cy;

		double sz = sin(ypr[0]);
		double cz = cos(ypr[0]);

		double Rz[3][3];
		Rz[0][0] = cz;
		Rz[0][1] = -sz;
		Rz[0][2] = 0;
		Rz[1][0] = sz; 
		Rz[1][1] = cz;
		Rz[1][2] = 0;
		Rz[2][0] = 0;
		Rz[2][1] = 0;
		Rz[2][2] = 1;

		double RzRy[3][3];
		mat3b3_mat3b3(RzRy, Rz, Ry);

		mat3b3_mat3b3(R, RzRy, Rx);

		double Rc1[3][3];
		mat3b3_mat3b3(Rc1, RLI_II, R);

		double Rc[3][3];
		mat3b3_mat3b3(Rc, Rc1, RI_P);

		double s2 = -Rc[2][0];
		double c2 = sqrt(1 - s2*s2);

		double s1 = Rc[1][0]/c2;
		double c1 = Rc[0][0]/c2;

		double s3 = Rc[2][1]/c2;
		double c3 = Rc[2][2]/c2;

		double th1 = atan2(s1, c1);
		double th2 = atan2(s2, c2);
		double th3 = atan2(s3, c3);

		//Or if convention of LIPM is Y-P-R
		rpy[0] = th3;
		rpy[1] = th2;
		rpy[2] = th1;
	}

	//Convert Simulation angles to B11 angles
	boost::array<int,12ul> sim_angles_to_b11_angles(double commanded_angles[12]){

		double qIn[3];
		double qOut[3];
		double reordered_angles[12];

		qIn[0] = commanded_angles[6];
		qIn[1] = commanded_angles[7];
		qIn[2] = commanded_angles[8];
		simToRealRight(qOut, qIn);	
		reordered_angles[0] = qOut[0];
		reordered_angles[1] = -qOut[1];
		reordered_angles[2] = -qOut[2];

		
		qIn[0] = commanded_angles[0];
		qIn[1] = commanded_angles[1];
		qIn[2] = commanded_angles[2];
		simToRealLeft(qOut, qIn);	
		reordered_angles[6] = -qOut[0];
		reordered_angles[7] = qOut[1];
		reordered_angles[8] = -qOut[2];

		reordered_angles[3] = -commanded_angles[9];
		reordered_angles[4] = -commanded_angles[10];
		reordered_angles[5] = -commanded_angles[11];
		reordered_angles[9] = -commanded_angles[3];
		reordered_angles[10] = -commanded_angles[4];
		reordered_angles[11] = commanded_angles[5];
 		
 		boost::array<int,12ul> target_enc_values;
		for (int i = 0; i < 12; i++)
			target_enc_values[i] = (int)(reordered_angles[i] * (INCREMENTAL_ENCODER_CPR * GEARHEAD_RATIO) / (2. * PI_NUMBER));

		return target_enc_values;
	}

	std::vector<double> b11_angles_to_sim_angles(double encoder_values[12]){
		double encoder_angles[12];

		
		//Convert raw encoder values to radians
		for(int i = 0; i < 12; i++)
		{

			encoder_angles[i] = encoder_values[i]*(2. * PI_NUMBER)/(INCREMENTAL_ENCODER_CPR * GEARHEAD_RATIO);

		}
		

		//Convert angles of B11 to angles of simplified robot
		//Left Leg
		double Enc[3];
		double qRes[3];
		Enc[0] = -encoder_angles[6];
		Enc[1] = encoder_angles[7];
		Enc[2] = -encoder_angles[8];
	
		realToSimLeft(qRes, Enc);

		encoder_angles[6] = qRes[0];
		encoder_angles[7] = qRes[1];
		encoder_angles[8] = qRes[2];

		//Right Leg
		Enc[0] = encoder_angles[0];
		Enc[1] = -encoder_angles[1];
		Enc[2] = -encoder_angles[2];
		realToSimRight(qRes, Enc);

		encoder_angles[0] = qRes[0];
		encoder_angles[1] = qRes[1];
		encoder_angles[2] = qRes[2];

		std::vector<double> positions;
		positions.resize(12);
        boost::array<double, 6ul> pos_left;
        boost::array<double, 6ul> pos_right;

        positions[0] = encoder_angles[6];
        positions[1] = encoder_angles[7];
        positions[2] = encoder_angles[8];
        positions[3] = -encoder_angles[9];
        positions[4] = -encoder_angles[10];
        positions[5] = encoder_angles[11];

        positions[6] = encoder_angles[0];
        positions[7] = encoder_angles[1];
        positions[8] = encoder_angles[2];
        positions[9] = -encoder_angles[3];
        positions[10] = -encoder_angles[4];
        positions[11] = -encoder_angles[5];

        return positions;
	}

	int radiant_to_incounts (int angle){
		return angle * (INCREMENTAL_ENCODER_CPR * GEARHEAD_RATIO) / (2. * PI_NUMBER) ;
	}
}

