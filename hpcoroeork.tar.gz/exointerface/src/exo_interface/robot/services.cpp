#include <exo_interface/robot/interface.h>
#include <exo_interface/common/timer.h>
#include <exo_interface/robot/packet.h>
#include <exo_interface/robot/services.h>
#include <iostream>
using namespace ros;
using namespace std;
namespace exo_interface {

ExoServices::ExoServices(ros::NodeHandle nh, ros::NodeHandle nhp,exo_interface::RobotInterface * ei) : nh_(nh), nhp_(nhp), ei_(ei)
{
    // setup servers for servises
    is_connected_= false;
  //  cout << ei_->test << endl;
 //   get_connection_service_ = nhp_.advertiseService("get_connection", &ExoServices::get_connection, this);
    ROS_INFO("service servers are stablished from inside class..");
    tt=567;
    ROS_INFO("%d",tt);
  //  cout << tt << endl;
}
ExoServices::ExoServices()
{
ROS_WARN("second cons");
}

ExoServices::~ExoServices()
{
ROS_ERROR("destr");
}

bool ExoServices::get_connection(exo_msgs::GetConnection::Request& req,exo_msgs::GetConnection::Response& res)
{
  res.is_connected = true;//ei_->is_open_;
 // cout << ei_->test << endl;
 // cout << tt << endl;
  ROS_INFO("%d",tt);
  return true;
}


}
