﻿#include <exo_interface/robot/interface.h>
#include <exo_interface/common/timer.h>
#include <exo_interface/common/data_conversion.h>
#include <exo_interface/robot/packet.h>
//#include <exo_interface/robot/services.h>
#include <iostream>
using namespace ros;
using namespace std;
namespace exo_interface {

RobotInterface::RobotInterface(ros::NodeHandle nh, ros::NodeHandle nhp) : nh_(nh), nhp_(nhp)
{
    // setup subscribers and publishers
    ROS_INFO("Running robot interface..");
    controller_cmd_definer();
    restart_timer_ = nhp_.createTimer(ros::Duration(1.0), boost::bind(&RobotInterface::setupConnection, this), false, false);
    command_subscriber_ = nhp_.subscribe("/robot/command", 50, &RobotInterface::commandCallback, this);
    foot_range_sensors_publisher_ = nhp_.advertise<exo_msgs::FootRangeSensors>("/robot/sensors/foot/range", 20);
    force_torque_sensors_publisher_ = nhp_.advertise<exo_msgs::ForceTorqueSensors>("/robot/sensors/foot/force", 20);

    joints_state_publisher_ = nhp_.advertise<exo_msgs::JointsState>("/robot/joints/state", 20);
    imu_sensor_publisher_ = nhp_.advertise<exo_msgs::IMUSensor>("/robot/sensors/backpack/imu", 20);
    foot_imu_sensor_publisher_ = nhp_.advertise<exo_msgs::IMUSensors>("/robot/sensors/foot/imu", 20);
    is_open_ = false;
    //exoservices = exo_interface::ExoServices (nh_, nhp_, this);
//    exo_interface::ExoServices exoservices(nh, nhp, this);
    get_connection_service_ = nhp_.advertiseService("get_connection", &RobotInterface::get_connection_callback, this);
    calibrate_inc_encoder_service_= nhp_.advertiseService("calibrate_encoder", &RobotInterface::calibrate_encoder_callback, this);
    get_encoders_service_= nhp_.advertiseService("get_encoders", &RobotInterface::get_encoders_callback, this);
    send_command_service_= nhp_.advertiseService("send_command", &RobotInterface::send_command_callback, this);
    goto_position_service_= nhp_.advertiseService("goto_position", &RobotInterface::goto_position_callback, this);
    reset_node_service_= nhp_.advertiseService("reset_node", &RobotInterface::reset_node_callback, this);
    sdo_packet_read_service_= nhp_.advertiseService("sdo_packet_read", &RobotInterface::sdo_packet_read_callback, this);
    sdo_packet_write_service_= nhp_.advertiseService("sdo_packet_write", &RobotInterface::sdo_packet_write_callback, this);
    set_motor_service_= nhp_.advertiseService("set_motor", &RobotInterface::set_motor_callback, this);

    exo_response_publisher_ = nhp_.advertise<exo_msgs::ExoResponse>("/robot/exoresponse",20);

    //  motor_command_publisher_ = nhp_.advertise<exo_msgs::MotorCommand>("/motors/command", 1);
    setupConnection();

}
RobotInterface::RobotInterface()
{
ROS_WARN("second constructor is called");
}

RobotInterface::~RobotInterface()
{
  ROS_ERROR("class deleted");
}

void RobotInterface::setupConnection()
{

    ROS_INFO("Setup connection to the robot..");

    is_open_ = false;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    sock_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (sock_fd_ < 0) {
        ROS_ERROR("Could not open the socket. Retrying in 2 seconds");
        restart_timer_.setPeriod(ros::Duration(2.0));
        restart_timer_.start();
        return;
    }

    struct timeval timeout;
    timeout.tv_sec  = 7;  // after 7 seconds connect() will timeout
    timeout.tv_usec = 0;
    setsockopt(sock_fd_, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));


    server = gethostbyname(HOSTNAME);
    if (server == NULL) {
        ROS_ERROR("Could not get host by its name. Retrying in 2 seconds");
        restart_timer_.setPeriod(ros::Duration(2.0));
        restart_timer_.start();
        return;
    }

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
    serv_addr.sin_port = htons(PORT);
    if (connect(sock_fd_, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
        ROS_ERROR("Could not connect to the server. Retrying in 2 seconds");
        restart_timer_.setPeriod(ros::Duration(2.0));
        restart_timer_.start();
        return;
    }

    is_open_ = true;
    read_thread_ = boost::make_shared<boost::thread>(boost::bind(&RobotInterface::readThread, this));
    restart_timer_.stop();

    ROS_INFO("Successfully connected to the robot @host: %s", HOSTNAME);
}

void RobotInterface::publishFootIMUData(RobotPacket * packet, ros::Time time)
{
  exo_msgs::IMUSensors::Ptr imuSensorsMessage = boost::make_shared<exo_msgs::IMUSensors>();
  imuSensorsMessage->header.stamp = time;

  uint8_t temp_buff[16] = {0};
  for (uint8_t p = 0; p < 3; ++p)
      for (int i = 0; i < 4; ++i)
          temp_buff[(p * 4) + 5 - i] = packet->sensors.foot_sensors[FP_LEFT].imu[(p * 4) + 2 + i];
  imuSensorsMessage->left.roll = *((float *) &temp_buff[2]);
  imuSensorsMessage->left.pitch = *((float *) &temp_buff[6]);
  imuSensorsMessage->left.yaw = *((float *) &temp_buff[10]);

  if (fabs(imuSensorsMessage->left.roll) > 6.2832 || fabs(imuSensorsMessage->left.pitch) > 6.2832 || fabs(imuSensorsMessage->left.yaw) > 6.2832)
  {
     ROS_ERROR("IMU data out of range!");
     ros::shutdown();
     return;
  }

  for (uint8_t p = 0; p < 3; ++p)
      for (int i = 0; i < 4; ++i)
          temp_buff[(p * 4) + 5 - i] = packet->sensors.foot_sensors[FP_RIGHT].imu[(p * 4) + 2 + i];
  imuSensorsMessage->right.roll = *((float *) &temp_buff[2]);
  imuSensorsMessage->right.pitch = *((float *) &temp_buff[6]);
  imuSensorsMessage->right.yaw = *((float *) &temp_buff[10]);

  if (fabs(imuSensorsMessage->right.roll) > 6.2832 || fabs(imuSensorsMessage->right.pitch) > 6.2832 || fabs(imuSensorsMessage->right.yaw) > 6.2832)
  {
     ROS_ERROR("IMU data out of range!");
     ros::shutdown();
     return;
  }

  foot_imu_sensor_publisher_.publish(imuSensorsMessage);
}

void RobotInterface::publishIMUData(IMUPacketType * imu_packet, ros::Time time)
{
    float roll, pitch, yaw;
  switch (imu_packet->Descriptor)
  {
    case EIMU_DESCSET_ESTFILTERDATA:
      switch (imu_packet->Payload[1])
      {
        case 0x5:  // Euler Angles
          uint8_t temp_buff[16] = {0};
          for (uint8_t p = 0; p < 3; ++p)
              for (int i = 0; i < 4; ++i)
                  temp_buff[(p * 4) + 5 - i] = (*((uint8_t *) (&imu_packet->Payload[(p * 4) + 2 + i])));
          roll = *((float *) &temp_buff[2]);
          pitch = *((float *) &temp_buff[6]);
          yaw = *((float *) &temp_buff[10]);
          break;
      }
      break;
    default:
      break;
  }

  if (fabs(roll) > 6.2832 || fabs(pitch) > 6.2832 || fabs(yaw) > 6.2832)
  {
     ROS_ERROR("IMU data out of range!");
     ros::shutdown();
     return;
  }
  exo_msgs::IMUSensor::Ptr imuSensorMessage = boost::make_shared<exo_msgs::IMUSensor>();

  imuSensorMessage->header.stamp = time;
  imuSensorMessage->roll = roll;
  imuSensorMessage->pitch = pitch;
  imuSensorMessage->yaw = yaw;

  imu_sensor_publisher_.publish(imuSensorMessage);
}

void RobotInterface::readThread()
{
    Timer timer(MOTION_FREQ);
    uint64_t expiration;
    int res;
    RobotPacket packet;
    while (is_open_) {

        // expiration = timer.sleep();
        // if(expiration > 1) {
        //     std::cerr << "read thread (robot interface) missed " << expiration << " cycle(s)!" << std::endl;
        // }

        // select(1024, )
        res = read(sock_fd_,(void*) &packet, sizeof(RobotPacket));
        if (res < 0) {
            ROS_ERROR("Failed to read from the server. Retrying in 2 seconds. err: %d", res);
            restart_timer_.setPeriod(ros::Duration(2.0));
            restart_timer_.start();
            return;
        }

        ros::Time now = ros::Time::now();
        if(packet.map[0]==1)
        {
            // the sensor structure is valid, publish footrange and forcetorque message
            exo_msgs::FootRangeSensors::Ptr footRangeMessage = boost::make_shared<exo_msgs::FootRangeSensors>();
            exo_msgs::ForceTorqueSensors::Ptr forceTorqueMessage = boost::make_shared<exo_msgs::ForceTorqueSensors>();
    
            footRangeMessage->header.stamp = now;
            for (int i=0; i<4; i++) {
                footRangeMessage->left[i] = packet.sensors.foot_sensors[FP_LEFT].rangeSensors[i];
                footRangeMessage->right[i] = packet.sensors.foot_sensors[FP_RIGHT].rangeSensors[i];
            }
    
            exo_msgs::ForceTorqueSensor leftForceTorque;
            leftForceTorque.fx = packet.sensors.foot_sensors[FP_LEFT].forceTorqueSensor.fx;
            leftForceTorque.fy = packet.sensors.foot_sensors[FP_LEFT].forceTorqueSensor.fy;
            leftForceTorque.fz = packet.sensors.foot_sensors[FP_LEFT].forceTorqueSensor.fz;
            leftForceTorque.tx = packet.sensors.foot_sensors[FP_LEFT].forceTorqueSensor.tx;
            leftForceTorque.ty = packet.sensors.foot_sensors[FP_LEFT].forceTorqueSensor.ty;
            leftForceTorque.tz = packet.sensors.foot_sensors[FP_LEFT].forceTorqueSensor.tz;
    
            exo_msgs::ForceTorqueSensor rightForceTorque;
            rightForceTorque.fx = packet.sensors.foot_sensors[FP_RIGHT].forceTorqueSensor.fx;
            rightForceTorque.fy = packet.sensors.foot_sensors[FP_RIGHT].forceTorqueSensor.fy;
            rightForceTorque.fz = packet.sensors.foot_sensors[FP_RIGHT].forceTorqueSensor.fz;
            rightForceTorque.tx = packet.sensors.foot_sensors[FP_RIGHT].forceTorqueSensor.tx;
            rightForceTorque.ty = packet.sensors.foot_sensors[FP_RIGHT].forceTorqueSensor.ty;
            rightForceTorque.tz = packet.sensors.foot_sensors[FP_RIGHT].forceTorqueSensor.tz;
    
            double offsetLeft[3];
            offsetLeft[0] = (57.5)/1000.0;
            offsetLeft[1] = (0.0)/1000.0;
            offsetLeft[2] = (-165+13)/1000.0;
    
            double offsetRight[3];
            offsetRight[0] = (57.5)/1000.0;
            offsetRight[1] = (0.0)/1000.0;
            offsetRight[2] = (-165+13)/1000.0;

            //Adjust Data to account for frame change
            leftForceTorque.fx = -leftForceTorque.fx;
            leftForceTorque.fz = -leftForceTorque.fz;
            leftForceTorque.tx = -leftForceTorque.tx;
            leftForceTorque.tz = -leftForceTorque.tz;

            rightForceTorque.fx = -rightForceTorque.fx;
            rightForceTorque.fz = -rightForceTorque.fz;
            rightForceTorque.tx = -rightForceTorque.tx;
            rightForceTorque.tz = -rightForceTorque.tz;

            exo_msgs::ForceTorqueSensor leftForceTorqueTemp;
            exo_msgs::ForceTorqueSensor rightForceTorqueTemp;

            leftForceTorqueTemp.fx = leftForceTorque.fx;
            leftForceTorqueTemp.fy = leftForceTorque.fy;
            leftForceTorqueTemp.fz = leftForceTorque.fz;
            leftForceTorqueTemp.tx = leftForceTorque.tx;
            leftForceTorqueTemp.ty = leftForceTorque.ty;
            leftForceTorqueTemp.tz = leftForceTorque.tz;

            rightForceTorqueTemp.fx = rightForceTorque.fx;
            rightForceTorqueTemp.fy = rightForceTorque.fy;
            rightForceTorqueTemp.fz = rightForceTorque.fz;
            rightForceTorqueTemp.tx = rightForceTorque.tx;
            rightForceTorqueTemp.ty = rightForceTorque.ty;
            rightForceTorqueTemp.tz = rightForceTorque.tz;

            //Adjust data to account for offsets
            leftForceTorque.tx = leftForceTorqueTemp.tx + (offsetLeft[1]*leftForceTorqueTemp.fz - leftForceTorqueTemp.fy*offsetLeft[2]);
            leftForceTorque.ty = leftForceTorqueTemp.ty - (offsetLeft[0]*leftForceTorqueTemp.fz - leftForceTorqueTemp.fx*offsetLeft[2]);
            leftForceTorque.tz = leftForceTorqueTemp.tz + (offsetLeft[0]*leftForceTorqueTemp.fy - leftForceTorqueTemp.fx*offsetLeft[1]);

            rightForceTorque.tx = rightForceTorqueTemp.tx + (offsetRight[1]*rightForceTorqueTemp.fz - rightForceTorqueTemp.fy*offsetRight[2]);
            rightForceTorque.ty = rightForceTorqueTemp.ty - (offsetRight[0]*rightForceTorqueTemp.fz - rightForceTorqueTemp.fx*offsetRight[2]);
            rightForceTorque.tz = rightForceTorqueTemp.tz + (offsetRight[0]*rightForceTorqueTemp.fy - rightForceTorqueTemp.fx*offsetRight[1]);

            publishIMUData(&packet.sensors.imu, now);
            publishFootIMUData(&packet, now);

            forceTorqueMessage->header.stamp = now;
            forceTorqueMessage->left = leftForceTorque;
            forceTorqueMessage->right = rightForceTorque;
    
            foot_range_sensors_publisher_.publish(footRangeMessage);
            force_torque_sensors_publisher_.publish(forceTorqueMessage);
        }

        if(packet.map[1] == 1)
        {
          //pdo JointsStats is valid, publish JointsStats message
          exo_msgs::JointsState::Ptr joints_msg = boost::make_shared<exo_msgs::JointsState>();
          joints_msg->header.stamp = now;
          for(int i = 0; i < NO_MOTORS; ++i)
          {
            joints_msg->states[i].controlword = packet.JointsStat[i].ControlWord;
            joints_msg->states[i].statusword = packet.JointsStat[i].StatusWord;
            joints_msg->states[i].current = packet.JointsStat[i].Current;
            joints_msg->states[i].position_incounts = packet.JointsStat[i].Position;
            joints_msg->states[i].timestamp = packet.JointsStat[i].TimeStamp;
            joints_msg->states[i].velocity = packet.JointsStat[i].Velocity;
          }

          joints_state_publisher_.publish(joints_msg);
        }

        if(packet.map[3]==1)
        {
          //exo response is valid, publish exo response message
          exo_msgs::ExoResponse::Ptr exo_response_msg = boost::make_shared<exo_msgs::ExoResponse>();
          exo_response_msg->header.stamp = now;
          exo_response_msg->response_id = packet.responses.response_id;
          for(uint8_t i=0;i<64;i++)
          {
            exo_response_msg->response_payload[i]=packet.responses.response_payload[i];
          }
          exo_response_publisher_.publish(exo_response_msg);
        }


        // TODO: do the same for Force torque sensor and etc.
    }

}

void RobotInterface::commandCallback(const exo_msgs::MotorCommand::ConstPtr& motor_command)
{
    int res;
    HPCPacket packet;

    memset(&packet,0,sizeof(HPCPacket));

    packet.command_id = controller_cmd_map["APP_CMD_MOTIONPOSITION"];
//    write_mutex_.lock();
    for (int i=0; i<NO_MOTORS; i++) {
      memcpy(&packet.command_payload[4*i],&motor_command->positions[i],4);
//        packet.positions[i] = motor_command->positions[i];// * INCREMENTAL_ENCODER_CPR * GEARHEAD_RATIO) / (2. * PI_NUMBER);
    }

    res = send(sock_fd_, &packet, sizeof(HPCPacket), 0);
    if (res < 0) {
        ROS_ERROR("Failed to write to the server. err: %d", res);
    }

}
void RobotInterface::writeThread()
{
    return; // SKIP FOR NOW
    Timer timer(MOTION_FREQ);
    uint64_t expiration;

    int res;
    while (is_open_) {
        expiration = timer.sleep();
        if(expiration > 1) {
            std::cerr << "write thread (robot interface) missed " << expiration << " cycle(s)!" << std::endl;
        }
        write_mutex_.lock();
        res = send(sock_fd_, &current_packet_, sizeof(HPCPacket), 0);
        write_mutex_.unlock();
        if (res < 0) {
            ROS_ERROR("Failed to write to the server. err: %d", res);
            restart_timer_.setPeriod(ros::Duration(2.0));
            restart_timer_.start();
            return;
        }
    }


}
void RobotInterface::controller_cmd_definer()
{
  controller_cmd_map["APP_CMD_RUNMOTION"] = 1;
  controller_cmd_map["APP_CMD_STOPMOTION"] = 2;
  controller_cmd_map["APP_CMD_GOTOHOME"] = 3;
  controller_cmd_map["APP_CMD_GOTOZERO"] = 4;
  controller_cmd_map["APP_CMD_MOTORSON"] = 5;
  controller_cmd_map["APP_CMD_MOTORSOFF"] = 6;
  controller_cmd_map["APP_CMD_UPDATESTATUS"] = 7;
  controller_cmd_map["APP_CMD_SENDTXPDO1DATA"] = 8;
  controller_cmd_map["APP_CMD_SENDTXPDO2DATA"] = 9;
  controller_cmd_map["APP_CMD_SENDTXPDO3DATA"] = 10;
  controller_cmd_map["APP_CMD_SENDTXPDO4DATA"] = 11;
  controller_cmd_map["APP_CMD_FOOTPLATESON"] = 12;
  controller_cmd_map["APP_CMD_FOOTPLATESOFF"] = 13;
  controller_cmd_map["APP_CMD_SDOREAD"] = 14;
  controller_cmd_map["APP_CMD_SDOWRITE"] = 15;
  controller_cmd_map["APP_CMD_MOTIONPOSITION"] = 16;
  controller_cmd_map["APP_CMD_MOTORSET"] = 17;
  controller_cmd_map["APP_CMD_ABSENCODER"] = 18;
  controller_cmd_map["APP_CMD_INCENCODER"] = 19;
  controller_cmd_map["APP_CMD_CALIBRATEENCODER"] = 20;
  controller_cmd_map["APP_CMD_GOTOPOSITION"] = 21;
  controller_cmd_map["APP_CMD_RESETNODE"] = 22;
}

bool RobotInterface::get_connection_callback(exo_msgs::GetConnection::Request& req,exo_msgs::GetConnection::Response& res)
{
  res.is_connected = is_open_;
  ROS_INFO("Service is called, get connection");
  return true;
}
bool RobotInterface::calibrate_encoder_callback(exo_msgs::CalibrateINCEncoder::Request& req,exo_msgs::CalibrateINCEncoder::Response& res)
{
  res.is_transmitted = is_open_;
  ROS_INFO("Service is called, calibrate encoder");
  if(is_open_)
  {
      int result;
      HPCPacket to_controller;
      memset(&to_controller,0,sizeof(HPCPacket));

      to_controller.command_id = controller_cmd_map["APP_CMD_CALIBRATEENCODER"];
      memcpy(&to_controller.command_payload[0],&req.robot_map,2);
      result = send(sock_fd_, &to_controller, sizeof(HPCPacket), 0);
      if (result < 0) {
          ROS_ERROR("Failed to write to the calibrate encoder server. err: %d", result);
      }
  }
  else
  {
      ROS_ERROR("No connection to support calibrate encoder service");
  }

  return true;
}
bool RobotInterface::get_encoders_callback(exo_msgs::GetEncoders::Request& req,exo_msgs::GetEncoders::Response& res)
{
  res.is_transmitted = is_open_;
  ROS_INFO("Service is called, get encoders");
  if(is_open_)
  {
      int result;
      HPCPacket to_controller;
      memset(&to_controller,0,sizeof(HPCPacket));

      if (req.encoder_type==0)
        to_controller.command_id = controller_cmd_map["APP_CMD_INCENCODER"]; // incremental
      else
        to_controller.command_id = controller_cmd_map["APP_CMD_ABSENCODER"]; //absolute


      result = send(sock_fd_, &to_controller, sizeof(HPCPacket), 0);
      if (result < 0) {
          ROS_ERROR("Failed to write to the get encoder server. err: %d", result);
      }
  }
  else
  {
      ROS_ERROR("No connection to support get encoder service");
  }

  return true;
}
bool RobotInterface::send_command_callback(exo_msgs::SendCommand::Request& req,exo_msgs::SendCommand::Response& res)
{
  res.is_transmitted = is_open_;
  ROS_INFO("Service is called, motion command");
  if(is_open_)
  {
      int result;
      HPCPacket to_controller;
      memset(&to_controller,0,sizeof(HPCPacket));
      if(req.command == "updatestatus")
      {
        to_controller.command_id = controller_cmd_map["APP_CMD_UPDATESTATUS"];
      }
      else if(req.command == "motorson")
      {
        to_controller.command_id = controller_cmd_map["APP_CMD_MOTORSON"];
      }
      else if(req.command == "motorsoff")
      {
        to_controller.command_id = controller_cmd_map["APP_CMD_MOTORSOFF"];
      }
      else if(req.command == "gotohome")
      {
        to_controller.command_id = controller_cmd_map["APP_CMD_GOTOHOME"];
      }
      else if(req.command == "runmotion")
      {
        to_controller.command_id = controller_cmd_map["APP_CMD_RUNMOTION"];
      }
      else if(req.command == "stopmotion")
      {
        to_controller.command_id = controller_cmd_map["APP_CMD_STOPMOTION"];
      }
      else if(req.command == "footplateson")
      {
        to_controller.command_id = controller_cmd_map["APP_CMD_FOOTPLATESON"];
      }
      else if(req.command == "footplatesoff")
      {
        to_controller.command_id = controller_cmd_map["APP_CMD_FOOTPLATESOFF"];
      }
      else
      {
        ROS_ERROR("invalid input, the valid inputs are [updatestatus motorson motorsoff  gotohome gotostart runmotion stopmotion footplateson footplatesoff]");
        res.is_transmitted = false;
        return true;
      }

      result = send(sock_fd_, &to_controller, sizeof(HPCPacket), 0);
      if (result < 0) {
          ROS_ERROR("Failed to write to the get status server. err: %d", result);
      }
  }
  else
  {
      ROS_ERROR("No connection to support motion command service");
  }

  return true;
}

bool RobotInterface::goto_position_callback(exo_msgs::GotoPosition::Request& req,exo_msgs::GotoPosition::Response& res)
{
  res.is_transmitted = is_open_;
  if(is_open_)
  {
      int result;
      HPCPacket to_controller;
      memset(&to_controller,0,sizeof(HPCPacket));
      to_controller.command_id = controller_cmd_map["APP_CMD_GOTOPOSITION"] ;

      memcpy(&to_controller.command_payload[0],&req.robot_map,2);
      memcpy(&to_controller.command_payload[2],&req.encoder_count[0],48);
      result = send(sock_fd_, &to_controller, sizeof(HPCPacket), 0);
      if (result < 0) {
          ROS_ERROR("Failed to write to the goto position server. err: %d", result);
      }
  }
  else
  {
      ROS_ERROR("No connection to support goto position service");
  }

  ROS_INFO("Service is called, goto position");
  return true;
}
bool RobotInterface::reset_node_callback(exo_msgs::ResetNode::Request& req,exo_msgs::ResetNode::Response& res)
{
  res.is_transmitted = is_open_;
  ROS_INFO("Service is called, reset node");
  if(is_open_)
  {
      int result;
      HPCPacket to_controller;
      memset(&to_controller,0,sizeof(HPCPacket));

      to_controller.command_id = controller_cmd_map["APP_CMD_RESETNODE"];
      memcpy(&to_controller.command_payload[0],&req.robot_map,2);
      result = send(sock_fd_, &to_controller, sizeof(HPCPacket), 0);
      if (result < 0) {
          ROS_ERROR("Failed to write to the reset node server. err: %d", result);
      }
  }
  else
  {
      ROS_ERROR("No connection to support reset node service");
  }
  return true;
}
bool RobotInterface::sdo_packet_read_callback(exo_msgs::SDOPacketRead::Request& req,exo_msgs::SDOPacketRead::Response& res)
{
  res.is_transmitted = is_open_;
  ROS_INFO("Service is called, sdo packet read");
  fortest_exo_response_publisher();
  if(is_open_)
  {
      int result;
      HPCPacket to_controller;
      memset(&to_controller,0,sizeof(HPCPacket));

      to_controller.command_id = controller_cmd_map["APP_CMD_SDOREAD"];
      memcpy(&to_controller.command_payload[0],&req.node_id,1);
      memcpy(&to_controller.command_payload[1],&req.object,2);
      memcpy(&to_controller.command_payload[3],&req.subindex,1);
      result = send(sock_fd_, &to_controller, sizeof(HPCPacket), 0);
      if (result < 0) {
          ROS_ERROR("Failed to write to the sdo read server. err: %d", result);
      }
  }
  else
  {
      ROS_ERROR("No connection to support sdo read service");
  }
  return true;
}
bool RobotInterface::sdo_packet_write_callback(exo_msgs::SDOPacketWrite::Request& req,exo_msgs::SDOPacketWrite::Response& res)
{
  res.is_transmitted = is_open_;
  ROS_INFO("Service is called, sdo packet write");
  if(is_open_)
  {
      int result;
      HPCPacket to_controller;
      memset(&to_controller,0,sizeof(HPCPacket));

      to_controller.command_id = controller_cmd_map["APP_CMD_SDOWRITE"];
      memcpy(&to_controller.command_payload[0],&req.node_id,1);
      memcpy(&to_controller.command_payload[1],&req.object,2);
      memcpy(&to_controller.command_payload[3],&req.subindex,1);
      memcpy(&to_controller.command_payload[4],&req.data,4);
      result = send(sock_fd_, &to_controller, sizeof(HPCPacket), 0);
      if (result < 0) {
          ROS_ERROR("Failed to write to the sdo write server. err: %d", result);
      }
  }
  else
  {
      ROS_ERROR("No connection to support sdo write service");
  }
  return true;
}

bool RobotInterface::set_motor_callback(exo_msgs::SetMotor::Request& req,exo_msgs::SetMotor::Response& res)
{

  res.is_transmitted = is_open_;
  ROS_INFO("Service is called, set motor");
  fortest_exo_response_publisher();
  if(is_open_)
  {
      int result;
      HPCPacket to_controller;
      memset(&to_controller,0,sizeof(HPCPacket));
      to_controller.command_id = controller_cmd_map["APP_CMD_MOTORSET"];
      memcpy(&to_controller.command_payload[0],&req.robot_map,2);
      if(req.enable)
        to_controller.command_payload[2] = 1;
      else
        to_controller.command_payload[2] = 0;
      result = send(sock_fd_, &to_controller, sizeof(HPCPacket), 0);
      if (result < 0) {
          ROS_ERROR("Failed to write to the set motor server. err: %d", result);
      }
  }
  else
  {
      ROS_ERROR("No connection to support set motor service");
  }
  return true;
}

void RobotInterface::fortest_exo_response_publisher()
{
  exo_msgs::ExoResponse::Ptr exo_response_msg = boost::make_shared<exo_msgs::ExoResponse>();
  ros::Time now = ros::Time::now();
  exo_response_msg->header.stamp = now;
  exo_response_msg->response_id = 1;
  uint16_t cob_id = 0x601;
  uint8_t byte0 = 0x1;
  uint16_t od = 0x3002;
  uint8_t subindex = 1;
  int32_t data = 1234;
  uint8_t pl[64];
  memset(&pl[0],0,64);
  memcpy(&pl[0],&cob_id,2);
  memcpy(&pl[2],&byte0,1);
  memcpy(&pl[3],&od,2);
  memcpy(&pl[5],&subindex,1);
  memcpy(&pl[6],&data,4);

  for(int i=0;i<64;i++)
  {
    exo_response_msg->response_payload[i]=pl[i];
  }
  exo_response_publisher_.publish(exo_response_msg);
}

}

