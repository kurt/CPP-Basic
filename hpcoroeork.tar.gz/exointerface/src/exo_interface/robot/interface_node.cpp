#include <ros/ros.h>
#include <exo_interface/robot/interface.h>

/**
    Starting point where the application (node) starts, instantiating exogateway object that registers services, nodes, publishers and advertisers.

    @param int args
    @param char** argv
    @return success
*/
int main(int argc, char** argv)
{
    ros::init(argc, argv, "robot_interface_node");
//Commented for testing

    exo_interface::RobotInterface robotInterface(ros::NodeHandle(), ros::NodeHandle("~"));
    ros::spin();


/////Added for testing
//exo_interface::RobotInterface robotInterface(ros::NodeHandle(), ros::NodeHandle("~"));
/////

    return 0;
}
