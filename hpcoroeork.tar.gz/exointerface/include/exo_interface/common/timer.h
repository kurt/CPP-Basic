#ifndef __CUSTOM_TIMER_H__
#define __CUSTOM_TIMER_H__

#include <ctime>
#include <cstdlib>

namespace exo_interface {

class Timer {
public:
    Timer(double rate);
    virtual ~Timer();

    long unsigned int sleep();

private:
    int timer_fd_;
};

}

#endif
