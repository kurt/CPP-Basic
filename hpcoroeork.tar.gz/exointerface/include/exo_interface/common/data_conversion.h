#ifndef __DATA_CONVERSION_H__
#define __DATA_CONVERSION_H__

#include <stdio.h> 
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <boost/array.hpp>

namespace exo_interface {
	void mat3b3_vec3(double res[3], double mat[3][3], double vec[3]);
	void mat3b3_mat3b3(double res[3][3], double mat1[3][3], double mat2[3][3]);
	void transpose_mat3b3(double res[3][3], double mat[3][3]);
	void arbitrary_axis_rot(double  R[3][3], double th, double kx, double ky, double kz);
	void Hybrid_FK_mat(double R0_3[3][3], double angles[3], double Pmtoc1wM[3], double P0toMw0[3], double P0toc2w2[3], double Lb, double v1w0[3], double v2w1[3], double v3w2[3], double vMw0[3]);
	void Simplified_IK(double angles[3], double R0_3[3][3]);
	void Hip_mech(double inp[9],double outp[4],int dir);
	void Hip_Joints_IK(double R[3][3],double outp[4],int side);
	void fast_inv(double inp[16],double outp[16]);
	void Simplified_FK(double R[3][3], double angles[3]);
	void realToSimRight(double qOut[3], double Enc[3]);
	void realToSimLeft(double qOut[3], double Enc[3]);
	void simToRealRight(double qOut[3], double qIn[3]);
	void simToRealLeft(double qOut[3], double qIn[3]);
	void YPR_to_RPY(double rpy[3], double ypr[3]);
	boost::array<int,12ul> sim_angles_to_b11_angles(double commanded_angles[12]);
	std::vector<double> b11_angles_to_sim_angles(double encoder_values[12]);
	int radiant_to_incounts (int angle);
	void IMU_Conversion(double rpy[3], double ypr[3], double RI_P[3][3], double RLI_II[3][3]);
}

#endif
