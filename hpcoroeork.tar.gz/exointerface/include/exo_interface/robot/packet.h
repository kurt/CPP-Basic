#ifndef __EXO_PACKET_H__
#define __EXO_PACKET_H__

#define NO_MOTORS 12
#define CMD_PAYLOAD_SIZE 64
#define IMU_MAX_PAYLOAD 64
#define FP_RIGHT  0
#define FP_LEFT   1

#define INCREMENTAL_ENCODER_CPR 3456
#define GEARHEAD_RATIO          101
#define PI_NUMBER               3.14159265359

#define ROBOT_PACKET_LEN sizeof(RobotPacket)
#define HPC_PACKET_LEN sizeof(HPCPacket)

typedef struct __attribute__((__packed__))
{
    float fx;
    float fy;
    float fz;
    float tx;
    float ty;
    float tz;
} ForceTorqueSensor;

typedef struct __attribute__((__packed__))
{
    ForceTorqueSensor forceTorqueSensor;
    int16_t           rangeSensors[4]; // 0: FR, 1: FL, 2: RR, 3: RL
    uint8_t           imu[16];
} FootSensors;

typedef struct __attribute__((__packed__))
{
    uint8_t State;
    uint8_t Descriptor;
    uint8_t PayloadLength;
    uint8_t Payload[IMU_MAX_PAYLOAD];
    uint8_t PayloadIndex;
    uint8_t Checksum[2];
} IMUPacketType;

typedef struct __attribute__((__packed__))
{
    FootSensors foot_sensors[2]; // 0 is left, 1 is right
    IMUPacketType imu;
} Sensors;

typedef struct __attribute__((__packed__))
{
    uint8_t tx_pdo[4][8];
} MotorState;

typedef struct __attribute__((__packed__))
{
    uint8_t response_id;
    uint8_t response_payload[64];
} ExoResponses;

typedef enum __attribute__((__packed__))
{
    EJOINT_STATE_POSITION = 0x1,
    EJOINT_STATE_VELOCITY = 0x2,
    EJOINT_STATE_CTRLWORD = 0x4,
    EJOINT_STATE_STSWORD = 0x8,
    EJOINT_STATE_TIMESTAMP = 0x16,
    EJOINT_STATE_CURRENT = 0x32,
    EJOINT_STATE_TORQUE = 0x64
} JointStatFlagsType;

enum
{
    EIMU_DESCSET_BASECMD = 0x01,
    EIMU_DESCSET_3DMCMD = 0x0C,
    EIMU_DESCSET_ESTFILTERCMD = 0x0D,
    EIMU_DESCSET_SYSCMD = 0x7F,
    EIMU_DESCSET_IMUDATA = 0x80,
    EIMU_DESCSET_ESTFILTERDATA = 0x82
};

typedef struct __attribute__((__packed__))
{
    int32_t Position;
    int32_t Velocity;
    uint16_t ControlWord;
    uint16_t StatusWord;
    uint32_t TimeStamp;
    int16_t Current;
    int16_t Torque;
    JointStatFlagsType IsValid;
} RobotJointStatType;

typedef RobotJointStatType RobotJointsStatType[NO_MOTORS];

typedef struct __attribute__((__packed__))
{
    uint8_t map[4];
    Sensors sensors;
    RobotJointsStatType JointsStat;
    ExoResponses responses;
} RobotPacket;

typedef struct __attribute__((__packed__))
{
  uint8_t command_id;
  uint8_t command_payload[CMD_PAYLOAD_SIZE];
} HPCPacket;

#endif
