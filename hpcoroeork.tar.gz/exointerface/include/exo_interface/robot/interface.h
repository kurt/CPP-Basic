#ifndef __ROBOT_INTERFACE_H__
#define __ROBOT_INTERFACE_H__

#include <ros/ros.h>
#include <sys/socket.h> 
#include <sys/select.h>
#include <netdb.h>
#include <arpa/inet.h> 
#include <stdio.h> 
#include <unistd.h> 
#include <fcntl.h>
#include <boost/thread.hpp>
#include <boost/function.hpp>
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <map>

#include <exo_interface/robot/packet.h>
//#include <exo_interface/robot/services.h>
#include <exo_msgs/JointData.h>
#include <exo_msgs/MotorCommand.h>
#include <exo_msgs/ForceTorqueSensors.h>
#include <exo_msgs/ForceTorqueSensor.h>
#include <exo_msgs/FootRangeSensors.h>
#include <exo_msgs/IMUSensor.h>
#include <exo_msgs/IMUSensors.h>

#include <exo_msgs/GetConnection.h>
#include <exo_msgs/GetEncoders.h>
#include <exo_msgs/SendCommand.h>
#include <exo_msgs/GotoPosition.h>
#include <exo_msgs/ResetNode.h>
#include <exo_msgs/SDOPacketRead.h>
#include <exo_msgs/SDOPacketWrite.h>
#include <exo_msgs/SetMotor.h>
#include <exo_msgs/CalibrateINCEncoder.h>

#include <exo_msgs/ExoResponse.h>
#include <exo_msgs/JointState.h>
#include <exo_msgs/JointsState.h>


// #include <sensor_msgs/Imu.h>
// #include <serial/serial.h>

// #define CM904_DEVICE    "/dev/cm904"
// #define BAUD_RATE       1e6
// #define BUFFER_LENGTH   32

#define HOSTNAME "192.168.2.100"
//#define HOSTNAME "localhost"
#define PORT 5000 
#define MOTION_FREQ 0.01

namespace exo_interface {



class RobotInterface
{
public:
    RobotInterface(ros::NodeHandle nh, ros::NodeHandle nhp);
    RobotInterface();
    virtual ~RobotInterface();

private:
    void setupConnection();
    void commandCallback(const exo_msgs::MotorCommand::ConstPtr& motor_command);
    void readThread();
    void writeThread();
    void parseData(uint8_t * buffer, int size);
    bool get_connection_callback(exo_msgs::GetConnection::Request& req,exo_msgs::GetConnection::Response& res);
    bool calibrate_encoder_callback(exo_msgs::CalibrateINCEncoder::Request& req,exo_msgs::CalibrateINCEncoder::Response& res);
    bool get_encoders_callback(exo_msgs::GetEncoders::Request& req,exo_msgs::GetEncoders::Response& res);
    bool send_command_callback(exo_msgs::SendCommand::Request& req,exo_msgs::SendCommand::Response& res);
    bool goto_position_callback(exo_msgs::GotoPosition::Request& req,exo_msgs::GotoPosition::Response& res);
    bool reset_node_callback(exo_msgs::ResetNode::Request& req,exo_msgs::ResetNode::Response& res);
    bool sdo_packet_read_callback(exo_msgs::SDOPacketRead::Request& req,exo_msgs::SDOPacketRead::Response& res);
    bool sdo_packet_write_callback(exo_msgs::SDOPacketWrite::Request& req,exo_msgs::SDOPacketWrite::Response& res);
    bool set_motor_callback(exo_msgs::SetMotor::Request& req,exo_msgs::SetMotor::Response& res);
    void controller_cmd_definer();
    void publishIMUData(IMUPacketType * imu_packet, ros::Time time);
    void publishFootIMUData(RobotPacket * packet, ros::Time time);
    void fortest_exo_response_publisher();

public:




private:
    int sock_fd_;
    const int32_t min_limits[NO_MOTORS] = {-24240,-19392,-29088,-116352,-38784,-14544,-24240,-19392,-29088,-116352,-38784,-14544};
    const int32_t max_limits[NO_MOTORS] = {24240,19392,126048,969,24240,14544,24240,19392,126048,969,24240,14544};
    std::map<std::string, uint8_t> controller_cmd_map;
    HPCPacket current_packet_;

    ros::ServiceServer get_connection_service_;
    ros::ServiceServer calibrate_inc_encoder_service_;
    ros::ServiceServer get_encoders_service_;
    ros::ServiceServer send_command_service_;
    ros::ServiceServer goto_position_service_;
    ros::ServiceServer reset_node_service_;
    ros::ServiceServer sdo_packet_read_service_;
    ros::ServiceServer sdo_packet_write_service_;
    ros::ServiceServer set_motor_service_;
    bool is_open_;
 //   exo_interface::ExoServices exoservices_();

private:
    ros::NodeHandle nh_;
    ros::NodeHandle nhp_;
    ros::Subscriber command_subscriber_;
    ros::Publisher foot_range_sensors_publisher_;
    ros::Publisher force_torque_sensors_publisher_;
    ros::Publisher encoder_publisher_;
    ros::Publisher orientation_publisher_;
    ros::Publisher joints_state_publisher_;
    ros::Publisher imu_sensor_publisher_;
    ros::Publisher foot_imu_sensor_publisher_;

    ros::Publisher exo_response_publisher_;
//    ros::Publisher motor_command_publisher_;
    ros::Timer restart_timer_;
    boost::shared_ptr<boost::thread> read_thread_;
    boost::shared_ptr<boost::thread> write_thread_;
    boost::mutex write_mutex_;
};

};

#endif
