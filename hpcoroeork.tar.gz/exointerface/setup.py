from distutils.core import setup
from catkin_pkg.python_setup import generate_distutils_setup

# fetch values from package.xml
setup_args = generate_distutils_setup(
    packages=['sim_pybullet3'],
    package_dir={'': 'src/exo_interface'},
)

setup(**setup_args)
