import os
import rospy
import rospkg
import rosbagprocess
import autosave_process
import binary_process
import json_process
import footplate_process
import graphic_process
import service_process
import pdo_process
import exo_process
from qt_gui.plugin import Plugin
from python_qt_binding import loadUi
from python_qt_binding.QtWidgets import QWidget
import easygui
import time
import Tkinter
import tkFileDialog
import threading
import math
from PyQt5 import QtCore, QtGui

class TimerThread(QtCore.QThread):
    update = QtCore.pyqtSignal()
    def __init__(self, event):
        QtCore.QThread.__init__(self)
        self.stopped = event

    def run(self):
        self.update.emit()
        while not self.stopped.wait(0.1):
            self.update.emit()
            

class ExouiPlugin(Plugin):
    #create class
    def __init__(self, context):
        super(ExouiPlugin, self).__init__(context)
        # Give QObjects reasonable names
        self.setObjectName('ExouiPlugin')

        # Process standalone plugin command-line arguments
        from argparse import ArgumentParser
        parser = ArgumentParser()
        # Add argument(s) to the parser.
        parser.add_argument("-q", "--quiet", action="store_true",
                      dest="quiet",
                      help="Put plugin in silent mode")
        args, unknowns = parser.parse_known_args(context.argv())
        if not args.quiet:
            print ('arguments: ', args)
            print ('unknowns: ', unknowns)

        # Create QWidget
        self._widget = QWidget()
        # Get path to UI file which should be in the "resource" folder of this package
        ui_file = os.path.join(rospkg.RosPack().get_path('rqt_exoui'), 'resource', 'ExouiPlugin.ui')
        # Extend the widget with all attributes and children from UI file
        loadUi(ui_file, self._widget)
        # Give QObjects reasonable names
        self._widget.setObjectName('ExouiPluginUi')
        # Show _widget.windowTitle on left-top of each plugin (when 
        # it's set in _widget). This is useful when you open multiple 
        # plugins at once. Also if you open multiple instances of your 
        # plugin at once, these lines add number to make it easy to 
        # tell from pane to pane.
        self._widget.Button_Rosbag_Open.clicked.connect(self._manage_button_rosbag_open)
        self._widget.Button_Rosbag_Plot.clicked.connect(self._manage_button_rosbag_plot)
        self._widget.Button_Rosbag_Plot_Close.clicked.connect(self._manage_button_rosbag_plot_close)
        self._widget.Button_Json_Load.clicked.connect(self._manage_button_json_load)
        self._widget.Button_Json_Plot.clicked.connect(self._manage_button_json_plot)
        self._widget.Button_Binary_Make.clicked.connect(self._manage_button_binary_make)
        self._widget.Button_Binary_Load.clicked.connect(self._manage_button_binary_load)
        self._widget.Button_Footplate_Reset.clicked.connect(self._manage_button_footplate_reset)
        self._widget.Button_Footplate_Enable.clicked.connect(self._manage_button_footplate_enable)
        self._widget.Button_Footplate_Disable.clicked.connect(self._manage_button_footplate_disable)
        self._widget.Button_Refresh_Exo.clicked.connect(self._manage_button_refresh_exo)
        self._widget.Button_Motors_On.clicked.connect(self._manage_button_motors_on)
        self._widget.Button_Motors_Off.clicked.connect(self._manage_button_motors_off)
        self._widget.Button_Reset_Node.clicked.connect(self._manage_button_reset_node)
        self._widget.Button_Reset_All.clicked.connect(self._manage_button_reset_all)
        self._widget.Button_Calibrate_Encoders.clicked.connect(self._manage_button_calibrate_encoders)
        self._widget.Button_GotoPosition_RHA.clicked.connect(self._manage_button_gotoposition_rha)
        self._widget.Button_GotoPosition_RHR.clicked.connect(self._manage_button_gotoposition_rhr)
        self._widget.Button_GotoPosition_RHF.clicked.connect(self._manage_button_gotoposition_rhf)
        self._widget.Button_GotoPosition_RK.clicked.connect(self._manage_button_gotoposition_rk)
        self._widget.Button_GotoPosition_RAF.clicked.connect(self._manage_button_gotoposition_raf)
        self._widget.Button_GotoPosition_RAI.clicked.connect(self._manage_button_gotoposition_rai)
        self._widget.Button_GotoPosition_LHA.clicked.connect(self._manage_button_gotoposition_lha)
        self._widget.Button_GotoPosition_LHR.clicked.connect(self._manage_button_gotoposition_lhr)
        self._widget.Button_GotoPosition_LHF.clicked.connect(self._manage_button_gotoposition_lhf)
        self._widget.Button_GotoPosition_LK.clicked.connect(self._manage_button_gotoposition_lk)
        self._widget.Button_GotoPosition_LAF.clicked.connect(self._manage_button_gotoposition_laf)
        self._widget.Button_GotoPosition_LAI.clicked.connect(self._manage_button_gotoposition_lai)
        self._widget.Button_Put_Encoders.clicked.connect(self._manage_button_put_encoders)
        self._widget.Button_Put_Home.clicked.connect(self._manage_button_put_home)
        self._widget.Button_Put_Start.clicked.connect(self._manage_button_put_start)
        self._widget.Button_Goto_All.clicked.connect(self._manage_button_goall)
        self._widget.Button_Motion_Load.clicked.connect(self._manage_button_motion_load)

        self._widget.Button_Motion_Save_Logs.clicked.connect(self._manage_button_motion_save_logs)
        self._widget.Button_Motion_Reset_Logs.clicked.connect(self._manage_button_motion_reset_logs)
        self._widget.Button_Goto_Home.clicked.connect(self._manage_button_goto_home)
        self._widget.Button_Goto_Start.clicked.connect(self._manage_button_goto_start)
        self._widget.Button_Start_Motion.clicked.connect(self._manage_button_start_motion)

        if context.serial_number() > 1:
            self._widget.setWindowTitle(self._widget.windowTitle() + (' (%d)' % context.serial_number()))
        # Add widget to the user interface
        context.add_widget(self._widget)
        self.rbg = rosbagprocess.RosbagProcess()
        self.a_save = autosave_process.AutoSaveProcess(autosave_process.__file__) # for passing the location of workspace
        self.json_p=json_process.JsonProcess()
        self.footplates=footplate_process.ExoFootplateProcess()
        self.graph_p = graphic_process.GraphicProcess()
        self.pdo_p = pdo_process.ExoPDOProcess()
        self.exo_p = exo_process.ExoProcess()
        self.service_p = service_process.ServiceProcess()
        pp = self.service_p.get_connection_status()
        self._widget.Icon_Connect.setVisible(pp.is_connected)
        self._widget.Icon_Disconnect.setVisible(not pp.is_connected)

        #defining array and matrix controls for status page
        for ll in range(13):
            self._widget.Status_Labels_Layout.addWidget(self.graph_p.status_labels_abs[ll],ll,0)

            self._widget.Status_Labels_Layout.addWidget(self.graph_p.status_labels_inc[ll], ll, 1)
            self._widget.Status_Labels_Layout.addWidget(self.graph_p.status_labels_curr[ll], ll, 2)
            self._widget.Status_Labels_Layout.addWidget(self.graph_p.status_labels_start[ll], ll, 3)
        for ll in range(12):
            for kk in range(14):
                self._widget.Status_Leds_Layout.addWidget(self.graph_p.status_led_off_matrix[ll][kk], ll, kk)
                self._widget.Status_Leds_Layout.addWidget(self.graph_p.status_led_matrix[ll][kk], ll, kk)

        # scrollarea.setWidgetResizable(False)
        #self._widget.Foot_Left_Scroll.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
        #self._widget.Foot_Left_Scroll.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.blink_cntr = 0
        self.binary_data=[]
        stop_flag = threading.Event()
        self.timer_thread = TimerThread(stop_flag)
        self.timer_thread.update.connect(self.update_gui_screen)
        self.timer_thread.start()
         #self.refresh_loop()
    def shutdown_plugin(self):
        # TODO unregister all publishers here
        pass
    def save_settings(self, plugin_settings, instance_settings):

        # TODO save intrinsic configuration, usually using:
        # instance_settings.set_value(k, v)
        self.save_controls()
        pass
    def restore_settings(self, plugin_settings, instance_settings):
        print('restore controls')
        self.restore_controls()
        # TODO restore intrinsic configuration, usually using:
        # v = instance_settings.value(k)
        pass
    def _manage_button_rosbag_open(self):

        self.rbg.reset_data()
        self.rbg.manage_file_open_button_clicked()
	
        self._widget.Label_Rosbag_File_Path.setText(self.rbg.msg)
        self._widget.Label_Motor_Command.setText(str(len(self.rbg.motor_command_msg_list)))
        self._widget.Label_Sensor_Force.setText(str(len(self.rbg.sensor_force_msg_list)))
        self._widget.Label_Sensor_Range.setText(str(len(self.rbg.sensor_range_msg_list)))
        self._widget.Label_Rosbag_Total.setText(str(self.rbg.cnt_total))
    def update_rosbag_checkboxes(self):

        self.rbg.visualization_enable_motor_command=self._widget.GBox_Rosbag_Motor_Command.isChecked()
        self.rbg.visualization_enable_sensor_force=self._widget.GBox_Rosbag_Sensor_Force.isChecked()
        self.rbg.visualization_enable_sensor_range=self._widget.GBox_Rosbag_Sensor_Range.isChecked()

        self.rbg.visualization_motor_map[0]=self._widget.CheckBox_Rosbag_RHA.isChecked()
        self.rbg.visualization_motor_map[1]=self._widget.CheckBox_Rosbag_RHR.isChecked()
        self.rbg.visualization_motor_map[2]=self._widget.CheckBox_Rosbag_RHF.isChecked()
        self.rbg.visualization_motor_map[3]=self._widget.CheckBox_Rosbag_RK.isChecked()
        self.rbg.visualization_motor_map[4]=self._widget.CheckBox_Rosbag_RAF.isChecked()
        self.rbg.visualization_motor_map[5]=self._widget.CheckBox_Rosbag_RAI.isChecked()
        self.rbg.visualization_motor_map[6]=self._widget.CheckBox_Rosbag_LHA.isChecked()
        self.rbg.visualization_motor_map[7]=self._widget.CheckBox_Rosbag_LHR.isChecked()
        self.rbg.visualization_motor_map[8]=self._widget.CheckBox_Rosbag_LHF.isChecked()
        self.rbg.visualization_motor_map[9]=self._widget.CheckBox_Rosbag_LK.isChecked()
        self.rbg.visualization_motor_map[10]=self._widget.CheckBox_Rosbag_LAF.isChecked()
        self.rbg.visualization_motor_map[11]=self._widget.CheckBox_Rosbag_LAI.isChecked()

        self.rbg.visualization_sensor_force_map[0]=self._widget.CheckBox_Rosbag_RFx.isChecked()
        self.rbg.visualization_sensor_force_map[1]=self._widget.CheckBox_Rosbag_RFy.isChecked()
        self.rbg.visualization_sensor_force_map[2]=self._widget.CheckBox_Rosbag_RFz.isChecked()
        self.rbg.visualization_sensor_force_map[3]=self._widget.CheckBox_Rosbag_RTx.isChecked()
        self.rbg.visualization_sensor_force_map[4]=self._widget.CheckBox_Rosbag_RTy.isChecked()
        self.rbg.visualization_sensor_force_map[5]=self._widget.CheckBox_Rosbag_RTz.isChecked()
        self.rbg.visualization_sensor_force_map[6]=self._widget.CheckBox_Rosbag_LFx.isChecked()
        self.rbg.visualization_sensor_force_map[7]=self._widget.CheckBox_Rosbag_LFy.isChecked()
        self.rbg.visualization_sensor_force_map[8]=self._widget.CheckBox_Rosbag_LFz.isChecked()
        self.rbg.visualization_sensor_force_map[9]=self._widget.CheckBox_Rosbag_LTx.isChecked()
        self.rbg.visualization_sensor_force_map[10]=self._widget.CheckBox_Rosbag_LTy.isChecked()
        self.rbg.visualization_sensor_force_map[11]=self._widget.CheckBox_Rosbag_LTz.isChecked()


        self.rbg.visualization_sensor_range_map[0]=self._widget.CheckBox_Rosbag_RR1.isChecked()
        self.rbg.visualization_sensor_range_map[1]=self._widget.CheckBox_Rosbag_RR2.isChecked()
        self.rbg.visualization_sensor_range_map[2]=self._widget.CheckBox_Rosbag_RR3.isChecked()
        self.rbg.visualization_sensor_range_map[3]=self._widget.CheckBox_Rosbag_RR4.isChecked()
        self.rbg.visualization_sensor_range_map[4]=self._widget.CheckBox_Rosbag_LR1.isChecked()
        self.rbg.visualization_sensor_range_map[5]=self._widget.CheckBox_Rosbag_LR2.isChecked()
        self.rbg.visualization_sensor_range_map[6]=self._widget.CheckBox_Rosbag_LR3.isChecked()
        self.rbg.visualization_sensor_range_map[7]=self._widget.CheckBox_Rosbag_LR4.isChecked()
        return
    def update_json_checkboxes(self):
        self.json_p.checkbox_position = self._widget.CheckBox_JSON_Position.isChecked()
        self.json_p.checkbox_velocity = self._widget.CheckBox_JSON_Velocity.isChecked()
        self.json_p.checkbox_torque = self._widget.CheckBox_JSON_Torque.isChecked()
        self.json_p.checkbox_actuators[0] = self._widget.CheckBox_JSON_RHA.isChecked()
        self.json_p.checkbox_actuators[1] = self._widget.CheckBox_JSON_RHR.isChecked()
        self.json_p.checkbox_actuators[2] = self._widget.CheckBox_JSON_RHF.isChecked()
        self.json_p.checkbox_actuators[3] = self._widget.CheckBox_JSON_RK.isChecked()
        self.json_p.checkbox_actuators[4] = self._widget.CheckBox_JSON_RAF.isChecked()
        self.json_p.checkbox_actuators[5] = self._widget.CheckBox_JSON_RAI.isChecked()
        self.json_p.checkbox_actuators[6] = self._widget.CheckBox_JSON_LHA.isChecked()
        self.json_p.checkbox_actuators[7] = self._widget.CheckBox_JSON_LHR.isChecked()
        self.json_p.checkbox_actuators[8] = self._widget.CheckBox_JSON_LHF.isChecked()
        self.json_p.checkbox_actuators[9] = self._widget.CheckBox_JSON_LK.isChecked()
        self.json_p.checkbox_actuators[10] = self._widget.CheckBox_JSON_LAF.isChecked()
        self.json_p.checkbox_actuators[11] = self._widget.CheckBox_JSON_LAI.isChecked()
        self.json_p.checkbox_ankle_position = self._widget.CheckBox_JSON_Ankle_Position.isChecked()
        self.json_p.checkbox_ft_force = self._widget.CheckBox_JSON_FT_Force.isChecked()
        self.json_p.checkbox_ft_torque = self._widget.CheckBox_JSON_FT_Torque.isChecked()
        self.json_p.checkbox_foot_directions[0] = self._widget.CheckBox_JSON_FT_Rx.isChecked()
        self.json_p.checkbox_foot_directions[1] = self._widget.CheckBox_JSON_FT_Ry.isChecked()
        self.json_p.checkbox_foot_directions[2] = self._widget.CheckBox_JSON_FT_Rz.isChecked()
        self.json_p.checkbox_foot_directions[3] = self._widget.CheckBox_JSON_FT_Lx.isChecked()
        self.json_p.checkbox_foot_directions[4] = self._widget.CheckBox_JSON_FT_Ly.isChecked()
        self.json_p.checkbox_foot_directions[5] = self._widget.CheckBox_JSON_FT_Lz.isChecked()
        self.json_p.checkbox_foot_orientation[0] = self._widget.CheckBox_JSON_RAlpha.isChecked()
        self.json_p.checkbox_foot_orientation[1] = self._widget.CheckBox_JSON_RBeta.isChecked()
        self.json_p.checkbox_foot_orientation[2] = self._widget.CheckBox_JSON_RGamma.isChecked()
        self.json_p.checkbox_foot_orientation[3] = self._widget.CheckBox_JSON_LAlpha.isChecked()
        self.json_p.checkbox_foot_orientation[4] = self._widget.CheckBox_JSON_LBeta.isChecked()
        self.json_p.checkbox_foot_orientation[5] = self._widget.CheckBox_JSON_LGamma.isChecked()
        self.json_p.checkbox_pelvis[0] = self._widget.CheckBox_JSON_Pelvis_X.isChecked()
        self.json_p.checkbox_pelvis[1] = self._widget.CheckBox_JSON_Pelvis_Y.isChecked()
        self.json_p.checkbox_pelvis[2] = self._widget.CheckBox_JSON_Pelvis_Z.isChecked()
        self.json_p.checkbox_pelvis[3] = self._widget.CheckBox_JSON_Pelvis_Alpha.isChecked()
        self.json_p.checkbox_pelvis[4] = self._widget.CheckBox_JSON_Pelvis_Beta.isChecked()
        self.json_p.checkbox_pelvis[5] = self._widget.CheckBox_JSON_Pelvis_Gamma.isChecked()
        self.json_p.checkbox_zmp[0] = self._widget.CheckBox_JSON_ZMP_X.isChecked()
        self.json_p.checkbox_zmp[1] = self._widget.CheckBox_JSON_ZMP_Y.isChecked()
        self.json_p.checkbox_com[0] = self._widget.CheckBox_JSON_COM_X.isChecked()
        self.json_p.checkbox_com[1] = self._widget.CheckBox_JSON_COM_Y.isChecked()
        self.json_p.checkbox_com[2] = self._widget.CheckBox_JSON_COM_Z.isChecked()

        return
    def _manage_button_binary_load(self):

        #clear labels
        self._widget.Label_Binary_File_Path.setText('');
        self._widget.Label_Binary_Motion_Length.setText('0')
        self._widget.Label_Binary_Foot1_Length.setText('0')
        self._widget.Label_Binary_Foot2_Length.setText('0')
        self._widget.Label_Binary_Nrelease.setText('0')
        self._widget.Label_Binary_Ts.setText('0')
        self._widget.Label_Binary_Delta_z.setText('0')
        self._widget.Label_Binary_Sensor_Thr.setText('0')
        self._widget.Label_Binary_Tsf.setText('0')
        # manage scroll area
        wdj = self.graph_p.create_scroll_widget([])
        self._widget.Foot_Left_Scroll.setWidget(wdj)
        self._widget.Foot_Right_Scroll.setWidget(wdj)
        root = Tkinter.Tk()
        root.withdraw()
        root.update()
        ftypes = [
            ('binary files', '*.bin'),
        ]
        f = tkFileDialog.askopenfilename(initialdir=self.a_save.r_cfg.binary_folder_path, filetypes=ftypes)
        if f:
            self.a_save.w_cfg.binary_folder_path = os.path.dirname(f)
            bn = binary_process.ExoBinaryProcess(f)
            self.binary_data=bn.manage_open_binary_button_clicked()
            if self.binary_data == -1:
                print('no valid binary data')
            else:
                print('binary date decode succeed')
                #update labels
                self._widget.Label_Binary_File_Path.setText(f);
                self._widget.Label_Binary_Motion_Length.setText(str(self.binary_data.motion_len))
                self._widget.Label_Binary_Foot1_Length.setText(str(self.binary_data.foot1_edge_len))
                self._widget.Label_Binary_Foot2_Length.setText(str(self.binary_data.foot2_edge_len))
                self._widget.Label_Binary_Nrelease.setText(str(self.binary_data.n_release))
                self._widget.Label_Binary_Ts.setText(str(self.binary_data.ts))
                self._widget.Label_Binary_Delta_z.setText(str(self.binary_data.delta_z))
                self._widget.Label_Binary_Sensor_Thr.setText(str(self.binary_data.sensor_thr))
                self._widget.Label_Binary_Tsf.setText(str(self.binary_data.t_sf))
                wdj = self.graph_p.create_scroll_widget(self.binary_data.sensor_edge_foot2)
                self._widget.Foot_Left_Scroll.setWidget(wdj)
                wdj = self.graph_p.create_scroll_widget(self.binary_data.sensor_edge_foot1)
                self._widget.Foot_Right_Scroll.setWidget(wdj)

        root.destroy()
        return
    def _manage_button_binary_make(self):
        # check the existance of json data
        if len(self.json_p.json_data.Motion_Position) == 0:
            easygui.msgbox('there is no json data to convert', title="error")
        else:
            ftypes = [
                ('binary files', '*.bin'),
            ]
            #get json file name and propose a binary file name
            jfnam=os.path.basename(self.json_p.file_path)
            fnam=os.path.splitext(jfnam)[0]+'.bin'

            f = tkFileDialog.asksaveasfile(mode='w', defaultextension=".bin" , filetypes=ftypes,initialdir=self.a_save.r_cfg.binary_folder_path,initialfile=fnam)
            if f:
                self.a_save.w_cfg.binary_folder_path=os.path.dirname(f.name)
                bn=binary_process.ExoBinaryProcess(f.name)
                bn.manage_make_binary_button_clicked(self.json_p.json_data)
        return
    def _manage_button_json_plot(self):
        if len(self.json_p.json_data.Motion_Position) == 0:
            easygui.msgbox('there is no json data to draw', title="error")
        else:
            self.update_json_checkboxes()
            self.json_p.plot_json_data()
    def _manage_button_rosbag_plot(self):
        # process plot setting
        res=self.process_plot_setting()
        if res=='ok':
            self.update_rosbag_checkboxes()
            self.rbg.close_plot()
            self.rbg.plot()
            self._widget.Button_Rosbag_Plot_Close.setEnabled(True)
        else:
            easygui.msgbox(res, title="error")
    def _manage_button_json_load(self):
        self.json_p.manage_file_load_button_clicked()
        self._widget.Label_Json_File_Path.setText(self.json_p.file_path)
        self._widget.Label_Json_List_Length.setText(str(len(self.json_p.json_data.Motion_Position)))
        self._widget.Label_Status_Source_Path.setText(self.json_p.file_path)
        self._widget.Label_Status_Sample_Num.setText(str(len(self.json_p.json_data.Motion_Position)))
        self._widget.Label_Status_IP_Time.setText(str(self.json_p.json_data.Interpolation_Time_ms))
        #enable screen refresh flag to update starting position
        self.exo_p.screen_refresh_flag = True

    def _manage_button_rosbag_plot_close(self):
        self.rbg.close_plot()
        self._widget.Button_Rosbag_Plot_Close.setEnabled(False)

    def process_plot_setting(self):
        #check the number of records if the groupbox is checked
        checked_gbox=0
        if self._widget.GBox_Rosbag_Motor_Command.isChecked():
            checked_gbox=checked_gbox+1
            #check the number of recorded data
            if len(self.rbg.motor_command_msg_list)==0:
                return 'there is no motor command data to draw'


        if self._widget.GBox_Rosbag_Sensor_Force.isChecked():
                checked_gbox=checked_gbox+1
        if self._widget.GBox_Rosbag_Sensor_Range.isChecked():
                checked_gbox=checked_gbox+1

        if checked_gbox==0:
            return 'Nothing is selected'
        return 'ok'

    def restore_controls(self):
        # update rosbag controls
        self._widget.GBox_Rosbag_Motor_Command.setChecked(self.a_save.r_cfg.rosbag_motor_cammands_enable)
        self._widget.GBox_Rosbag_Sensor_Force.setChecked(self.a_save.r_cfg.rosbag_sensor_force_enable)
        self._widget.GBox_Rosbag_Sensor_Range.setChecked(self.a_save.r_cfg.rosbag_sensor_range_enable)

        self._widget.CheckBox_Rosbag_RHA.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[0])
        self._widget.CheckBox_Rosbag_RHR.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[1])
        self._widget.CheckBox_Rosbag_RHF.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[2])
        self._widget.CheckBox_Rosbag_RK.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[3])
        self._widget.CheckBox_Rosbag_RAF.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[4])
        self._widget.CheckBox_Rosbag_RAI.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[5])
        self._widget.CheckBox_Rosbag_LHA.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[6])
        self._widget.CheckBox_Rosbag_LHR.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[7])
        self._widget.CheckBox_Rosbag_LHF.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[8])
        self._widget.CheckBox_Rosbag_LK.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[9])
        self._widget.CheckBox_Rosbag_LAF.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[10])
        self._widget.CheckBox_Rosbag_LAI.setChecked(self.a_save.r_cfg.rosbag_motor_command_map[11])

        self._widget.CheckBox_Rosbag_RFx.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[0])
        self._widget.CheckBox_Rosbag_RFy.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[1])
        self._widget.CheckBox_Rosbag_RFz.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[2])
        self._widget.CheckBox_Rosbag_RTx.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[3])
        self._widget.CheckBox_Rosbag_RTy.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[4])
        self._widget.CheckBox_Rosbag_RTz.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[5])
        self._widget.CheckBox_Rosbag_LFx.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[6])
        self._widget.CheckBox_Rosbag_LFy.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[7])
        self._widget.CheckBox_Rosbag_LFz.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[8])
        self._widget.CheckBox_Rosbag_LTx.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[9])
        self._widget.CheckBox_Rosbag_LTy.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[10])
        self._widget.CheckBox_Rosbag_LTz.setChecked(self.a_save.r_cfg.rosbag_sensor_force_map[11])

        self._widget.CheckBox_Rosbag_RR1.setChecked(self.a_save.r_cfg.rosbag_sensor_range_map[0])
        self._widget.CheckBox_Rosbag_RR2.setChecked(self.a_save.r_cfg.rosbag_sensor_range_map[1])
        self._widget.CheckBox_Rosbag_RR3.setChecked(self.a_save.r_cfg.rosbag_sensor_range_map[2])
        self._widget.CheckBox_Rosbag_RR4.setChecked(self.a_save.r_cfg.rosbag_sensor_range_map[3])
        self._widget.CheckBox_Rosbag_LR1.setChecked(self.a_save.r_cfg.rosbag_sensor_range_map[4])
        self._widget.CheckBox_Rosbag_LR2.setChecked(self.a_save.r_cfg.rosbag_sensor_range_map[5])
        self._widget.CheckBox_Rosbag_LR3.setChecked(self.a_save.r_cfg.rosbag_sensor_range_map[6])
        self._widget.CheckBox_Rosbag_LR4.setChecked(self.a_save.r_cfg.rosbag_sensor_range_map[7])

        self.rbg.filepath=self.a_save.r_cfg.rosbag_file_path
        self.json_p.folder_path=self.a_save.r_cfg.json_file_path

        #update json controls
        self._widget.CheckBox_JSON_Position.setChecked(self.a_save.r_cfg.jsonplot_position)
        self._widget.CheckBox_JSON_Velocity.setChecked(self.a_save.r_cfg.jsonplot_velocity)
        self._widget.CheckBox_JSON_Torque.setChecked(self.a_save.r_cfg.jsonplot_torque)
        self._widget.CheckBox_JSON_RHA.setChecked(self.a_save.r_cfg.jsonplot_actuators[0])
        self._widget.CheckBox_JSON_RHR.setChecked(self.a_save.r_cfg.jsonplot_actuators[1])
        self._widget.CheckBox_JSON_RHF.setChecked(self.a_save.r_cfg.jsonplot_actuators[2])
        self._widget.CheckBox_JSON_RK.setChecked(self.a_save.r_cfg.jsonplot_actuators[3])
        self._widget.CheckBox_JSON_RAF.setChecked(self.a_save.r_cfg.jsonplot_actuators[4])
        self._widget.CheckBox_JSON_RAI.setChecked(self.a_save.r_cfg.jsonplot_actuators[5])
        self._widget.CheckBox_JSON_LHA.setChecked(self.a_save.r_cfg.jsonplot_actuators[6])
        self._widget.CheckBox_JSON_LHR.setChecked(self.a_save.r_cfg.jsonplot_actuators[7])
        self._widget.CheckBox_JSON_LHF.setChecked(self.a_save.r_cfg.jsonplot_actuators[8])
        self._widget.CheckBox_JSON_LK.setChecked(self.a_save.r_cfg.jsonplot_actuators[9])
        self._widget.CheckBox_JSON_LAF.setChecked(self.a_save.r_cfg.jsonplot_actuators[10])
        self._widget.CheckBox_JSON_LAI.setChecked(self.a_save.r_cfg.jsonplot_actuators[11])
        self._widget.CheckBox_JSON_Ankle_Position.setChecked(self.a_save.r_cfg.jsonplot_ankle_position)
        self._widget.CheckBox_JSON_FT_Force.setChecked(self.a_save.r_cfg.jsonplot_ft_force)
        self._widget.CheckBox_JSON_FT_Torque.setChecked(self.a_save.r_cfg.jsonplot_ft_torque)
        self._widget.CheckBox_JSON_FT_Rx.setChecked(self.a_save.r_cfg.jsonplot_foot_directions[0])
        self._widget.CheckBox_JSON_FT_Ry.setChecked(self.a_save.r_cfg.jsonplot_foot_directions[1])
        self._widget.CheckBox_JSON_FT_Rz.setChecked(self.a_save.r_cfg.jsonplot_foot_directions[2])
        self._widget.CheckBox_JSON_FT_Lx.setChecked(self.a_save.r_cfg.jsonplot_foot_directions[3])
        self._widget.CheckBox_JSON_FT_Ly.setChecked(self.a_save.r_cfg.jsonplot_foot_directions[4])
        self._widget.CheckBox_JSON_FT_Lz.setChecked(self.a_save.r_cfg.jsonplot_foot_directions[5])
        self._widget.CheckBox_JSON_RAlpha.setChecked(self.a_save.r_cfg.jsonplot_foot_orientation[0])
        self._widget.CheckBox_JSON_RBeta.setChecked(self.a_save.r_cfg.jsonplot_foot_orientation[1])
        self._widget.CheckBox_JSON_RGamma.setChecked(self.a_save.r_cfg.jsonplot_foot_orientation[2])
        self._widget.CheckBox_JSON_LAlpha.setChecked(self.a_save.r_cfg.jsonplot_foot_orientation[3])
        self._widget.CheckBox_JSON_LBeta.setChecked(self.a_save.r_cfg.jsonplot_foot_orientation[4])
        self._widget.CheckBox_JSON_LGamma.setChecked(self.a_save.r_cfg.jsonplot_foot_orientation[5])
        self._widget.CheckBox_JSON_Pelvis_X.setChecked(self.a_save.r_cfg.jsonplot_pelvis[0])
        self._widget.CheckBox_JSON_Pelvis_Y.setChecked(self.a_save.r_cfg.jsonplot_pelvis[1])
        self._widget.CheckBox_JSON_Pelvis_Z.setChecked(self.a_save.r_cfg.jsonplot_pelvis[2])
        self._widget.CheckBox_JSON_Pelvis_Alpha.setChecked(self.a_save.r_cfg.jsonplot_pelvis[3])
        self._widget.CheckBox_JSON_Pelvis_Beta.setChecked(self.a_save.r_cfg.jsonplot_pelvis[4])
        self._widget.CheckBox_JSON_Pelvis_Gamma.setChecked(self.a_save.r_cfg.jsonplot_pelvis[5])
        self._widget.CheckBox_JSON_ZMP_X.setChecked(self.a_save.r_cfg.jsonplot_zmp[0])
        self._widget.CheckBox_JSON_ZMP_Y.setChecked(self.a_save.r_cfg.jsonplot_zmp[1])
        self._widget.CheckBox_JSON_COM_X.setChecked(self.a_save.r_cfg.jsonplot_com[0])
        self._widget.CheckBox_JSON_COM_Y.setChecked(self.a_save.r_cfg.jsonplot_com[1])
        self._widget.CheckBox_JSON_COM_Z.setChecked(self.a_save.r_cfg.jsonplot_com[2])

        #update exo controls
        self._widget.CheckBox_MotorEnable_RHA.setChecked(self.a_save.r_cfg.exo_motors_enable[0])
        self._widget.CheckBox_MotorEnable_RHR.setChecked(self.a_save.r_cfg.exo_motors_enable[1])
        self._widget.CheckBox_MotorEnable_RHF.setChecked(self.a_save.r_cfg.exo_motors_enable[2])
        self._widget.CheckBox_MotorEnable_RK.setChecked(self.a_save.r_cfg.exo_motors_enable[3])
        self._widget.CheckBox_MotorEnable_RAF.setChecked(self.a_save.r_cfg.exo_motors_enable[4])
        self._widget.CheckBox_MotorEnable_RAI.setChecked(self.a_save.r_cfg.exo_motors_enable[5])
        self._widget.CheckBox_MotorEnable_LHA.setChecked(self.a_save.r_cfg.exo_motors_enable[6])
        self._widget.CheckBox_MotorEnable_LHR.setChecked(self.a_save.r_cfg.exo_motors_enable[7])
        self._widget.CheckBox_MotorEnable_LHF.setChecked(self.a_save.r_cfg.exo_motors_enable[8])
        self._widget.CheckBox_MotorEnable_LK.setChecked(self.a_save.r_cfg.exo_motors_enable[9])
        self._widget.CheckBox_MotorEnable_LAF.setChecked(self.a_save.r_cfg.exo_motors_enable[10])
        self._widget.CheckBox_MotorEnable_LAI.setChecked(self.a_save.r_cfg.exo_motors_enable[11])

        self._widget.Radiobutton_Encocder_ABS.setChecked(self.a_save.r_cfg.exo_abs_encoder_selected)
        self._widget.Radiobutton_Encocder_INC.setChecked(self.a_save.r_cfg.exo_inc_encoder_selected)
        self._widget.Radiobutton_Encocder_Count.setChecked(self.a_save.r_cfg.exo_encoder_count_selected)
        self._widget.Radiobutton_Encocder_Degree.setChecked(self.a_save.r_cfg.exo_angle_degree_selected)
    def save_controls(self):
        #saving rosbag controls
        self.a_save.w_cfg.rosbag_file_path=self.rbg.filepath
        self.a_save.w_cfg.json_file_path=self.json_p.folder_path
        self.a_save.w_cfg.rosbag_motor_cammands_enable=self._widget.GBox_Rosbag_Motor_Command.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_enable=self._widget.GBox_Rosbag_Sensor_Force.isChecked()
        self.a_save.w_cfg.rosbag_sensor_range_enable=self._widget.GBox_Rosbag_Sensor_Range.isChecked()

        self.a_save.w_cfg.rosbag_motor_command_map[0]=self._widget.CheckBox_Rosbag_RHA.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[1]=self._widget.CheckBox_Rosbag_RHR.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[2]=self._widget.CheckBox_Rosbag_RHF.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[3]=self._widget.CheckBox_Rosbag_RK.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[4]=self._widget.CheckBox_Rosbag_RAF.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[5]=self._widget.CheckBox_Rosbag_RAI.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[6]=self._widget.CheckBox_Rosbag_LHA.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[7]=self._widget.CheckBox_Rosbag_LHR.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[8]=self._widget.CheckBox_Rosbag_LHF.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[9]=self._widget.CheckBox_Rosbag_LK.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[10]=self._widget.CheckBox_Rosbag_LAF.isChecked()
        self.a_save.w_cfg.rosbag_motor_command_map[11]=self._widget.CheckBox_Rosbag_LAI.isChecked()

        self.a_save.w_cfg.rosbag_sensor_force_map[0]=self._widget.CheckBox_Rosbag_RFx.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[1]=self._widget.CheckBox_Rosbag_RFy.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[2]=self._widget.CheckBox_Rosbag_RFz.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[3]=self._widget.CheckBox_Rosbag_RTx.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[4]=self._widget.CheckBox_Rosbag_RTy.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[5]=self._widget.CheckBox_Rosbag_RTz.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[6]=self._widget.CheckBox_Rosbag_LFx.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[7]=self._widget.CheckBox_Rosbag_LFy.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[8]=self._widget.CheckBox_Rosbag_LFz.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[9]=self._widget.CheckBox_Rosbag_LTx.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[10]=self._widget.CheckBox_Rosbag_LTy.isChecked()
        self.a_save.w_cfg.rosbag_sensor_force_map[11]=self._widget.CheckBox_Rosbag_LTz.isChecked()

        self.a_save.w_cfg.rosbag_sensor_range_map[0]=self._widget.CheckBox_Rosbag_RR1.isChecked()
        self.a_save.w_cfg.rosbag_sensor_range_map[1]=self._widget.CheckBox_Rosbag_RR2.isChecked()
        self.a_save.w_cfg.rosbag_sensor_range_map[2]=self._widget.CheckBox_Rosbag_RR3.isChecked()
        self.a_save.w_cfg.rosbag_sensor_range_map[3]=self._widget.CheckBox_Rosbag_RR4.isChecked()
        self.a_save.w_cfg.rosbag_sensor_range_map[4]=self._widget.CheckBox_Rosbag_LR1.isChecked()
        self.a_save.w_cfg.rosbag_sensor_range_map[5]=self._widget.CheckBox_Rosbag_LR2.isChecked()
        self.a_save.w_cfg.rosbag_sensor_range_map[6]=self._widget.CheckBox_Rosbag_LR3.isChecked()
        self.a_save.w_cfg.rosbag_sensor_range_map[7]=self._widget.CheckBox_Rosbag_LR4.isChecked()

        #saving json controls
        self.a_save.w_cfg.jsonplot_position = self._widget.CheckBox_JSON_Position.isChecked()
        self.a_save.w_cfg.jsonplot_velocity = self._widget.CheckBox_JSON_Velocity.isChecked()
        self.a_save.w_cfg.jsonplot_torque = self._widget.CheckBox_JSON_Torque.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[0] = self._widget.CheckBox_JSON_RHA.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[1] = self._widget.CheckBox_JSON_RHR.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[2] = self._widget.CheckBox_JSON_RHF.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[3] = self._widget.CheckBox_JSON_RK.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[4] = self._widget.CheckBox_JSON_RAF.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[5] = self._widget.CheckBox_JSON_RAI.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[6] = self._widget.CheckBox_JSON_LHA.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[7] = self._widget.CheckBox_JSON_LHR.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[8] = self._widget.CheckBox_JSON_LHF.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[9] = self._widget.CheckBox_JSON_LK.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[10] = self._widget.CheckBox_JSON_LAF.isChecked()
        self.a_save.w_cfg.jsonplot_actuators[11] = self._widget.CheckBox_JSON_LAI.isChecked()
        self.a_save.w_cfg.jsonplot_ankle_position = self._widget.CheckBox_JSON_Ankle_Position.isChecked()
        self.a_save.w_cfg.jsonplot_ft_force = self._widget.CheckBox_JSON_FT_Force.isChecked()
        self.a_save.w_cfg.jsonplot_ft_torque = self._widget.CheckBox_JSON_FT_Torque.isChecked()
        self.a_save.w_cfg.jsonplot_foot_directions[0] = self._widget.CheckBox_JSON_FT_Rx.isChecked()
        self.a_save.w_cfg.jsonplot_foot_directions[1] = self._widget.CheckBox_JSON_FT_Ry.isChecked()
        self.a_save.w_cfg.jsonplot_foot_directions[2] = self._widget.CheckBox_JSON_FT_Rz.isChecked()
        self.a_save.w_cfg.jsonplot_foot_directions[3] = self._widget.CheckBox_JSON_FT_Lx.isChecked()
        self.a_save.w_cfg.jsonplot_foot_directions[4] = self._widget.CheckBox_JSON_FT_Ly.isChecked()
        self.a_save.w_cfg.jsonplot_foot_directions[5] = self._widget.CheckBox_JSON_FT_Lz.isChecked()
        self.a_save.w_cfg.jsonplot_foot_orientation[0] = self._widget.CheckBox_JSON_RAlpha.isChecked()
        self.a_save.w_cfg.jsonplot_foot_orientation[1] = self._widget.CheckBox_JSON_RBeta.isChecked()
        self.a_save.w_cfg.jsonplot_foot_orientation[2] = self._widget.CheckBox_JSON_RGamma.isChecked()
        self.a_save.w_cfg.jsonplot_foot_orientation[3] = self._widget.CheckBox_JSON_LAlpha.isChecked()
        self.a_save.w_cfg.jsonplot_foot_orientation[4] = self._widget.CheckBox_JSON_LBeta.isChecked()
        self.a_save.w_cfg.jsonplot_foot_orientation[5] = self._widget.CheckBox_JSON_LGamma.isChecked()
        self.a_save.w_cfg.jsonplot_pelvis[0] = self._widget.CheckBox_JSON_Pelvis_X.isChecked()
        self.a_save.w_cfg.jsonplot_pelvis[1] = self._widget.CheckBox_JSON_Pelvis_Y.isChecked()
        self.a_save.w_cfg.jsonplot_pelvis[2] = self._widget.CheckBox_JSON_Pelvis_Z.isChecked()
        self.a_save.w_cfg.jsonplot_pelvis[3] = self._widget.CheckBox_JSON_Pelvis_Alpha.isChecked()
        self.a_save.w_cfg.jsonplot_pelvis[4] = self._widget.CheckBox_JSON_Pelvis_Beta.isChecked()
        self.a_save.w_cfg.jsonplot_pelvis[5] = self._widget.CheckBox_JSON_Pelvis_Gamma.isChecked()
        self.a_save.w_cfg.jsonplot_zmp[0] = self._widget.CheckBox_JSON_ZMP_X.isChecked()
        self.a_save.w_cfg.jsonplot_zmp[1] = self._widget.CheckBox_JSON_ZMP_Y.isChecked()
        self.a_save.w_cfg.jsonplot_com[0] = self._widget.CheckBox_JSON_COM_X.isChecked()
        self.a_save.w_cfg.jsonplot_com[1] = self._widget.CheckBox_JSON_COM_Y.isChecked()
        self.a_save.w_cfg.jsonplot_com[2] = self._widget.CheckBox_JSON_COM_Z.isChecked()

        # saving exo controls
        self.a_save.w_cfg.exo_motors_enable[0] = self._widget.CheckBox_MotorEnable_RHA.isChecked()
        self.a_save.w_cfg.exo_motors_enable[1] = self._widget.CheckBox_MotorEnable_RHR.isChecked()
        self.a_save.w_cfg.exo_motors_enable[2] = self._widget.CheckBox_MotorEnable_RHF.isChecked()
        self.a_save.w_cfg.exo_motors_enable[3] = self._widget.CheckBox_MotorEnable_RK.isChecked()
        self.a_save.w_cfg.exo_motors_enable[4] = self._widget.CheckBox_MotorEnable_RAF.isChecked()
        self.a_save.w_cfg.exo_motors_enable[5] = self._widget.CheckBox_MotorEnable_RAI.isChecked()
        self.a_save.w_cfg.exo_motors_enable[6] = self._widget.CheckBox_MotorEnable_LHA.isChecked()
        self.a_save.w_cfg.exo_motors_enable[7] = self._widget.CheckBox_MotorEnable_LHR.isChecked()
        self.a_save.w_cfg.exo_motors_enable[8] = self._widget.CheckBox_MotorEnable_LHF.isChecked()
        self.a_save.w_cfg.exo_motors_enable[9] = self._widget.CheckBox_MotorEnable_LK.isChecked()
        self.a_save.w_cfg.exo_motors_enable[10] = self._widget.CheckBox_MotorEnable_LAF.isChecked()
        self.a_save.w_cfg.exo_motors_enable[11] = self._widget.CheckBox_MotorEnable_LAI.isChecked()

        self.a_save.w_cfg.exo_abs_encoder_selected = self._widget.Radiobutton_Encocder_ABS.isChecked()
        self.a_save.w_cfg.exo_inc_encoder_selected = self._widget.Radiobutton_Encocder_INC.isChecked()
        self.a_save.w_cfg.exo_encoder_count_selected = self._widget.Radiobutton_Encocder_Count.isChecked()
        self.a_save.w_cfg.exo_angle_degree_selected = self._widget.Radiobutton_Encocder_Degree.isChecked()

        self.a_save.write_to_config_file()
    def _manage_button_footplate_reset(self):
        self.footplates.reset_data()
        self.manage_footplate_graph()
    def _manage_button_footplate_enable(self):
        res=self.service_p.set_footplates_activity(True)
        if  res.is_transmitted:
            print('footplate enable request is transmitted')
        else:
            print('footplate connection is failed')

    def _manage_button_footplate_disable(self):
         res = self.service_p.set_footplates_activity(False)
         if res.is_transmitted:
             print('footplate disable request is transmitted')
         else:
             print('footplate connection is failed')

    def update_gui_screen(self):
        self._widget.Label_Footplate_Cnt.setText(str(len(self.footplates.sensor_ft_msg_list)))

        self._widget.Label_Status_Footplate_Num.setText(str(len(self.footplates.sensor_ft_msg_list)))
        #udpate pdo cntrs
        if self.pdo_p.screen_refresh_flag:
            self._widget.Label_Status_PDO_Tx3_Num.setText(str(len(self.pdo_p.pdo_tx3_list)))
            self._widget.Label_Status_PDO_Tx4_Num.setText(str(len(self.pdo_p.pdo_tx4_list)))
            self.pdo_p.screen_refresh_flag = False
        #update exo parms
        if self.exo_p.screen_refresh_flag:
            for i in range (12):
                # udpate status led matrix
                for j in range (14):
                    if self.exo_p.status_led_map[i][j]:
                        self.graph_p.status_led_matrix[i][j].setVisible(True)
                        self.graph_p.status_led_off_matrix[i][j].setVisible(False)
                    else:
                        self.graph_p.status_led_matrix[i][j].setVisible(False)
                        self.graph_p.status_led_off_matrix[i][j].setVisible(True)
                # update abs and incremental encoder value
                self.graph_p.status_labels_abs[i+1].setText(str(self.exo_p.abs_encoder_cnt[i]))
                self.graph_p.status_labels_inc[i+1].setText(str(self.exo_p.inc_encoder_cnt[i]))

            #update start position value
            if len(self.json_p.json_data.Motion_Position) > 0:
                self.graph_p.status_labels_start[1].setText(str(self.json_p.json_data.Starting_Position.Right_Hip_Abduction))
                self.graph_p.status_labels_start[2].setText(str(self.json_p.json_data.Starting_Position.Right_Hip_Rob))
                self.graph_p.status_labels_start[3].setText(str(self.json_p.json_data.Starting_Position.Right_Hip_Flex))
                self.graph_p.status_labels_start[4].setText(str(self.json_p.json_data.Starting_Position.Right_Knee))
                self.graph_p.status_labels_start[5].setText(str(self.json_p.json_data.Starting_Position.Right_Ankle_Flex))
                self.graph_p.status_labels_start[6].setText(str(self.json_p.json_data.Starting_Position.Right_Ankle_Inversion))
                self.graph_p.status_labels_start[7].setText(str(self.json_p.json_data.Starting_Position.Left_Hip_Abduction))
                self.graph_p.status_labels_start[8].setText(str(self.json_p.json_data.Starting_Position.Left_Hip_Rob))
                self.graph_p.status_labels_start[9].setText(str(self.json_p.json_data.Starting_Position.Left_Hip_Flex))
                self.graph_p.status_labels_start[10].setText(str(self.json_p.json_data.Starting_Position.Left_Knee))
                self.graph_p.status_labels_start[11].setText(str(self.json_p.json_data.Starting_Position.Left_Ankle_Flex))
                self.graph_p.status_labels_start[12].setText(str(self.json_p.json_data.Starting_Position.Left_Ankle_Inversion))
            else:
                for i in range(12):
                    self.graph_p.status_labels_start[i+1].setText(' ')



            self.exo_p.screen_refresh_flag = False

        if (self._widget.CheckBox_ZMP_Autorefresh.isChecked()):
            self.manage_footplate_graph()
        pass

    def manage_footplate_graph(self):
        self.graph_p.make_footplate_ft_scene(self.footplates.last_zmp_x_left,self.footplates.last_zmp_y_left,self.footplates.last_zmp_x_right,self.footplates.last_zmp_y_right)
        self.graph_p.make_footplate_range_scene(self.footplates.last_range_left,self.footplates.last_range_right)
        self._widget.Footplate_ZMP_Graph.setScene(self.graph_p.footplate_ft_scene)
        self._widget.Footplate_Range_Graph.setScene(self.graph_p.footplate_range_scene)
        self._widget.Label_ZMP_X_Right.setText(str(self.footplates.last_zmp_x_right))
        self._widget.Label_ZMP_Y_Right.setText(str(self.footplates.last_zmp_y_right))
        self._widget.Label_ZMP_X_Left.setText(str(self.footplates.last_zmp_x_left))
        self._widget.Label_ZMP_Y_Left.setText(str(self.footplates.last_zmp_y_left))
        self._widget.Label_Range1_Left.setText(str(self.footplates.last_range_left[0]))
        self._widget.Label_Range2_Left.setText(str(self.footplates.last_range_left[1]))
        self._widget.Label_Range3_Left.setText(str(self.footplates.last_range_left[2]))
        self._widget.Label_Range4_Left.setText(str(self.footplates.last_range_left[3]))
        self._widget.Label_Range1_Right.setText(str(self.footplates.last_range_right[0]))
        self._widget.Label_Range2_Right.setText(str(self.footplates.last_range_right[1]))
        self._widget.Label_Range3_Right.setText(str(self.footplates.last_range_right[2]))
        self._widget.Label_Range4_Right.setText(str(self.footplates.last_range_right[3]))

    def _manage_button_refresh_exo(self):
        #call status word service
        res = self.service_p.send_motion_command(1)
        if res.is_transmitted:
            print('status word request is transmitted')
        else:
            print('status word: connection is failed')
        #call abs encoder service
        res = self.service_p.get_encoders_value(1)
        if res.is_transmitted:
            print('abs encoder request is transmitted')
        else:
            print('abs encoder: connection is failed')
        #call inc encoder service
        res = self.service_p.get_encoders_value(0)
        if res.is_transmitted:
            print('inc encoder request is transmitted')
        else:
            print('inc encoder: connection is failed')
        #call current value service
        return
    def _manage_button_motors_on(self):
        map=self.make_robot_map()
        if map == 4095: # work with all motors
            res = self.service_p.send_motion_command(2)
            if res.is_transmitted:
                print('all motors on request is transmitted')
            else:
                print('motion command: connection is failed')
        else:
            res = self.service_p.set_motor(map,True)
            if res.is_transmitted:
                print('motors on request is transmitted')
            else:
                print('motors on: connection is failed')
    def _manage_button_motors_off(self):
        map = self.make_robot_map()
        if map == 4095:  # work with all motors
            res = self.service_p.send_motion_command(3)
            if res.is_transmitted:
                print('all motors off request is transmitted')
            else:
                print('motion command: connection is failed')
        else:
            res = self.service_p.set_motor(map, False)
            if res.is_transmitted:
                print('motors off request is transmitted')
            else:
                print('motors off: connection is failed')
    def _manage_button_reset_node(self):
        ind = self._widget.ComboBox_Reset_Node.currentIndex()
        robot_map = int(math.pow(2, ind))
        res = self.service_p.reset_actuator(robot_map)
        if res.is_transmitted:
            print('reset node request is transmitted')
        else:
            print('reset node: connection is failed')
    def _manage_button_reset_all(self):
        res = self.service_p.reset_actuator(4095)
        if res.is_transmitted:
            print('reset node request is transmitted')
        else:
            print('reset node: connection is failed')
    def _manage_button_calibrate_encoders(self):
        map = self.make_robot_map()
        res = self.service_p.calibrate_encoder(map)
        if res.is_transmitted:
            print('calibrate encoder request is transmitted')
        else:
            print('calibrate encoder: connection is failed')

    def make_robot_map(self):
        outp=0
        if self._widget.CheckBox_MotorEnable_RHA.isChecked():
            outp = outp + 1
        if self._widget.CheckBox_MotorEnable_RHR.isChecked():
            outp = outp + 2
        if self._widget.CheckBox_MotorEnable_RHF.isChecked():
            outp = outp + 4
        if self._widget.CheckBox_MotorEnable_RK.isChecked():
            outp = outp + 8
        if self._widget.CheckBox_MotorEnable_RAF.isChecked():
            outp = outp + 16
        if self._widget.CheckBox_MotorEnable_RAI.isChecked():
            outp = outp + 32
        if self._widget.CheckBox_MotorEnable_LHA.isChecked():
            outp = outp + 64
        if self._widget.CheckBox_MotorEnable_LHR.isChecked():
            outp = outp + 128
        if self._widget.CheckBox_MotorEnable_LHF.isChecked():
            outp = outp + 256
        if self._widget.CheckBox_MotorEnable_LK.isChecked():
            outp = outp + 512
        if self._widget.CheckBox_MotorEnable_LAF.isChecked():
            outp = outp + 1024
        if self._widget.CheckBox_MotorEnable_LAI.isChecked():
            outp = outp + 2048
        return outp

    def _manage_button_gotoposition_rha(self):
        val=self._widget.TextEdit_Position_RHA.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(0,'ABS',self._widget.Radiobutton_Encocder_Count.isChecked(),float(val))
                res = self.service_p.goto_position(1, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(0, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(), float(val))
                res = self.service_p.goto_position(1, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')
        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in RHA', title="error")
            else:
                easygui.msgbox('please enter float value in RHA', title="error")
    def _manage_button_gotoposition_rhr(self):
        val=self._widget.TextEdit_Position_RHR.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(1,'ABS',self._widget.Radiobutton_Encocder_Count.isChecked(),float(val))
                res = self.service_p.goto_position(2, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(1, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(), float(val))
                res = self.service_p.goto_position(2, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in RHR', title="error")
            else:
                easygui.msgbox('please enter float value in RHR', title="error")
    def _manage_button_gotoposition_rhf(self):
        val = self._widget.TextEdit_Position_RHF.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(2, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(4, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(2, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(4, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in RHF', title="error")
            else:
                easygui.msgbox('please enter float value in RHF', title="error")
    def _manage_button_gotoposition_rk(self):
        val = self._widget.TextEdit_Position_RK.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(3, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(8, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(3, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(8, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in RK', title="error")
            else:
                easygui.msgbox('please enter float value in RK', title="error")
    def _manage_button_gotoposition_raf(self):
        val = self._widget.TextEdit_Position_RAF.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(4, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(16, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(4, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(16, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in RAF', title="error")
            else:
                easygui.msgbox('please enter float value in RAF', title="error")
    def _manage_button_gotoposition_rai(self):
        val = self._widget.TextEdit_Position_RAI.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(5, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(32, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(5, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(32, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in RAI', title="error")
            else:
                easygui.msgbox('please enter float value in RAI', title="error")
    def _manage_button_gotoposition_lha(self):
        val = self._widget.TextEdit_Position_LHA.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(6, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(64, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(6, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(64, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in LHA', title="error")
            else:
                easygui.msgbox('please enter float value in LHA', title="error")
    def _manage_button_gotoposition_lhr(self):
        val = self._widget.TextEdit_Position_LHR.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(7, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(128, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(7, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(128, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in LHR', title="error")
            else:
                easygui.msgbox('please enter float value in LHR', title="error")
    def _manage_button_gotoposition_lhf(self):
        val = self._widget.TextEdit_Position_LHF.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(8, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(256, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(8, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(256, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in LHF', title="error")
            else:
                easygui.msgbox('please enter float value in LHF', title="error")
    def _manage_button_gotoposition_lk(self):
        val = self._widget.TextEdit_Position_LK.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(9, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(512, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(9, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(512, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in LK', title="error")
            else:
                easygui.msgbox('please enter float value in LK', title="error")
    def _manage_button_gotoposition_laf(self):
        val = self._widget.TextEdit_Position_LAF.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(10, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(1024, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(10, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(1024, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in LAF', title="error")
            else:
                easygui.msgbox('please enter float value in LAF', title="error")
    def _manage_button_gotoposition_lai(self):
        val = self._widget.TextEdit_Position_LAI.toPlainText()
        if self.check_gotoposition_textbox(val):
            if self._widget.Radiobutton_Encocder_ABS.isChecked():
                self.exo_p.update_gotoposition_buffer(11, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(2048, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

            else:
                self.exo_p.update_gotoposition_buffer(11, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(val))
                res = self.service_p.goto_position(2048, self.exo_p.gotoposition_buffer)
                if res.is_transmitted:
                    print('goto position request is transmitted')
                else:
                    print('gotoposition connection is failed')

        else:
            if self._widget.Radiobutton_Encocder_Count.isChecked():
                easygui.msgbox('please enter integer value in LAI', title="error")
            else:
                easygui.msgbox('please enter float value in LAI', title="error")

    def check_gotoposition_textbox(self,txt):
        if self._widget.Radiobutton_Encocder_Count.isChecked():
            #check if it is fixed point number number
            try:
                val = int(txt)
                return True
            except:
                return False
        else:
            # check if it is fixed point number number
            try:
                val = float(txt)
                return True
            except:
                return False

    def _manage_button_put_encoders(self):
        self._widget.Radiobutton_Encocder_Count.setChecked(True)

        if self._widget.Radiobutton_Encocder_ABS.isChecked():
            self._widget.TextEdit_Position_RHA.setText(str(self.exo_p.abs_encoder_cnt[0]))
            self._widget.TextEdit_Position_RHR.setText(str(self.exo_p.abs_encoder_cnt[1]))
            self._widget.TextEdit_Position_RHF.setText(str(self.exo_p.abs_encoder_cnt[2]))
            self._widget.TextEdit_Position_RK.setText(str(self.exo_p.abs_encoder_cnt[3]))
            self._widget.TextEdit_Position_RAF.setText(str(self.exo_p.abs_encoder_cnt[4]))
            self._widget.TextEdit_Position_RAI.setText(str(self.exo_p.abs_encoder_cnt[5]))
            self._widget.TextEdit_Position_LHA.setText(str(self.exo_p.abs_encoder_cnt[6]))
            self._widget.TextEdit_Position_LHR.setText(str(self.exo_p.abs_encoder_cnt[7]))
            self._widget.TextEdit_Position_LHF.setText(str(self.exo_p.abs_encoder_cnt[8]))
            self._widget.TextEdit_Position_LK.setText(str(self.exo_p.abs_encoder_cnt[9]))
            self._widget.TextEdit_Position_LAF.setText(str(self.exo_p.abs_encoder_cnt[10]))
            self._widget.TextEdit_Position_LAI.setText(str(self.exo_p.abs_encoder_cnt[11]))
        else:
            self._widget.TextEdit_Position_RHA.setText(str(self.exo_p.inc_encoder_cnt[0]))
            self._widget.TextEdit_Position_RHR.setText(str(self.exo_p.inc_encoder_cnt[1]))
            self._widget.TextEdit_Position_RHF.setText(str(self.exo_p.inc_encoder_cnt[2]))
            self._widget.TextEdit_Position_RK.setText(str(self.exo_p.inc_encoder_cnt[3]))
            self._widget.TextEdit_Position_RAF.setText(str(self.exo_p.inc_encoder_cnt[4]))
            self._widget.TextEdit_Position_RAI.setText(str(self.exo_p.inc_encoder_cnt[5]))
            self._widget.TextEdit_Position_LHA.setText(str(self.exo_p.inc_encoder_cnt[6]))
            self._widget.TextEdit_Position_LHR.setText(str(self.exo_p.inc_encoder_cnt[7]))
            self._widget.TextEdit_Position_LHF.setText(str(self.exo_p.inc_encoder_cnt[8]))
            self._widget.TextEdit_Position_LK.setText(str(self.exo_p.inc_encoder_cnt[9]))
            self._widget.TextEdit_Position_LAF.setText(str(self.exo_p.inc_encoder_cnt[10]))
            self._widget.TextEdit_Position_LAI.setText(str(self.exo_p.inc_encoder_cnt[11]))

    def _manage_button_put_home(self):
        self._widget.TextEdit_Position_RHA.setText('0')
        self._widget.TextEdit_Position_RHR.setText('0')
        self._widget.TextEdit_Position_RHF.setText('0')
        self._widget.TextEdit_Position_RK.setText('0')
        self._widget.TextEdit_Position_RAF.setText('0')
        self._widget.TextEdit_Position_RAI.setText('0')
        self._widget.TextEdit_Position_LHA.setText('0')
        self._widget.TextEdit_Position_LHR.setText('0')
        self._widget.TextEdit_Position_LHF.setText('0')
        self._widget.TextEdit_Position_LK.setText('0')
        self._widget.TextEdit_Position_LAF.setText('0')
        self._widget.TextEdit_Position_LAI.setText('0')

    def _manage_button_put_start(self):
        self._widget.Radiobutton_Encocder_ABS.setChecked(True)
        self._widget.Radiobutton_Encocder_Degree.setChecked(True)

        self._widget.TextEdit_Position_RHA.setText(str(self.exo_p.motion_startig_position[0]))
        self._widget.TextEdit_Position_RHR.setText(str(self.exo_p.motion_startig_position[1]))
        self._widget.TextEdit_Position_RHF.setText(str(self.exo_p.motion_startig_position[2]))
        self._widget.TextEdit_Position_RK.setText(str(self.exo_p.motion_startig_position[3]))
        self._widget.TextEdit_Position_RAF.setText(str(self.exo_p.motion_startig_position[4]))
        self._widget.TextEdit_Position_RAI.setText(str(self.exo_p.motion_startig_position[5]))
        self._widget.TextEdit_Position_LHA.setText(str(self.exo_p.motion_startig_position[6]))
        self._widget.TextEdit_Position_LHR.setText(str(self.exo_p.motion_startig_position[7]))
        self._widget.TextEdit_Position_LHF.setText(str(self.exo_p.motion_startig_position[8]))
        self._widget.TextEdit_Position_LK.setText(str(self.exo_p.motion_startig_position[9]))
        self._widget.TextEdit_Position_LAF.setText(str(self.exo_p.motion_startig_position[10]))
        self._widget.TextEdit_Position_LAI.setText(str(self.exo_p.motion_startig_position[11]))

    def _manage_button_goall(self):
        #step 1 check contents of texedit boxes
        valarray = []
        valarray.append(self._widget.TextEdit_Position_RHA.toPlainText())
        valarray.append(self._widget.TextEdit_Position_RHR.toPlainText())
        valarray.append(self._widget.TextEdit_Position_RHF.toPlainText())
        valarray.append(self._widget.TextEdit_Position_RK.toPlainText())
        valarray.append(self._widget.TextEdit_Position_RAF.toPlainText())
        valarray.append(self._widget.TextEdit_Position_RAI.toPlainText())
        valarray.append(self._widget.TextEdit_Position_LHA.toPlainText())
        valarray.append(self._widget.TextEdit_Position_LHR.toPlainText())
        valarray.append(self._widget.TextEdit_Position_LHF.toPlainText())
        valarray.append(self._widget.TextEdit_Position_LK.toPlainText())
        valarray.append(self._widget.TextEdit_Position_LAF.toPlainText())
        valarray.append(self._widget.TextEdit_Position_LAI.toPlainText())
        for i in range(12):
            if not self.check_gotoposition_textbox(valarray[i]):
                easygui.msgbox('please enter correct number in textboxes row '+str(i+1), title="error")
                return
        # step 3 make robot map
        robot_map = self.make_robot_map()
        # step 2 update robot buffer
        if self._widget.Radiobutton_Encocder_ABS.isChecked():
            for i in range(12):
                self.exo_p.update_gotoposition_buffer(i, 'ABS', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(valarray[i]))
            res = self.service_p.goto_position(robot_map, self.exo_p.gotoposition_buffer)
            if res.is_transmitted:
                print('goto position request is transmitted')
            else:
                print('gotoposition connection is failed')
        else:
            for i in range(12):
                self.exo_p.update_gotoposition_buffer(i, 'INC', self._widget.Radiobutton_Encocder_Count.isChecked(),
                                                      float(valarray[i]))
            res = self.service_p.goto_position(robot_map, self.exo_p.gotoposition_buffer)
            if res.is_transmitted:
                print('goto position request is transmitted')
            else:
                print('gotoposition connection is failed')



    def _manage_button_motion_load(self):
        print('button motion load - backendshould be developed')

    def _manage_button_motion_save_logs(self):
        print('button motion save loges - backendshould be developed')

    def _manage_button_motion_reset_logs(self):
        print('button motion reset logs - backendshould be developed')

    def _manage_button_goto_home(self):
        # call status word service
        res = self.service_p.send_motion_command(4)
        if res.is_transmitted:
            print('goto home request is transmitted')
        else:
            print('motion command: connection is failed')

    def _manage_button_goto_start(self):
        # call status word service
        res = self.service_p.send_motion_command(5)
        if res.is_transmitted:
            print('goto start request is transmitted')
        else:
            print('motion command: connection is failed')

    def _manage_button_start_motion(self):
        # call status word service
        res = self.service_p.send_motion_command(6)
        if res.is_transmitted:
            print('start motion request is transmitted')
        else:
            print('motion command: connection is failed')

    #def trigger_configuration(self):
        # Comment in to signal that the plugin has a way to configure
        # This will enable a setting button (gear icon) in each dock widget title bar
        # Usually used to open a modal configuration dialog


