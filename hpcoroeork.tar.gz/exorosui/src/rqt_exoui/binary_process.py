import struct

class ExoBinaryProcess(object):
    def __init__(self,filepath):

        self.file_path = filepath

    def manage_make_binary_button_clicked(self,json_data):
        print ('generating binary file')
        fout = open(self.file_path, 'wb')
        fout.write(struct.pack('B', 45))
        fout.close()
        return
    def read_uint32_from_stream(self,inp):
        try:
            data=inp.read(4)
            outp=struct.Struct('=I').unpack_from(data)
            return outp[0]
        except:
            return 0
    def read_double_from_stream(self,inp):
        try:
            data=inp.read(8)
            outp=struct.Struct('=d').unpack_from(data)
            return outp[0]
        except:
            return 0
    def read_uint8_from_stream(self,inp):
        try:
            data=inp.read(1)
            outp=struct.Struct('=B').unpack_from(data)
            return outp[0]
        except:
            return 0
    def manage_open_binary_button_clicked(self):
        return self.decode_binary_file()

    def decode_binary_file(self):
        fin = open(self.file_path, 'rb')
        # read the header
        hdr = self.read_uint32_from_stream(fin)
        if hdr != 305419896:
            return -1

        # define output class
        class Sample:
            motion_len = 0
            foot1_edge_len = 0
            foot2_edge_len = 0
            n_release = 0
            release_inverse_matrix = []
            ts = 0
            delta_z = 0
            sensor_thr = 0
            t_sf = 0

            z_foot1_preplanned = []
            z_foot2_preplanned = []
            dz_foot1_preplanned = []
            dz_foot2_preplanned = []
            ddz_foot1_preplanned = []
            ddz_foot2_preplanned = []

            z_foot1_preplanned_wc = []
            z_foot2_preplanned_wc = []
            dz_foot1_preplanned_wc = []
            dz_foot2_preplanned_wc = []
            ddz_foot1_preplanned_wc = []
            ddz_foot2_preplanned_wc = []

            pelvis_preplanned_x = []
            pelvis_preplanned_y = []
            pelvis_preplanned_z = []
            pelvis_preplanned_alpha = []
            pelvis_preplanned_beta = []
            pelvis_preplanned_gamma = []

            x_foot1_preplanned = []
            x_foot2_preplanned = []
            y_foot1_preplanned = []
            y_foot2_preplanned = []

            alpha_foot1_preplanned = []
            alpha_foot2_preplanned = []
            beta_foot1_preplanned = []
            beta_foot2_preplanned = []
            gamma_foot1_preplanned = []
            gamma_foot2_preplanned = []

            q_preplanned_right = []
            q_preplanned_left = []

            sensor_switch1 = []
            sensor_switch2 = []
            foot1_advanced_check_enable = []
            foot2_advanced_check_enable = []
            foot1_retard_check_enable = []
            foot2_retard_check_enable = []
            step_foot1 = []
            step_foot2 = []
            sensor_edge_foot1 = []
            foot1_edge = []
            sensor_edge_foot2 = []
            foot2_edge = []

        outp = Sample()
        # read motion len
        outp.motion_len = self.read_uint32_from_stream(fin)
        # read feet edges
        outp.foot1_edge_len = self.read_uint32_from_stream(fin)
        outp.foot2_edge_len = self.read_uint32_from_stream(fin)
        # read n_release
        outp.n_release = self.read_uint32_from_stream(fin)
        for cnt in range(36):
            outp.release_inverse_matrix.append(self.read_double_from_stream(fin))
        outp.ts=self.read_double_from_stream(fin)
        outp.delta_z = self.read_double_from_stream(fin)
        outp.sensor_thr = self.read_double_from_stream(fin)
        outp.t_sf = self.read_double_from_stream(fin)
        #reading preplanned motion parameters
        for cnt in range(outp.motion_len):
            outp.z_foot1_preplanned.append(self.read_double_from_stream(fin))
            outp.z_foot2_preplanned.append(self.read_double_from_stream(fin))
            outp.dz_foot1_preplanned.append(self.read_double_from_stream(fin))
            outp.dz_foot2_preplanned.append(self.read_double_from_stream(fin))
            outp.ddz_foot1_preplanned.append(self.read_double_from_stream(fin))
            outp.ddz_foot2_preplanned.append(self.read_double_from_stream(fin))

 # TODO it should be activated in the final binary decoder
 #           outp.z_foot1_preplanned_wc.append(self.read_double_from_stream(fin))
 #           outp.z_foot2_preplanned_wc.append(self.read_double_from_stream(fin))
 #           outp.dz_foot1_preplanned_wc.append(self.read_double_from_stream(fin))
 #           outp.dz_foot2_preplanned_wc.append(self.read_double_from_stream(fin))
 #           outp.ddz_foot1_preplanned_wc.append(self.read_double_from_stream(fin))
 #           outp.ddz_foot2_preplanned_wc.append(self.read_double_from_stream(fin))

            outp.pelvis_preplanned_x.append(self.read_double_from_stream(fin))
            outp.pelvis_preplanned_y.append(self.read_double_from_stream(fin))
            outp.pelvis_preplanned_z.append(self.read_double_from_stream(fin))
            outp.pelvis_preplanned_alpha.append(self.read_double_from_stream(fin))
            outp.pelvis_preplanned_beta.append(self.read_double_from_stream(fin))
            outp.pelvis_preplanned_gamma.append(self.read_double_from_stream(fin))

            outp.x_foot1_preplanned.append(self.read_double_from_stream(fin))
            outp.x_foot2_preplanned.append(self.read_double_from_stream(fin))
            outp.y_foot1_preplanned.append(self.read_double_from_stream(fin))
            outp.y_foot2_preplanned.append(self.read_double_from_stream(fin))

            outp.alpha_foot1_preplanned.append(self.read_double_from_stream(fin))
            outp.alpha_foot2_preplanned.append(self.read_double_from_stream(fin))
            outp.beta_foot1_preplanned.append(self.read_double_from_stream(fin))
            outp.beta_foot2_preplanned.append(self.read_double_from_stream(fin))
            outp.gamma_foot1_preplanned.append(self.read_double_from_stream(fin))
            outp.gamma_foot2_preplanned.append(self.read_double_from_stream(fin))

            for cnt2 in range(6):
                outp.q_preplanned_right.append(self.read_double_from_stream(fin))
            for cnt2 in range(6):
                outp.q_preplanned_left.append(self.read_double_from_stream(fin))

            outp.sensor_switch1.append(self.read_uint8_from_stream(fin))
            outp.sensor_switch2.append(self.read_uint8_from_stream(fin))
            outp.foot1_advanced_check_enable.append(self.read_uint8_from_stream(fin))
            outp.foot2_advanced_check_enable.append(self.read_uint8_from_stream(fin))
            outp.foot1_retard_check_enable.append(self.read_uint8_from_stream(fin))
            outp.foot2_retard_check_enable.append(self.read_uint8_from_stream(fin))
            outp.step_foot1.append(self.read_uint8_from_stream(fin))
            outp.step_foot2.append(self.read_uint8_from_stream(fin))

        #reading foot edges
        for cnt in range(outp.foot1_edge_len):
            outp.sensor_edge_foot1.append(self.read_uint32_from_stream(fin))
            outp.foot1_edge.append(self.read_uint32_from_stream(fin))

        for cnt in range(outp.foot2_edge_len):
            outp.sensor_edge_foot2.append(self.read_uint32_from_stream(fin))
            outp.foot2_edge.append(self.read_uint32_from_stream(fin))
        footer=self.read_uint32_from_stream(fin)
        fin.close()
        if footer == 2271560481:
            return outp
        else:
            return -1
