import rospy
import sys
from exo_msgs.srv import GetConnection
from exo_msgs.srv import FootplateCommand
from exo_msgs.srv import CalibrateINCEncoder
from exo_msgs.srv import GetEncoders
from exo_msgs.srv import MotionCommand
from exo_msgs.srv import GotoPosition
from exo_msgs.srv import ResetNode
from exo_msgs.srv import SDOPacketRead
from exo_msgs.srv import SDOPacketWrite
from exo_msgs.srv import SetMotor

class ServiceProcess(object):
    def __int__(self):

        return

    def get_connection_status(self):
        try:
            rospy.wait_for_service('/robot_interface_node/get_connection')
            get_connection = rospy.ServiceProxy('/robot_interface_node/get_connection', GetConnection)
            resp = get_connection()
            return resp
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return False

    def set_footplates_activity(self,enable):
        try:
            rospy.wait_for_service('/robot_interface_node/footplate_command')
            footplate = rospy.ServiceProxy('/robot_interface_node/footplate_command', FootplateCommand)
            resp = footplate(enable)
            return resp
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return False

    def send_motion_command(self,cmd):
        try:
            rospy.wait_for_service('/robot_interface_node/motion_command')
            mo_command = rospy.ServiceProxy('/robot_interface_node/motion_command', MotionCommand)
            resp = mo_command(cmd)
            return resp
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return False

    def get_encoders_value(self,encoder_type):
        try:
            rospy.wait_for_service('/robot_interface_node/get_encoders')
            get_enc = rospy.ServiceProxy('/robot_interface_node/get_encoders', GetEncoders)
            resp = get_enc(encoder_type)
            return resp
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return False

    def set_motor(self,robot_map,enable):
        try:
            rospy.wait_for_service('/robot_interface_node/set_motor')
            set_m = rospy.ServiceProxy('/robot_interface_node/set_motor', SetMotor)
            resp = set_m(robot_map,enable)
            return resp
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return False

    def reset_actuator(self,robot_map):
        try:
            rospy.wait_for_service('/robot_interface_node/reset_node')
            reset_n = rospy.ServiceProxy('/robot_interface_node/reset_node',ResetNode)
            resp = reset_n(robot_map)
            return resp

        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return False

    def calibrate_encoder(self,robot_map):
        try:
            rospy.wait_for_service('/robot_interface_node/calibrate_encoder')
            calibrate_n=rospy.ServiceProxy('/robot_interface_node/calibrate_encoder',CalibrateINCEncoder)
            resp=calibrate_n(robot_map)
            return resp
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return False
    def goto_position(self, robot_map, encoders_vector):
        try:
            rospy.wait_for_service('/robot_interface_node/goto_position')
            goto_p = rospy.ServiceProxy('/robot_interface_node/goto_position', GotoPosition)

            resp = goto_p(robot_map,encoders_vector)
            return resp
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return False




    def sdo_read(self,node_id,object,subindex):
        try:
            rospy.wait_for_service('/robot_interface_node/sdo_packet_read')
            sdo_r=rospy.ServiceProxy('/robot_interface_node/sdo_packet_read',SDOPacketRead)
            resp=sdo_r(node_id,object,subindex)
            return resp
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return False

    def sdo_write(self,node_id,object,subindex,data):
        try:
            rospy.wait_for_service('/robot_interface_node/sdo_packet_write')
            sdo_w=rospy.ServiceProxy('/robot_interface_node/sdo_packet_write',SDOPacketWrite)
            resp=sdo_w(node_id,object,subindex,data)
            return resp
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return False

