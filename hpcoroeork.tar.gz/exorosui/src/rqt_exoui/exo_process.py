import rospy
import sys
import struct
from exo_msgs.msg import ExoResponse

class ExoProcess(object):
    def __init__(self):
        self.sub = rospy.Subscriber("/robot/exoresponse", ExoResponse, self.callback_exo_response)
        self.status_led_map = self.create_status_led_map()
        self.cmd_dictionary = {}
        self.creat_cmd_dictionary()
        self.abs_encoder_cnt = []
        self.inc_encoder_cnt = []
        self.gotoposition_buffer = []
        self.motion_startig_position = []
        self.abs_encoder_zero_offset = []
        for i in range(12):
            self.abs_encoder_cnt.append(0)
            self.inc_encoder_cnt.append(0)
            self.gotoposition_buffer.append(0)
            self.motion_startig_position.append(0.0)

        self.abs_encoder_zero_offset.append(0)       #offset for rha
        self.abs_encoder_zero_offset.append(0)       #offset for rhr
        self.abs_encoder_zero_offset.append(0)       #offset for rhf
        self.abs_encoder_zero_offset.append(0)       #offset for rk
        self.abs_encoder_zero_offset.append(0)       #offset for raf
        self.abs_encoder_zero_offset.append(0)       #offset for rai
        self.abs_encoder_zero_offset.append(0)       #offset for lha
        self.abs_encoder_zero_offset.append(0)       #offset for lhr
        self.abs_encoder_zero_offset.append(0)       #offset for lhf
        self.abs_encoder_zero_offset.append(0)       #offset for lk
        self.abs_encoder_zero_offset.append(0)       #offset for laf
        self.abs_encoder_zero_offset.append(0)       #offset for lai

        self.incremantal_encoder_loop_count = 3456
        self.absolute_encoder_loop_count = 16384
        self.error_acceptable_tolerance = 10
        self.gearhead_ratio = 101

        self.screen_refresh_flag = True


        return
    def callback_exo_response(self,msg):
        r_cmd = msg.response_id
        r_payload = msg.response_payload
        self.process_response(r_cmd,r_payload)
        self.screen_refresh_flag = True

    def create_status_led_map(self):
        outp =[]
        for ll in range (12):
            rr=[]
            for kk in range (14):
                rr.append(False)
            outp.append(rr)
        return outp
    def creat_cmd_dictionary(self):
        self.cmd_dictionary['SDOPacket'] = 1
        self.cmd_dictionary['StatusWord'] = 2
        self.cmd_dictionary['ABSEncoder'] = 3
        self.cmd_dictionary['INCEncoder'] = 4

    def process_response(self,cmd,payload):
        if cmd == self.cmd_dictionary['SDOPacket']:
            print ('sdo packet is received')
        elif cmd == self.cmd_dictionary['StatusWord']:
            self.decode_statusword_payload(payload)
        elif cmd == self.cmd_dictionary['ABSEncoder']:
            self.decode_abs_encoder_payload(payload)
        elif cmd == self.cmd_dictionary['INCEncoder']:
            self.decode_inc_encoder_payload(payload)
        elif cmd == self.cmd_dictionary['SDOPacket']:
            self.decode_sdopacket_payload(payload)

    def decode_statusword_payload(self,payload):
        #extract robot map
        status_words=[]
        robot_map = struct.unpack_from('H', payload,0)
        robot_map = robot_map[0]
        # extract status words for 12 actuators
        for i in range(12):
            st_word = struct.unpack_from('H',payload,2+2*i)
            status_words.append(st_word[0])

        #update status led maps if robot map is enable
        for i in range(12):
            flg=1<<i
            if(robot_map & flg) == flg:
                self.udpate_status_led_row(i,status_words[i])

    def udpate_status_led_row(self,inx,st_word):
        # bit0 Ready to switch on
        if (st_word & 0x0001) == 1:
            self.status_led_map[inx][0] = True
        else:
            self.status_led_map[inx][0] = False
        # bit1 Switched on
        if (st_word & 0x0002) == 2:
            self.status_led_map[inx][1] = True
        else:
            self.status_led_map[inx][1] = False
        # bit2 Operation enabled
        if (st_word & 0x0004) == 4:
            self.status_led_map[inx][2] = True
        else:
            self.status_led_map[inx][2] = False
        # bit3 Fault
        if (st_word & 0x0008) == 8:
            self.status_led_map[inx][3] = True
        else:
            self.status_led_map[inx][3] = False
        # bit4 Voltage enabled
        if (st_word & 0x0010) == 16:
            self.status_led_map[inx][4] = True
        else:
            self.status_led_map[inx][4] = False
        # bit5 Quick stop
        if (st_word & 0x0020) == 32:
            self.status_led_map[inx][5] = True
        else:
            self.status_led_map[inx][5] = False
        # bit6 Switch on disabled
        if (st_word & 0x0040) == 64:
            self.status_led_map[inx][6] = True
        else:
            self.status_led_map[inx][6] = False
        # bit7 Warning
        if (st_word & 0x0080) == 128:
            self.status_led_map[inx][7] = True
        else:
            self.status_led_map[inx][7] = False
        # bit10 Target reached
        if (st_word & 0x0400) == 1024:
            self.status_led_map[inx][8] = True
        else:
            self.status_led_map[inx][8] = False
        # bit11 Internal limit active
        if (st_word & 0x0800) == 2048:
            self.status_led_map[inx][9] = True
        else:
            self.status_led_map[inx][9] = False
        # bit 12 interpolation active just in the case of elmo interpolation position mode
        if (st_word & 0x1000) == 4096:
            self.status_led_map[inx][13] = True
        else:
            self.status_led_map[inx][13] = False

    def decode_abs_encoder_payload(self,payload):
        enc_words = []
        robot_map = struct.unpack_from('H', payload, 0)
        robot_map = robot_map[0]
        # extract status words for 12 actuators
        for i in range(12):
            enc_word = struct.unpack_from('i', payload, 2 + 4 * i)
            enc_words.append(enc_word[0])
       #update status led maps if robot map is enable
        for i in range(12):
            flg=1<<i
            if(robot_map & flg) == flg:
                self.abs_encoder_cnt[i]=enc_words[i]


    def decode_inc_encoder_payload(self,payload):
        enc_words = []
        robot_map = struct.unpack_from('H', payload, 0)
        robot_map = robot_map[0]
        # extract status words for 12 actuators
        for i in range(12):
            enc_word = struct.unpack_from('i', payload, 2 + 4 * i)
            enc_words.append(enc_word[0])
        # update status led maps if robot map is enable
        for i in range(12):
            flg = 1 << i
            if (robot_map & flg) == flg:
                self.inc_encoder_cnt[i] = enc_words[i]

    def update_gotoposition_buffer(self,node_id,encoder_type,angle_type,target_value):
        if(angle_type): #this angle unit is encoder cnt
            target_value = int(target_value)
            if encoder_type == 'INC':
                self.gotoposition_buffer[node_id] = target_value
            else:
                #in this case we are going to find appropriate incremental encoder value which is matched to this abs encoder value
                diff = target_value -self.abs_encoder_zero_offset[node_id]
                #related degree_value
                #deg_load=diff*360/self.absolute_encoder_loop_count
                #convert to degree in motor side
                #deg_motor = deg_load * self.gearhead_ratio
                #convert to incremental encoder count
                #self.gotoposition_buffer[node_id] = deg_motor * self.incremantal_encoder_loop_count / 360.0
                self.gotoposition_buffer[node_id] = diff * self.gearhead_ratio * self.incremantal_encoder_loop_count / self.absolute_encoder_loop_count
        else: #angle uint is degree
            self.gotoposition_buffer[node_id] = target_value*self.gearhead_ratio*self.incremantal_encoder_loop_count/360.0

    def decode_sdopacket_payload(self,payload):
        return