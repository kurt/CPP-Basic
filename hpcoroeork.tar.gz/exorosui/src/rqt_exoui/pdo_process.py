import rospy
import sys
from exo_msgs.msg import PDOTX3, PDOTX4, PDOsTX3, PDOsTX4

class ExoPDOProcess(object):
    def __init__(self):
        self.sub = rospy.Subscriber("/robot/pdo/tx3", PDOsTX3, self.callback_pdo_tx3)
        self.sub = rospy.Subscriber("/robot/pdo/tx4", PDOsTX4, self.callback_pdo_tx4)
        self.pdo_tx3_list = []
        self.pdo_tx4_list = []
        self.screen_refresh_flag = True

        return
    def callback_pdo_tx3(self,msg):
        self.pdo_tx3_list.append(msg)
        self.screen_refresh_flag = True
    def callback_pdo_tx4(self,msg):
        self.pdo_tx4_list.append(msg)
        self.screen_refresh_flag = True
    def reset_data(self):
        del self.pdo_tx3_list[:]
        del self.pdo_tx4_list[:]
        self.screen_refresh_flag = True
