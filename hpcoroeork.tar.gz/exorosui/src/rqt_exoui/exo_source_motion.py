class ExoActuators(object):
    def __init__(self):
        self.Right_Hip_Abduction=0
        self.Right_Hip_Rob=0
        self.Right_Hip_Flex=0
        self.Right_Knee=0
        self.Right_Ankle_Flex=0
        self.Right_Ankle_Inversion=0
        self.Right_Hip_Abduction = 0
        self.Right_Hip_Rob = 0
        self.Right_Hip_Flex = 0
        self.Right_Knee = 0
        self.Right_Ankle_Flex = 0
        self.Right_Ankle_Inversion = 0

class ExoFootAxis(object):
    def __init__(self):
        self.Right_x = 0
        self.Right_y = 0
        self.Right_z = 0
        self.Left_x = 0
        self.Left_y = 0
        self.Left_z = 0

class ExoPelvisPosition(object):
    def __init__(self):
        self.Pelvis_x = 0
        self.Pelvis_y = 0
        self.Pelvis_z = 0

class ExoPelvisOrientation(object):
    def __init__(self):
        self.Pelvis_alpha = 0
        self.Pelvis_beta = 0
        self.Pelvis_gamma = 0

class ExoFootOrientation(object):
    def __init__(self):
        self.Right_alpha = 0
        self.Right_beta = 0
        self.Right_gamma = 0
        self.Left_alpha = 0
        self.Left_beta = 0
        self.Left_gamma = 0

class ExoCOM(object):
    def __init__(self):
        self.COM_x = 0
        self.COM_y = 0
        self.COM_z = 0

class ExoZMP(object):
    def __init__(self):
        self.ZMP_x = 0
        self.ZMP_y = 0

class ExoSourceMotion(object):

    def __init__(self):
        self.Interpolation_Time_ms=10
        self.Starting_Position=ExoActuators()
        self.Motion_Position=[]
        self.Motion_Velocity=[]
        self.Actuator_Torque=[]
        self.Foot_Reaction_Force=[]
        self.Foot_Reaction_Moment=[]
        self.Pelvis_Position=[]
        self.Pelvis_Orientation=[]
        self.Ankle_Position=[]
        self.Foot_Orientation=[]
        self.COM=[]
        self.ZMP=[]