import exoui_config
import os.path
from os import path
import json
from json import JSONEncoder


class AutoSaveProcess(object):


    cfg_path=""
    def __init__(self,location):
        print ('loading last setting ...')
        self.r_cfg= exoui_config.ExouiConfig()
        self.w_cfg = exoui_config.ExouiConfig()
        wks_folder = os.path.dirname(location)
        self.cfg_path=wks_folder+"/cfg.json"
        self.start_autoload()

        return

    def start_autoload(self):
        if not path.exists(self.cfg_path):
            print ('cfg file not found, creating the new one')
            self.write_to_config_file()
        self.read_from_config_file()
        return

    def write_to_config_file(self):
 #       with open(self.cfg_path, 'w') as outfile:
 #           json.dump(self.w_cfg.tojson(), outfile)
        ss = self.w_cfg.tojson()
        with open(self.cfg_path, "w") as text_file:
            text_file.write(ss)

        print ('json file updated')
        return


    def read_from_config_file(self):
        print('load start')
        with open(self.cfg_path, "r") as text_file:
            dd=text_file.read()
        ddd=json.loads(dd)
        #load rosbag settings
        self.r_cfg.rosbag_file_path = ddd["rosbag_file_path"]
        self.r_cfg.json_file_path=ddd["json_file_path"]
        self.r_cfg.rosbag_motor_cammands_enable = ddd["rosbag_motor_cammands_enable"]
        self.r_cfg.rosbag_sensor_force_enable = ddd["rosbag_sensor_force_enable"]
        self.r_cfg.rosbag_sensor_range_enable = ddd["rosbag_sensor_range_enable"]

        self.r_cfg.rosbag_motor_command_map = ddd["rosbag_motor_command_map"]
        self.r_cfg.rosbag_sensor_force_map = ddd["rosbag_sensor_force_map"]
        self.r_cfg.rosbag_sensor_range_map = ddd["rosbag_sensor_range_map"]
        #load json settings

        self.r_cfg.jsonplot_position = ddd["jsonplot_position"]
        self.r_cfg.jsonplot_velocity = ddd["jsonplot_velocity"]
        self.r_cfg.jsonplot_torque = ddd["jsonplot_torque"]
        self.r_cfg.jsonplot_actuators = ddd["jsonplot_actuators"]
        self.r_cfg.jsonplot_ankle_position = ddd["jsonplot_ankle_position"]
        self.r_cfg.jsonplot_ft_force = ddd["jsonplot_ft_force"]
        self.r_cfg.jsonplot_ft_torque = ddd["jsonplot_ft_torque"]
        self.r_cfg.jsonplot_foot_directions = ddd["jsonplot_foot_directions"]
        self.r_cfg.jsonplot_foot_orientation = ddd["jsonplot_foot_orientation"]
        self.r_cfg.jsonplot_pelvis = ddd["jsonplot_pelvis"]
        self.r_cfg.jsonplot_zmp = ddd["jsonplot_zmp"]
        self.r_cfg.jsonplot_com = ddd["jsonplot_com"]

        # load binary setting
        self.r_cfg.binary_folder_path = ddd["binary_folder_path"]
        print ('parse succeed')

        #load exo page settings
        self.r_cfg.exo_motors_enable = ddd["exo_motors_enable"]
        self.r_cfg.exo_abs_encoder_selected = ddd["exo_abs_encoder_selected"]
        self.r_cfg.exo_inc_encoder_selected = ddd["exo_inc_encoder_selected"]
        self.r_cfg.exo_encoder_count_selected = ddd["exo_encoder_count_selected"]
        self.r_cfg.exo_angle_degree_selected = ddd["exo_angle_degree_selected"]

        return

