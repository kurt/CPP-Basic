import os
from PyQt5 import QtCore, QtGui, QtWidgets
class GraphicProcess(object):

    def __init__(self):
        self.footplate_ft_scene = QtWidgets.QGraphicsScene(0, 0, 100, 100)
        self.footplate_range_scene = QtWidgets.QGraphicsScene(0, 0, 100, 100)
        self.status_labels_abs = []
        self.status_labels_inc = []
        self.status_labels_curr = []
        self.status_labels_start = []
        self.status_led_matrix = []
        self.status_led_off_matrix = []
        self.create_status_labels()
        self.create_status_leds()

          # self.footplate_scene.setBackgroundBrush(QtGui.QColor('coral'))

        self.zmpleft_x_start = -185
        self.zmpleft_x_end = 15
        self.zmpleft_y_start = -155
        self.zmpleft_y_end = 245

        self.zmpright_x_start = 75
        self.zmpright_x_end = 275
        self.zmpright_y_start = -155
        self.zmpright_y_end = 245
        cwd = os.getcwd()


    def make_footplate_ft_scene(self,zmpx_l,zmpy_l,zmpx_r,zmpy_r):
        # clear scene
        self.footplate_ft_scene.clear()
        # adding rectangle

        rct1 = QtWidgets.QGraphicsRectItem(-180, -150, 200, 400)
        rct1.setBrush(QtGui.QColor('orange'))
        rct2 = QtWidgets.QGraphicsRectItem(80, -150, 200, 400)
        rct2.setBrush(QtGui.QColor('orange'))

        rct_in1 = QtWidgets.QGraphicsRectItem(-140, -95, 120, 290)
        rct_in1.setBrush(QtGui.QColor('palegreen'))
        rct_in2 = QtWidgets.QGraphicsRectItem(120, -95, 120, 290)
        rct_in2.setBrush(QtGui.QColor('palegreen'))

        self.footplate_ft_scene.addItem(rct1)
        self.footplate_ft_scene.addItem(rct2)
        self.footplate_ft_scene.addItem(rct_in1)
        self.footplate_ft_scene.addItem(rct_in2)

        zmpleft = QtWidgets.QGraphicsEllipseItem((zmpx_l*60) - 85, (zmpy_l*145) + 45, 10, 10)
        zmpleft.setBrush(QtGui.QColor('coral'))
        zmpright = QtWidgets.QGraphicsEllipseItem((zmpx_r*60) + 175, (zmpy_r*145) + 45, 10, 10)
        zmpright.setBrush(QtGui.QColor('yellow'))

        self.footplate_ft_scene.addItem(zmpleft)
        self.footplate_ft_scene.addItem(zmpright)

    def make_footplate_range_scene(self,left,right):
        self.footplate_range_scene.clear()
        rect_gnd = QtWidgets.QGraphicsRectItem(-80, 120, 260, 1)

        range1_left = QtWidgets.QGraphicsEllipseItem(-50, 115-(left[0]*0.25), 10, 10)
        range1_left.setBrush(QtGui.QColor('coral'))
        range2_left = QtWidgets.QGraphicsEllipseItem(-30, 115-(left[1]*0.25), 10, 10)
        range2_left.setBrush(QtGui.QColor('coral'))
        range3_left = QtWidgets.QGraphicsEllipseItem(-10, 115-(left[2]*0.25), 10, 10)
        range3_left.setBrush(QtGui.QColor('coral'))
        range4_left = QtWidgets.QGraphicsEllipseItem(10, 115-(left[3]*0.25), 10, 10)
        range4_left.setBrush(QtGui.QColor('coral'))

        range1_right = QtWidgets.QGraphicsEllipseItem(90, 115-(right[0]*0.25), 10, 10)
        range1_right.setBrush(QtGui.QColor('yellow'))
        range2_right = QtWidgets.QGraphicsEllipseItem(110, 115-(right[1]*0.25), 10, 10)
        range2_right.setBrush(QtGui.QColor('yellow'))
        range3_right = QtWidgets.QGraphicsEllipseItem(130, 115-(right[2]*0.25), 10, 10)
        range3_right.setBrush(QtGui.QColor('yellow'))
        range4_right = QtWidgets.QGraphicsEllipseItem(150, 115-(right[3]*0.25), 10, 10)
        range4_right.setBrush(QtGui.QColor('yellow'))


        self.footplate_range_scene.addItem(rect_gnd)
        self.footplate_range_scene.addItem(range1_left)
        self.footplate_range_scene.addItem(range2_left)
        self.footplate_range_scene.addItem(range3_left)
        self.footplate_range_scene.addItem(range4_left)

        self.footplate_range_scene.addItem(range1_right)
        self.footplate_range_scene.addItem(range2_right)
        self.footplate_range_scene.addItem(range3_right)
        self.footplate_range_scene.addItem(range4_right)
    def create_scroll_widget(self, inp):
        outp = QtWidgets.QWidget()
        vbox = QtWidgets.QVBoxLayout()

        for i in range(len(inp)):
            helplbl = QtWidgets.QLabel(str(inp[i]))
            helplbl.setStyleSheet("border: 1px solid white;")
            vbox.addWidget(helplbl)

        outp.setLayout(vbox)
        #font = QtGui.QFont('Mono', 9, QtGui.QFont.Light)
        #helplbl.setFont(font)
        #helplbl.setWordWrap(True)
        #helplbl.move(100, 10)
        return outp


    def create_status_labels(self):
        for ll in range (13):
            l1 = QtWidgets.QLabel()
            l2 = QtWidgets.QLabel()
            l3 = QtWidgets.QLabel()
            l4 = QtWidgets.QLabel()
            if ll==0:
                l1.setText('ABS')
                l2.setText('INC')
                l3.setText('Curr')
                l4.setText('Start')
            else:
                l1.setText('TODO')
                l2.setText('TODO')
                l3.setText('TODO')


            self.status_labels_abs.append(l1)
            self.status_labels_inc.append(l2)
            self.status_labels_curr.append(l3)
            self.status_labels_start.append(l4)
        return

    def generate_green_led(self):
        l = QtWidgets.QLabel()
        pixmap = QtGui.QPixmap('/home/babak/hmr_ws/src/hpc/exorosui/resource/led_green.png')
        l.setPixmap(pixmap)
        l.setScaledContents(True)
        l.setStyleSheet("border: 0px;")
        return l
    def generate_red_led(self):
        l = QtWidgets.QLabel()
        pixmap = QtGui.QPixmap('/home/babak/hmr_ws/src/hpc/exorosui/resource/led_red.png')
        l.setPixmap(pixmap)
        l.setScaledContents(True)
        l.setStyleSheet("border: 0px;")
        return l
    def generate_black_led(self):
        l = QtWidgets.QLabel()
        pixmap = QtGui.QPixmap('/home/babak/hmr_ws/src/hpc/exorosui/resource/led_black.png')
        l.setPixmap(pixmap)
        l.setScaledContents(True)
        l.setStyleSheet("border: 0px;")
        return l

    def create_status_leds(self):
        for ll in range(12):
            led_row=[]
            led_row.append(self.generate_green_led())
            led_row.append(self.generate_green_led())
            led_row.append(self.generate_green_led())
            led_row.append(self.generate_red_led())
            led_row.append(self.generate_green_led())
            led_row.append(self.generate_green_led())
            led_row.append(self.generate_green_led())
            led_row.append(self.generate_green_led())
            led_row.append(self.generate_green_led())
            led_row.append(self.generate_red_led())
            led_row.append(self.generate_green_led())
            led_row.append(self.generate_red_led())
            led_row.append(self.generate_green_led())
            led_row.append(self.generate_green_led())

            self.status_led_matrix.append(led_row)
        #create status led off matrix
        for ll in range(12):
            rr=[]
            for kk in range (14):
                rr.append(self.generate_black_led())
            self.status_led_off_matrix.append(rr)
