import sys
import rosbag
import matplotlib
matplotlib.use('qt5agg')
import Tkinter
import tkFileDialog


import os.path
from os import path
from matplotlib import pyplot



class RosbagProcess(object):
    def __init__(self):
        self.cnt_total = 0
        self.filepath = ''

        self.motor_command_msg_list = []
        self.sensor_force_msg_list = []
        self.sensor_range_msg_list = []
        self.control_states_msg_list = []
        self.rosout_msg_list=[]
        self.rosout_agg_msg_list=[]

        self.visualization_enable_motor_command = False
        self.visualization_enable_sensor_force = False
        self.visualization_enable_sensor_range = False
        self.visualization_motor_map = [False] * 12
        self.visualization_sensor_force_map = [False] * 12
        self.visualization_sensor_range_map = [False] * 8

    def manage_file_open_button_clicked(self):
        import exo_msgs
        root = Tkinter.Tk()
        root.withdraw()
        ftypes = [
            ('rosbag files', '*.bag'),
         ]


        file_path = tkFileDialog.askopenfilename(initialdir = self.filepath,filetypes=ftypes)
  #      file_path = tkFileDialog.askopenfilename()

        if file_path:
          self.filepath=os.path.dirname(file_path)
          self.msg = file_path
          bag = rosbag.Bag(file_path)
          for topic, msg, t in bag.read_messages():#topics='/motors/command'):
              self.cnt_total=self.cnt_total+1
              if topic=='/motors/command':
                  #                print msg.header.seq
                  self.process_motor_command_topic(msg)
              elif topic=='/robot/sensors/foot/force':
                  self.process_sensor_force_topic(msg)
              elif topic=='/robot/sensors/foot/range':
                  self.process_sensor_range_topic(msg)
              elif topic=='/control/states':
                  self.process_control_states_topic(msg)
              elif topic == '/rosout':
                  self.process_rosout_topic(msg)
              elif topic == '/rosout_agg':
                  self.process_rosout_agg_topic(msg)
              else:
                  print(topic)

        else:
          self.msg = 'no file selected'
    def reset_data(self):
        self.cnt_total=0
        del self.motor_command_msg_list[:]
        del self.sensor_force_msg_list[:]
        del self.sensor_range_msg_list[:]
        del self.control_states_msg_list[:]
        del self.rosout_msg_list[:]
        del self.rosout_agg_msg_list[:]



    def process_motor_command_topic(self,msg):
          self.motor_command_msg_list.append(msg)
          # put message to motor command list
          return

    def process_sensor_force_topic(self,msg):
          self.sensor_force_msg_list.append(msg)
          # put message to sensor force list
          return

    def process_sensor_range_topic(self,msg):
          self.sensor_range_msg_list.append(msg)
          # put message to sensor range list
          return
    def process_control_states_topic(self,msg):
        self.control_states_msg_list.append(msg)
#        if len(self.control_states_msg_list)==1:
#            print(str(msg))
    def process_rosout_topic(self, msg):
        self.rosout_msg_list.append(msg)
        # put message to sensor range list
        #if len(self.rosout_msg_list)==1:
        #    print(str(msg))
        return

    def process_rosout_agg_topic(self, msg):
        self.rosout_agg_msg_list.append(msg)
        if len(self.rosout_agg_msg_list)==1:
            print(str(msg))
        # put message to sensor range list
        return

    def plot(self):

        #draw motor command plot if it is checked
        if self.visualization_enable_motor_command:
            fig = pyplot.figure()
            fig.suptitle('Motor commands', fontsize=16)
            #extract time and data from motor command list
            p=[]
            t_motor=self.extract_time_from_list(self.motor_command_msg_list)
            for x in range(12):
                p.append(self.extract_motor_command_position_from_list(self.motor_command_msg_list,x))

            #pyplot.ion()
            #pyplot.show()
            pyplot.cla()
            tit=('RHA','RHR','RHF','RK','RAF','RAI','LHA','LHR','LHF','LK','LAF','LAI')
            des=[]

            for x in range(12):
                if self.visualization_motor_map[x]:
                    pyplot.plot(t_motor,p[x])
                    des.append(tit[x])

            #pyplot.draw()
            pyplot.legend(des,shadow=True, loc=(0.9, 0.5), handlelength=1.5, fontsize=12)
            pyplot.pause(0.001)
        #draw sensor force and torque plot if it is checked
        if self.visualization_enable_sensor_force:
            fig,axs = pyplot.subplots(2)
            fig.suptitle('Sensor Force & Torque', fontsize=16)
            #extract time and data from sensor force list
            p=[]
            t_force=self.extract_time_from_list(self.sensor_force_msg_list)
            for x in range(12):
                p.append(self.extract_sensor_force_from_list(self.sensor_force_msg_list,x))

            pyplot.cla()
            tit=('RFx','RFy','RFz','RTx','RTy','RTz','LFx','LFy','LFz','LTx','LTy','LTz')
            des1=[]
            des2=[]

            for x in range(3):
                if self.visualization_sensor_force_map[x]:
                    axs[0].plot(t_force,p[x])
                    des1.append(tit[x])
                if self.visualization_sensor_force_map[x+6]:
                    axs[0].plot(t_force,p[x+6])
                    des1.append(tit[x+6])
                if self.visualization_sensor_force_map[x+3]:
                    axs[1].plot(t_force,p[x+3])
                    des2.append(tit[x+3])
                if self.visualization_sensor_force_map[x+9]:
                    axs[1].plot(t_force,p[x+9])
                    des2.append(tit[x+9])


                axs[0].legend(des1,shadow=True, loc=(0.9, 0.5), handlelength=1.5, fontsize=12)

                axs[1].legend(des2,shadow=True, loc=(0.9, 0.5), handlelength=1.5, fontsize=12)

        #draw sensor range plot if it is checked
        if self.visualization_enable_sensor_range:
            fig = pyplot.figure()
            fig.suptitle('Sensor Range', fontsize=16)
            #extract time and data from motor command list
            p=[]
            t_range=self.extract_time_from_list(self.sensor_range_msg_list)
            for x in range(8):
                p.append(self.extract_sensor_range_from_list(self.sensor_range_msg_list,x))

            #pyplot.ion()
            #pyplot.show()
            pyplot.cla()
            tit=('RR1','RR2','RR3','RR4','LR1','LR2','LR3','LR4')
            des=[]

            for x in range(8):
                if self.visualization_sensor_range_map[x]:
                    pyplot.plot(t_range,p[x])
                    des.append(tit[x])

            #pyplot.draw()
            pyplot.legend(des,shadow=True, loc=(0.9, 0.5), handlelength=1.5, fontsize=12)
            pyplot.pause(0.001)

        pyplot.show(block=True)
        return
    def close_plot(self):
        pyplot.close('all')

    def extract_time_from_list(self,list):
        t_out=[]
        msg_base=list[0]
        tsec=msg_base.header.stamp.secs
        tnsec=msg_base.header.stamp.nsecs
        t_base=float(tsec)+(float(tnsec)*float(1e-9))
        for msg in list:
            tsec=msg.header.stamp.secs
            tnsec=msg.header.stamp.nsecs
            t=float(tsec)+(float(tnsec)*float(1e-9))
            t_out.append(t-t_base)

        return t_out
    def extract_motor_command_position_from_list(self,list,ind):
        p_out=[]

        for msg in list:
            pos=msg.positions[ind]
            p_out.append(pos)

        return p_out
    def extract_sensor_force_from_list(self,list,ind):
        p_out=[]

        for msg in list:
            dat=0
            if ind==0:
                dat=msg.right.fx
            elif ind==1:
                dat=msg.right.fy
            elif ind==2:
                dat=msg.right.fz
            elif ind==3:
                dat=msg.right.tx
            elif ind==4:
                dat=msg.right.ty
            elif ind==5:
                dat=msg.right.tz
            elif ind==6:
                dat=msg.left.fx
            elif ind==7:
                dat=msg.left.fy
            elif ind==8:
                dat=msg.left.fz
            elif ind==9:
                dat=msg.left.tx
            elif ind==10:
                dat=msg.left.ty
            elif ind==111:
                dat=msg.left.tz

            p_out.append(dat)

        return p_out

    def extract_sensor_range_from_list(self,list,ind):
        p_out=[]

        for msg in list:
            dat=0
            if ind<4:
                dat=msg.right[ind]
            else:
                dat=msg.left[ind-4]
            p_out.append(dat)

        return p_out

