import matplotlib
matplotlib.use('qt5agg')
import Tkinter
import tkFileDialog
import os.path
from os import path
from matplotlib import pyplot
import exo_source_motion
import json

class JsonProcess(object):
    def __init__(self):
        self.folder_path=""
        self.file_path=""
        self.json_data=exo_source_motion.ExoSourceMotion()
        # plot chekboxes
        self.checkbox_position = False
        self.checkbox_velocity = False
        self.checkbox_torque = False
        self.checkbox_actuators = [False]*12
        self.checkbox_ankle_position = False
        self.checkbox_ft_force = False
        self.checkbox_ft_torque = False
        self.checkbox_foot_directions = [False]*6
        self.checkbox_foot_orientation = [False]*6
        self.checkbox_pelvis = [False]*6
        self.checkbox_zmp = [False]*2
        self.checkbox_com = [False]*3
        return
    def manage_file_load_button_clicked(self):
        import Tkinter, tkFileDialog
        import exo_msgs
        root = Tkinter.Tk()
        root.withdraw()
        ftypes = [
            ('json files', '*.json'),
        ]
        file_path = tkFileDialog.askopenfilename(initialdir=self.folder_path, filetypes=ftypes)
        if file_path:
            self.folder_path = os.path.dirname(file_path)
            self.file_path=file_path
            print('loading source json file ...')
            with open(file_path, "r") as text_file:
                dd = text_file.read()
            ddd = json.loads(dd)
            print('json loaded successfully, decoding json data')
            self.json_data.Interpolation_Time_ms = ddd["Interpolation_Time_ms"]
            #decoding start position
            self.json_data.Starting_Position = self.decode_json_actuator_string(ddd["Starting_Position"])
            #decoding motion position
            self.json_data.Motion_Position=self.decode_json_actuator_list(ddd["Motion_Position"])
            self.json_data.Motion_Velocity = self.decode_json_actuator_list(ddd["Motion_Velocity"])
            self.json_data.Actuator_Torque = self.decode_json_actuator_list(ddd["Actuator_Torque"])
            self.json_data.Foot_Reaction_Force = self.decode_json_footaxis_list(ddd["Foot_Reaction_Force"])
            self.json_data.Foot_Reaction_Moment = self.decode_json_footaxis_list(ddd["Foot_Reaction_Moment"])
            self.json_data.Pelvis_Position = self.decode_json_pelvis_position_list(ddd["Pelvis_Position"])
            self.json_data.Pelvis_Orientation = self.decode_json_pelvis_orientation_list(ddd["Pelvis_Orientation"])
            self.json_data.Ankle_Position = self.decode_json_footaxis_list(ddd["Ankle_Position"])
            self.json_data.Foot_Orientation = self.decode_json_foot_orientation_list(ddd["Foot_Orientation"])
            self.json_data.COM = self.decode_json_COM_list(ddd["COM"])
            self.json_data.ZMP = self.decode_json_ZMP_list(ddd["ZMP"])
        return
    def decode_json_actuator_string(self,inp):
        outp = exo_source_motion.ExoActuators()
        outp.Right_Hip_Abduction = inp["Right_Hip_Abduction"]
        outp.Right_Hip_Rob = inp["Right_Hip_Rob"]
        outp.Right_Hip_Flex = inp["Right_Hip_Flex"]
        outp.Right_Knee = inp["Right_Knee"]
        outp.Right_Ankle_Flex = inp["Right_Ankle_Flex"]
        outp.Right_Ankle_Inversion = inp["Right_Ankle_Inversion"]
        outp.Left_Hip_Abduction = inp["Left_Hip_Abduction"]
        outp.Left_Hip_Rob = inp["Left_Hip_Rob"]
        outp.Left_Hip_Flex = inp["Left_Hip_Flex"]
        outp.Left_Knee = inp["Left_Knee"]
        outp.Left_Ankle_Flex = inp["Left_Ankle_Flex"]
        outp.Left_Ankle_Inversion = inp["Left_Ankle_Inversion"]
        return outp
    def decode_json_actuator_list(self,inp):
        outp = []
        for x in inp:
            temp=self.decode_json_actuator_string(x)
            outp.append(temp)
        return outp
    def decode_json_footaxis_list(self, inp):
        outp = []
        for x in inp:
            temp = self.decode_json_footaxis_string(x)
            outp.append(temp)
        return outp
    def decode_json_footaxis_string(self,inp):
        outp = exo_source_motion.ExoFootAxis()
        outp.Right_x = inp["Right_x"]
        outp.Right_y = inp["Right_y"]
        outp.Right_z = inp["Right_z"]
        outp.Left_x = inp["Left_x"]
        outp.Left_y = inp["Left_y"]
        outp.Left_z = inp["Left_z"]
        return outp
    def decode_json_pelvis_position_string(self,inp):
        outp=exo_source_motion.ExoPelvisPosition()
        outp.Pelvis_x = inp["Pelvis_x"]
        outp.Pelvis_y = inp["Pelvis_y"]
        outp.Pelvis_z = inp["Pelvis_z"]
        return outp
    def decode_json_pelvis_position_list(self,inp):
        outp = []
        for x in inp:
            temp = self.decode_json_pelvis_position_string(x)
            outp.append(temp)
        return outp
    def decode_json_pelvis_orientation_string(self,inp):
        outp=exo_source_motion.ExoPelvisOrientation()
        outp.Pelvis_alpha = inp["Pelvis_alpha"]
        outp.Pelvis_beta = inp["Pelvis_beta"]
        outp.Pelvis_gamma = inp["Pelvis_gamma"]
        return outp
    def decode_json_pelvis_orientation_list(self,inp):
        outp = []
        for x in inp:
            temp = self.decode_json_pelvis_orientation_string(x)
            outp.append(temp)
        return outp
    def decode_json_foot_orientation_string(self,inp):
        outp=exo_source_motion.ExoFootOrientation()
        outp.Right_alpha = inp["Right_alpha"]
        outp.Right_beta = inp["Right_beta"]
        outp.Right_gamma = inp["Right_gamma"]
        outp.Left_alpha = inp["Left_alpha"]
        outp.Left_beta = inp["Left_beta"]
        outp.Left_gamma = inp["Left_gamma"]
        return outp
    def decode_json_foot_orientation_list(self,inp):
        outp = []
        for x in inp:
            temp = self.decode_json_foot_orientation_string(x)
            outp.append(temp)
        return outp
    def decode_json_foot_orientation_string(self,inp):
        outp=exo_source_motion.ExoFootOrientation()
        outp.Right_alpha = inp["Right_alpha"]
        outp.Right_beta = inp["Right_beta"]
        outp.Right_gamma = inp["Right_gamma"]
        outp.Left_alpha = inp["Left_alpha"]
        outp.Left_beta = inp["Left_beta"]
        outp.Left_gamma = inp["Left_gamma"]
        return outp
    def decode_json_foot_orientation_list(self,inp):
        outp = []
        for x in inp:
            temp = self.decode_json_foot_orientation_string(x)
            outp.append(temp)
        return outp
    def decode_json_COM_string(self,inp):
        outp=exo_source_motion.ExoCOM()
        outp.COM_x = inp["COM_x"]
        outp.COM_y = inp["COM_y"]
        outp.COM_z = inp["COM_z"]
        return outp
    def decode_json_COM_list(self,inp):
        outp = []
        for x in inp:
            temp = self.decode_json_COM_string(x)
            outp.append(temp)
        return outp
    def decode_json_ZMP_string(self,inp):
        outp=exo_source_motion.ExoZMP()
        outp.ZMP_x = inp["ZMP_x"]
        outp.ZMP_y = inp["ZMP_y"]
        return outp
    def decode_json_ZMP_list(self,inp):
        outp = []
        for x in inp:
            temp = self.decode_json_ZMP_string(x)
            outp.append(temp)
        return outp
    def plot_json_data(self):
        print('start plotting json data')



        pyplot.clf()

        des=[]
        ac_tit=['RHA','RHR','RHF','RK','RAF','RAI','LHA','LHR','LHF','LK','LAF','LAI']
        fd_tit=['Rx','Ry','Rz','Lx','Ly','Lz']
        fo_tit=['RAlpha','RBeta','RGamma','LAlpha','LBeta','LGamma']
        plv_tit=['plv_x','plv_y','plv_z','plv_A','plv_B','plv_G']
        zmp_tit=['ZMP_x','ZMP_y']
        com_tit=['COM_x','COM_y','COM_z']
        if self.checkbox_position:
            for ind in range(12):
                if self.checkbox_actuators[ind]:
                    ss = 'pos_' + ac_tit[ind]
                    des.append(ss)
                    d=[]
                    for x in self.json_data.Motion_Position:
                        d.append(self.extract_data_from_actuator_class(x,ind))
                    pyplot.plot(d)
        if self.checkbox_velocity:
            for ind in range(12):
                if self.checkbox_actuators[ind]:
                    ss = 'vel_' + ac_tit[ind]
                    des.append(ss)
                    d = []
                    for x in self.json_data.Motion_Velocity:
                        d.append(self.extract_data_from_actuator_class(x, ind))
                    pyplot.plot(d)
        if self.checkbox_torque:
            for ind in range(12):
                if self.checkbox_actuators[ind]:
                    ss = 'tor_' + ac_tit[ind]
                    des.append(ss)
                    d = []
                    for x in self.json_data.Actuator_Torque:
                        d.append(self.extract_data_from_actuator_class(x, ind))
                    pyplot.plot(d)
        if self.checkbox_ankle_position:
            for ind in range(6):
                if self.checkbox_foot_directions[ind]:
                    ss = 'Apos_' + fd_tit[ind]
                    des.append(ss)
                    d = []
                    for x in self.json_data.Ankle_Position:
                        d.append(self.extract_from_axis_class(x, ind))
                    pyplot.plot(d)
        if self.checkbox_ft_force:
            for ind in range(6):
                if self.checkbox_foot_directions[ind]:
                    ss = 'F_' + fd_tit[ind]
                    des.append(ss)
                    d = []
                    for x in self.json_data.Foot_Reaction_Force:
                        d.append(self.extract_from_axis_class(x, ind))
                    pyplot.plot(d)
        if self.checkbox_ft_torque:
            for ind in range(6):
                if self.checkbox_foot_directions[ind]:
                    ss = 'T_' + fd_tit[ind]
                    des.append(ss)
                    d = []
                    for x in self.json_data.Foot_Reaction_Moment:
                        d.append(self.extract_from_axis_class(x, ind))
                    pyplot.plot(d)

        for ind in range(6):
            if self.checkbox_foot_orientation[ind]:
                ss = fo_tit[ind]
                des.append(ss)
                d = []
                for x in self.json_data.Foot_Orientation:
                    d.append(self.extarct_from_foot_orientation_class(x, ind))
                pyplot.plot(d)

        for ind in range(6):
            if self.checkbox_pelvis[ind]:
                ss=plv_tit[ind]
                des.append(ss)
                d=[]
                if ind<3:
                    for x in self.json_data.Pelvis_Position:
                        d.append(self.extarct_from_pelvis_position_class(x,ind))
                else:
                    for x in self.json_data.Pelvis_Orientation:
                        d.append(self.extract_from_pelvis_orientation_class(x, (ind-3)))
                pyplot.plot(d)

        for ind in range(2):
            if self.checkbox_zmp[ind]:
                ss=zmp_tit[ind]
                des.append(ss)
                d=[]
                for x in self.json_data.ZMP:
                    d.append(self.extract_from_zmp_class(x,ind))
                pyplot.plot(d)

        for ind in range(3):
            if self.checkbox_com[ind]:
                ss=com_tit[ind]
                des.append(ss)
                d=[]
                for x in self.json_data.COM:
                    d.append(self.extract_from_com_class(x,ind))
                pyplot.plot(d)

        pyplot.legend(des, shadow=True, loc=(0.9, 0.5), handlelength=1.5, fontsize=12)
        pyplot.pause(0.001)
        pyplot.show(block=True)
        return;
    def extract_data_from_actuator_class(self,inp,ind):
        outp = 0
        if ind == 0:
            return inp.Right_Hip_Abduction
        elif ind == 1:
            return inp.Right_Hip_Rob
        elif ind == 2:
            return inp.Right_Hip_Flex
        elif ind == 3:
            return inp.Right_Knee
        elif ind == 4:
            return inp.Right_Ankle_Flex
        elif ind == 5:
            return inp.Right_Ankle_Inversion
        elif ind == 6:
            return inp.Left_Hip_Abduction
        elif ind == 7:
            return inp.Left_Hip_Rob
        elif ind == 8:
            return inp.Left_Hip_Flex
        elif ind == 9:
            return inp.Left_Knee
        elif ind == 10:
            return inp.Left_Ankle_Flex
        elif ind == 11:
            return inp.Left_Ankle_Inversion


        return outp
    def extract_from_axis_class(self,inp,ind):
        outp = 0
        if ind == 0:
            return inp.Right_x
        elif ind == 1:
            return inp.Right_y
        elif ind == 2:
            return inp.Right_z
        elif ind == 3:
            return inp.Left_x
        elif ind == 4:
            return inp.Left_y
        elif ind == 5:
            return inp.Left_z
        return outp
    def extarct_from_foot_orientation_class(self,inp,ind):
        outp = 0
        if ind == 0:
            return inp.Right_alpha
        elif ind == 1:
            return inp.Right_beta
        elif ind == 2:
            return inp.Right_gamma
        elif ind == 3:
            return inp.Left_alpha
        elif ind == 4:
            return inp.Left_beta
        elif ind == 5:
            return inp.Left_gamma

        return outp
    def extarct_from_pelvis_position_class(self,inp,ind):
        outp = 0
        if ind == 0:
            return inp.Pelvis_x
        elif ind == 1:
            return inp.Pelvis_y
        elif ind == 2:
            return inp.Pelvis_z

        return outp
    def extract_from_pelvis_orientation_class(self,inp,ind):
        outp = 0
        if ind == 0:
            return inp.Pelvis_alpha
        elif ind == 1:
            return inp.Pelvis_beta
        elif ind == 2:
            return inp.Pelvis_gamma

        return outp
    def extract_from_zmp_class(self,inp,ind):
        outp = 0
        if ind == 0:
            return inp.ZMP_x
        elif ind == 1:
            return inp.ZMP_y

        return outp
    def extract_from_com_class(self,inp,ind):
        outp = 0
        if ind == 0:
            return inp.COM_x
        elif ind == 1:
            return inp.COM_y
        elif ind == 2:
            return inp.COM_z

        return outp
