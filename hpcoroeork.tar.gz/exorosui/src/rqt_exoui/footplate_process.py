import rospy
import sys
from exo_msgs.msg import FootRangeSensors, ForceTorqueSensor, ForceTorqueSensors



class ExoFootplateProcess(object):
    def __init__(self):
        self.sub = rospy.Subscriber("/robot/sensors/foot/force", ForceTorqueSensors, self.callback_ft)
        self.sub = rospy.Subscriber("/robot/sensors/foot/range", FootRangeSensors, self.callback_range)
        self.sensor_ft_msg_list = []
        self.sensor_range_msg_list = []
        self.last_zmp_x_right = 0
        self.last_zmp_y_right = 0
        self.last_zmp_x_left = 0
        self.last_zmp_y_left = 0
        self.last_range_right = [0] * 4
        self.last_range_left = [0] * 4

        self.ft_offset = [0] * 6
        self.ft_offset[0] = 0
        self.ft_offset[1] = 15
        self.ft_offset[2] = 46
        self.ft_offset[3] = 0.35
        self.ft_offset[4] = - 0.4
        self.ft_offset[5] = 17


    def reset_data(self):
        del self.sensor_ft_msg_list[:]
        del self.sensor_range_msg_list[:]
        self.last_zmp_x_left = 0
        self.last_zmp_y_left = 0
        self.last_zmp_x_right = 0
        self.last_zmp_y_right = 0
        for x in range(4):
            self.last_range_left[x] = 0
            self.last_range_right[x] = 0

    def callback_ft(self, msg):

        # deducting offsets
        msg.left.fx = msg.left.fx - self.ft_offset[0]
        msg.left.fy = msg.left.fy - self.ft_offset[1]
        msg.left.fz = msg.left.fz - self.ft_offset[2]
        msg.left.tx = msg.left.tx - self.ft_offset[3]
        msg.left.ty = msg.left.ty - self.ft_offset[4]
        msg.left.tz = msg.left.tz - self.ft_offset[5]

        msg.right.fx = msg.right.fx - self.ft_offset[0]
        msg.right.fy = msg.right.fy - self.ft_offset[1]
        msg.right.fz = msg.right.fz - self.ft_offset[2]
        msg.right.tx = msg.right.tx - self.ft_offset[3]
        msg.right.ty = msg.right.ty - self.ft_offset[4]
        msg.right.tz = msg.right.tz - self.ft_offset[5]

        self.sensor_ft_msg_list.append(msg)
        #calculate zmp
        # left side
        zs = 0.013
        if msg.left.fz == 0:
            msg.left.fz = 1
        self.last_zmp_x_left = ((-msg.left.fx * zs) - msg.left.ty) / msg.left.fz
        self.last_zmp_y_left = ((-msg.left.fy * zs) + msg.left.tx) / msg.left.fz
        # right side
        if msg.right.fz == 0:
            msg.right.fz = 1
        self.last_zmp_x_right = ((-msg.right.fx * zs) - msg.right.ty) / msg.right.fz
        self.last_zmp_y_right = ((-msg.right.fy * zs) + msg.right.tx) / msg.right.fz


    def callback_range(self, msg):
        self.sensor_range_msg_list.append(msg)
        # update last ranges
        for x in range(4):
            self.last_range_left[x] = msg.left[x]
            self.last_range_right[x] = msg.right[x]
