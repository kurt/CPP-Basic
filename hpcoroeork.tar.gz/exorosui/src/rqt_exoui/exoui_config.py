import json
class ExouiConfig(object):


    def __init__(self):
        #rosbag page
        self.rosbag_file_path = ''
        self.json_file_path=''
        self.binary_folder_path=''
        self.rosbag_motor_cammands_enable = False
        self.rosbag_sensor_force_enable = False
        self.rosbag_sensor_range_enable = False

        self.rosbag_motor_command_map = [False] * 12
        self.rosbag_sensor_force_map = [False] * 12
        self.rosbag_sensor_range_map = [False] * 8

        self.jsonplot_position = False
        self.jsonplot_velocity = False
        self.jsonplot_torque = False
        self.jsonplot_actuators = [False]*12
        self.jsonplot_ankle_position = False
        self.jsonplot_ft_force = False
        self.jsonplot_ft_torque = False
        self.jsonplot_foot_directions = [False]*6
        self.jsonplot_foot_orientation = [False]*6
        self.jsonplot_pelvis = [False]*6
        self.jsonplot_zmp = [False]*2
        self.jsonplot_com = [False]*3

        self.exo_motors_enable = [False]*12
        self.exo_abs_encoder_selected = True
        self.exo_inc_encoder_selected = False
        self.exo_encoder_count_selected = True
        self.exo_angle_degree_selected = False



        return

    def tojson(self):
        return json.dumps(self, default=lambda o: o.__dict__,
                          sort_keys=True, indent=4)