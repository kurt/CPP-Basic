#ifndef __TRAJECTORY_H__
#define __TRAJECTORY_H__

#include <ros/ros.h>
#include <boost/thread.hpp>
#include <boost/function.hpp>
#include <exo_trajectory/controller_a.h>
#include <exo_trajectory/exoinfo.h>
#include <exo_msgs/JointData.h>
#include <exo_msgs/MotorCommand.h>
#include <exo_msgs/ForceTorqueSensors.h>
#include <exo_msgs/ForceTorqueSensor.h>
#include <exo_msgs/FootRangeSensors.h>

namespace exo_trajectory {

class TrajectoryGenerator
{
public:
    TrajectoryGenerator(ros::NodeHandle nh, ros::NodeHandle nhp);
    virtual ~TrajectoryGenerator();

private:
    void rangeSensorsDataCallback(const exo_msgs::FootRangeSensors::ConstPtr& footRangeSensors);
    void forceTorqueSensorsDataCallback(const exo_msgs::ForceTorqueSensor::ConstPtr& forceTorqueSensors);

private:
    exo_trajectory::Sensors sensors_;
    exo_trajectory::ControllerA controller_a_;
    ros::NodeHandle nh_;
    ros::NodeHandle nhp_;

    ros::Publisher control_state_publisher_;
    ros::Publisher motor_command_publisher_;
    ros::Subscriber foot_range_sensors_subscriber_;
    ros::Subscriber force_torque_sensors_subscriber_;
};

};

#endif
