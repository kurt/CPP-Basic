#ifndef __EXOINFO_H__
#define __EXOINFO_H__

#include <stdint.h>

#define NO_MOTORS 12

#define RIGHT                   0
#define LEFT                    1

#define RANGE_SENSOR_CPR        16384.0
#define INCREMENTAL_ENCODER_CPR 3456.0
#define GEARHEAD_RATIO          101.0
#define PI_NUMBER               3.14159265358979323846

namespace exo_trajectory {

typedef struct __attribute__((__packed__))
{
    float fx;
    float fy;
    float fz;
    float tx;
    float ty;
    float tz;
} ForceTorqueSensor;

typedef struct __attribute__((__packed__))
{
    ForceTorqueSensor forceTorqueSensor;
    int16_t           rangeSensors[4]; // 0: FR, 1: FL, 2: RR, 3: RL
} FootSensors;

typedef struct __attribute__((__packed__))
{
    FootSensors foot_sensors[2]; // 0 is left, 1 is right
    // IMU         imu;
} Sensors;

class ExoConstants
{
private:
    static constexpr int32_t min_limits[NO_MOTORS] = {-24240,-19392,-29088,-116352,-38784,-14544,-24240,-19392,-29088,-116352,-38784,-14544};
    static constexpr int32_t max_limits[NO_MOTORS] = {24240,19392,126048,969,24240,14544,24240,19392,126048,969,24240,14544};

public:
    static int32_t getMinLimit(int node)
    {
        if (node < NO_MOTORS)
            return min_limits[node];
    }

    static int32_t getMaxLimit(int node)
    {
        if (node < NO_MOTORS)
            return max_limits[node];
    }
};

}

#endif
