#define L_sh		0.4
#define L_th 		0.4
#define L_pl 		0.186
#define L_sh2		0.16		//L_sh^2
#define L_th2		0.16		//L_th^2
#define My_Coef		3.125		//1/(2*L_sh*L_th)

#define lh1  0.1
#define lh2  0.17413
#define lh3  0.3079
#define lh4  0.30799

#define	uy   0.642787609686539 //cosd(50);
#define	uz   0.766044443118978 //sind(50);

void Hip_Joints_IK(double inp[3],double outp[4],int side);
void Hip_mech(double inp[9],double outp[4],int dir);
void ik(double* inp,double* outp);
void fast_inv(double inp[16],double outp[16]);
