#ifndef __CONTROLLER_A_H__
#define __CONTROLLER_A_H__

#include <math.h>
#include <string.h>
#include <iostream>
#include <ros/ros.h>
#include <exo_msgs/MotorCommand.h>
#include <exo_msgs/ControlState.h>
#include <exo_trajectory/exoinfo.h>
#include <exo_trajectory/preplanned_info.h>
#include <exo_trajectory/ik.h>

#define INDX_FR             0
#define INDX_FL             1
#define INDX_RR             2
#define INDX_RL             3

#define Z_Off_The_Ground    400 // this should be found by footplate experiment
#define CONTACT_THR         0  // this should be found by footplate experiment

#define Roll_Step           150//150 //this should be found by exo experimnet
#define Pitch_Step          150//150 //this should be found by exo experimnet

#define K_Roll_Gain         1.5//2   //this should be found by exo experimnet
#define K_Pitch_Gain        1.5//2   //this should be found by exo experimnet

#define THETA_0                     (3.19 * PI_NUMBER /180)  // Range sensor arm angle offset wrt horizental plane in deg
#define RANGE_SENSOR_ARM_LENGTH     (94.29 / 1000)           // meter
#define PARALLEL_THRESHOLD          20


#define FT_SENSOR_X_LOC             (0)
#define FT_SENSOR_Y_LOC             (0)
#define FT_SENSOR_Z_LOC             (0.013)
#define FT_SENSOR_LANDED_THRESHOLD  (50.0)
#define FT_SENSOR_LIFTED_THRESHOLD  (1.0)
#define FOOTPLATE_L                 (30)
#define FOOTPLATE_W                 (12)
#define ZMP_REGION_L                (0.8)
#define ZMP_REGION_W                (0.6)
#define GAIN_Kac_r                  0.02
#define GAIN_Kas_r                  0.01

namespace exo_trajectory {

typedef enum
{
    ZMP_PHASE_SS_RIGHT = 0,
    ZMP_PHASE_SS_LEFT = 1,
    ZMP_PHASE_DS = 2,
    ZMP_PHASE_TRS = 3
} ZMPPhaseType;

typedef struct
{
    bool is_advance_happend; // Advance is occured
    int prev_sensor_value; // Previous sensor_switch value
    int sequence_advance; // The sequence no in which latest advance is happend
    double z_expected_at_advance; // Value of preplanned Z which we expect a touching at the moment of advance
    double z_touched;
    int sequence_phase1_end;
    int sequence_phase2_end;
    int sequence_phase3_end;
    double advance_coef_matrix[36]; // AHMADREZA
    double advance_c_coef[6];
} AdvanceLandingParamsType;

typedef struct
{
    bool is_retard_happend; // Retard is occured. (Boolean)
    int retard_process_stage; // Is 1 or 2. 1: hasn't touched the ground yet. 2: It touched the ground
    int sequence_retard_start; // Sequence of Retard_Process_Enable
    int sequence_retard_happen; // Sequence no when Retard_Process_Stage is 2
    int retard_phase1_part1_end;
    int retard_phase1_part2_end;
    int sequence_part1_end;
    int sequence_part2_end;
    double a_coef_ret_inv_mid[36];
    double a_coef_ret_inv_end[36];
    double retard_z_preplanned;
    double c_coef_part1[6];
    double c_coef_part2[6];
    int sequence_phase1_end; // Now we know we touched the ground
    int sequence_phase2_end;
    int sequence_phase3_end;
    double z_retard;
    double dZ_Retard;
    double ddZ_Retard;
    double z_buffer[2]; // To calculate dZ and ddZ
    double retard_c_coef[6];
    double retard_c_rls[6];
} RetardLandingParamsType;

typedef struct
{
    int sequence;
    double Foot_Sensor[2];
} LandingInputType;

typedef struct
{
    int x;
    int y;
} Point2DType;

class ControllerA
{
public:
    ControllerA();
    ControllerA(Sensors* sensors, bool landing_enable, bool adaptation_enable, bool zero_test_enable, ros::NodeHandle nh, ros::NodeHandle nhp);
    virtual ~ControllerA();

private:
    bool cur_step_adaptation_enable_[2];
    double delta_z;
    Sensors* sensors_ptr_;
    int no_touched_range_sensors_[2];
    int adapt_ankle_pitch_[2];
    int adapt_ankle_roll_[2];
    int sequence_;
    int last_output_[NO_MOTORS];
    AdvanceLandingParamsType advance_params_[2];
    RetardLandingParamsType retard_params_[2];
    exo_trajectory::PreplannedInformation preplanned_;

    ros::Publisher control_state_publisher_;
    exo_msgs::ControlState::Ptr control_state_msg_;
    bool landing_enabled_;
    bool adaptation_enabled_;
    bool zero_test_enabled_;
    Point2DType zmp_;
    ros::NodeHandle nh_;
    ros::NodeHandle nhp_;
private:
    void fastInverseMatrix(double t,double outp[36]);
    double det33(double inp1,double inp2,double inp3,double inp4,double inp5,double inp6,double inp7,double inp8,double inp9);
    void doInverseKinematic(double z1_adv, double z1_ret, double z2_adv, double z2_ret, double outp[12]);

    double advancedLandingControl(int foot);
    double retardLandingControl(int index);
    int* landingControl();
    int* rawMotion();
    void sensorProcess();
    void footAdaptationControl(uint8_t right_left, int16_t* roll_c, int16_t* pitch_c);
    void zmpControl(uint8_t right_left, int16_t* roll, int16_t* pitch);
    double getSensorHeight(uint8_t foot_index, uint8_t sensor_number);
    double getFootHeight(int average_distance_in_count);
    int isTheFootParallel(uint8_t foot_index);
    double integral(double x, double f);
    ZMPPhaseType calculateZMP();
public:
    int* step(); // After setting the sensors' values this function should be called, the output is actuators' position in incremental encoder counts
    int* getCurrentSeqRowOutputs();
};

};

#endif
