#ifndef __PREPLANNED_INFO_H__
#define __PREPLANNED_INFO_H__

#include <stdio.h>
#include <ros/ros.h>
#include <exo_trajectory/exoinfo.h>
#include <boost/container/vector.hpp>
#include <boost/thread.hpp>
#include <boost/function.hpp>

namespace exo_trajectory {


typedef struct
{
    double z_preplanned[2];
    double dz_preplanned[2];
    double ddz_preplanned[2];
    double z_preplanned_w_correction[2];
    double dz_preplanned_w_correction[2];
    double ddz_preplanned_w_correction[2];
    double x_pelvis_preplanned; //DONE
    double y_pelvis_preplanned;
    double z_pelvis_preplanned;
    double alpha_pelvis_preplanned; //DONE
    double beta_pelvis_preplanned;
    double gamma_pelvis_preplanned;
    double x_preplanned[2];
    double y_preplanned[2];
    double alpha_preplanned[2];
    double beta_preplanned[2];
    double gamma_preplanned[2];
    double q_preplanned[12]; // Preplanned motion output (the IK is already done)
    uint8_t sensor_switch[2]; // NOTUSED // 1: Foot is grounded. 0: Foot is suspended
    uint8_t advance_check_enable[2]; // Do advance processing if this flag is enabled. Middle of the single support until begining of double support
    uint8_t retard_check_enable[2]; // Do advance processing if this flag is enabled. End of single support until the begining of next single support
    uint8_t current_steps[2]; // Current step no
} SequenceInfoType;

typedef struct
{
    uint32_t sensor_triggered_seqs; // Array of timings of touching/untouching of the sensors || Foot1_edge_Len
    uint32_t foot_state_changed_seqs; // Array of timings of touching/untouching of the foot || Foot1_edge_Len
} FootStateChangesType;

typedef struct
{
    uint32_t motion_len;
    uint32_t feet_state_change_len[2]; // No of steps * 2; foot state: when foot touches/untouches the ground
    uint32_t n_release; // No of sequences to release landing control
    double release_inv_matrix[36]; // Inversed matrix which is used to release landing control
    double time_step; // In seconds
    double delta_z;
    double Sensor_Thr; // In meters
    double delta_t_safety_factor; // NOTUSED
} MotionFileParamsType;

class PreplannedInformation
{
public:
    void step();
    PreplannedInformation();
    virtual ~PreplannedInformation();
    int loadPreplannedMotionFile();

private:

private:
    uint32_t cur_seq_;
    boost::container::vector<SequenceInfoType> sequences_info_;
public:
    boost::container::vector<bool> adaptation_enable[2];
    MotionFileParamsType params;
    SequenceInfoType cur_seq_info, prev_seq_info;

    boost::container::vector<FootStateChangesType> footplates_state_changes[2];
//    SequenceInfoType* sequence_info_;
//    FootStateChangesType* footplates_state_changes_[2];
};

};

#endif
