#include <exo_trajectory/trajectory.h>

using namespace ros;

int32_t min_limits[NO_MOTORS] = {-24240,-19392,-29088,-116352,-38784,-14544,-24240,-19392,-29088,-116352,-38784,-14544};
int32_t max_limits[NO_MOTORS] = {24240,19392,126048,969,24240,14544,24240,19392,126048,969,24240,14544};

namespace exo_trajectory {

TrajectoryGenerator::TrajectoryGenerator(ros::NodeHandle nh, ros::NodeHandle nhp) : nh_(nh), nhp_(nhp)
{
    // setup subscribers and publishers
    ROS_INFO("Running Trajectory Generator...");
    motor_command_publisher_ = nhp_.advertise<exo_msgs::MotorCommand>("/motors/command", 20);
    foot_range_sensors_subscriber_ = nhp_.subscribe("/robot/sensors/foot/range", 20, &TrajectoryGenerator::rangeSensorsDataCallback, this);
//    force_torque_sensors_subscriber_ = nhp_.subscribe("/robot/sensors/foot/force", 20, &TrajectoryGenerator::forceTorqueSensorsDataCallback, this);

    controller_a_ = ControllerA(&sensors_, false, false, false, nh_, nhp_); //landing_enable, adaptation_enable, zero_test_enable
}

TrajectoryGenerator::~TrajectoryGenerator()
{
}

void TrajectoryGenerator::rangeSensorsDataCallback(const exo_msgs::FootRangeSensors::ConstPtr& footRangeSensors)
{
    for (uint8_t i = 0; i < 4; ++i)
    {
        sensors_.foot_sensors[RIGHT].rangeSensors[i] = footRangeSensors->right[i];
        sensors_.foot_sensors[LEFT].rangeSensors[i] = footRangeSensors->left[i];
    }
    int* controlled_output = controller_a_.step();
    int* raw_output = controller_a_.getCurrentSeqRowOutputs();


    exo_msgs::MotorCommand::Ptr actuatorsMsg = boost::make_shared<exo_msgs::MotorCommand>();
    actuatorsMsg->header = footRangeSensors->header;
    for (int i = 0; i < NO_MOTORS; i++)
    {
        actuatorsMsg->positions[i] = controlled_output[i];
        if (actuatorsMsg->positions[i] > max_limits[i])
            actuatorsMsg->positions[i] = max_limits[i] - 1;
        if (actuatorsMsg->positions[i] < min_limits[i])
            actuatorsMsg->positions[i] = min_limits[i] + 1;
        actuatorsMsg->hypo_positions[i] = raw_output[i];
    }
    motor_command_publisher_.publish(actuatorsMsg);
    delete[] controlled_output;
    delete[] raw_output;
}

void TrajectoryGenerator::forceTorqueSensorsDataCallback(const exo_msgs::ForceTorqueSensor::ConstPtr& forceTorqueSensors)
{

}

}
