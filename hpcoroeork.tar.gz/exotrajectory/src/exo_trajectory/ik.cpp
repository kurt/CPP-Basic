#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <exo_trajectory/ik.h>

// codes from babak
void Hip_Joints_IK(double inp[3],double outp[4],int side)
{
	double ac1,ac2,ac3,as1,as2,as3;
	double mech_input[9];
	ac1=cos(inp[2]);
	as1=sin(inp[2]);

	ac2=cos(inp[0]);
	as2=sin(inp[0]);

	ac3=cos(inp[1]);
	as3=sin(inp[1]);

	mech_input[0]=ac1*ac2;
	mech_input[1]=-(as1*ac3)-(ac1*as2*as3);
	mech_input[2]=(as1*as3)-(ac1*as2*ac3);
	mech_input[3]=as1*ac2;
	mech_input[4]=(ac1*ac3)-(as1*as2*as3);
	mech_input[5]=-(ac1*as3)-(as1*as2*ac3);
	mech_input[6]=as2;
	mech_input[7]=ac2*as3;
	mech_input[8]=ac2*ac3;
	Hip_mech(mech_input,outp,side);

}
void Hip_mech(double inp[9],double outp[4],int dir)
{
	double L1,L2,L3,L4;
	double const1,const2,const3,const4;
	double a,b,c;
	double d[4];
	double sai,phi;
	double k1;
	double o1,o2,o3,o4;
	double ac,as,cq,sq;
	double a_m[6];
	double mid[4];
	double mid_inv[4];
	double p_inv[6];
	double b_m[3];
	double det;
	int sg;

	memset(&outp[0],0xFF,4*sizeof(double));

	L1=lh1;
	L2=lh2;
	L3=lh3;
	L4=lh4;

	if (dir==1)
	{
	    L1=-L1;
	}
	// index 2
	const1=1.704088191041846;//1/(1-uy^2);
	const2= -1.704088191041846;//-1/(1-uy^2);
	const3=2.030853223771491;//1/(uy*uz);
	const4=-1.305407289332279;//(-1/uz);

	a = (inp[4]*const1)+(inp[7]*const3);
	b = (inp[5]*const2)-(inp[8]*const3);
	c = -const2;;//%1/(1-uy^2);

	sai = atan2(b,a);
	k1=(a*a)+(b*b)-(c*c);
	if(k1<0)
	{
        printf("Invalid state for hip ik!!! it should not happen\n");
        exit(0);
	}

    phi = atan2(sqrt(k1),c);
    o3 = sai + phi;

	// index 1
	ac=cos(o3);
	as=sin(o3);

	a = const4*((inp[1]*ac)-(inp[2]*as));
	b = (-const3)*(inp[7]*ac-inp[8]*as)+1;
	o2 = atan2(a,b);


	// index3
	ac=cos(o2);
	as=sin(o2);

	a_m[0]=ac;
	a_m[1]=-uy*as;
	a_m[2]=uz*as;
	a_m[3]=uy*uz*(ac - 1);
	a_m[4]=-uy*as;
	a_m[5]=-(((1 - ac)*uz*uz) + ac);

	b_m[0]= inp[0];
	b_m[1]= inp[3];
	b_m[2]= inp[6];

	//calculate a_m'*a_m
	mid[0]=(a_m[0]*a_m[0])+(a_m[2]*a_m[2])+(a_m[4]*a_m[4]);
	mid[1]=(a_m[0]*a_m[1])+(a_m[2]*a_m[3])+(a_m[4]*a_m[5]);
	mid[2]=mid[1];
	mid[3]=(a_m[1]*a_m[1])+(a_m[3]*a_m[3])+(a_m[5]*a_m[5]);

	//finding inverse matrix
	det=(mid[0]*mid[3])-(mid[1]*mid[2]);
	mid_inv[0]=mid[3]/det;
	mid_inv[1]=-mid[1]/det;
	mid_inv[2]=-mid[2]/det;
	mid_inv[3]=mid[0]/det;

	//calculating pesudo inverse matrix
	//pa=mid_inv*A';
	p_inv[0]=(mid_inv[0]*a_m[0])+(mid_inv[1]*a_m[1]);
	p_inv[1]=(mid_inv[0]*a_m[2])+(mid_inv[1]*a_m[3]);
	p_inv[2]=(mid_inv[0]*a_m[4])+(mid_inv[1]*a_m[5]);
	p_inv[3]=(mid_inv[2]*a_m[0])+(mid_inv[3]*a_m[1]);
	p_inv[4]=(mid_inv[2]*a_m[2])+(mid_inv[3]*a_m[3]);
	p_inv[5]=(mid_inv[2]*a_m[4])+(mid_inv[3]*a_m[5]);


	//x = pa*b;
	a=(p_inv[0]*b_m[0])+(p_inv[1]*b_m[1])+(p_inv[2]*b_m[2]);
	b=(p_inv[3]*b_m[0])+(p_inv[4]*b_m[1])+(p_inv[5]*b_m[2]);

	o4 = atan2(b,a);

	// index 0
	ac=cos(o4);
	as=sin(o4);

	cq=cos(o2);
	sq=sin(o2);
	d[0]=(ac*L1*cq)-(uz*sq*L2)-(as*L1*uy*sq);
	d[1]=(uz*sq*ac*L1)+(L2*(cq+uy*uy*(1-cq)))-(uy*uz*(1-cq)*as*L1);
	d[2]=-(uy*sq*ac*L1)+(uy*uz*(1-cq)*L2)-((cq+uz*uz*(1-cq))*as*L1);
	d[3]=1;

	// finding sign (-L1)
	if(L1>0)
		sg=-1;
	else if (L1<0)
		sg=1;
	else
		sg=0;
	a = sg*2*L1*d[0];
	b = sg*2*L1*(L3-d[2]);
	c = sg*((L1*L1) + (L2*L2) + (L3*L3) - (L4*L4) - (2*L2*d[1]) - (2*L3*d[2]) + (d[0]*d[0]) + (d[1]*d[1]) + (d[2]*d[2]));

	sai = atan2(b,a);
	k1 = (a*a)+(b*b)-(c*c);

	if (k1<0)
	{
        printf("Invalid state for hip ik!!! It should not happen \n");
        exit(0);
	}

	phi = atan2(sqrt(k1),c);
	o1 = sai + phi;
	outp[0]=o1;
	outp[1]=o2;
	outp[2]=o3;
	outp[3]=o4;

}

void fast_inv(double inp[16],double outp[16])
{
	// this function calculate inverse of 4*4 matrix if the last row is [0 0 0 1]
	double a,b,c,d,e,f,g,h,i,j,k,l;
	double mydet,det_p1,det_p2,det_p3;

	a=inp[0];
	b=inp[1];
	c=inp[2];
	d=inp[3];

	e=inp[4];
	f=inp[5];
	g=inp[6];
	h=inp[7];

	i=inp[8];
	j=inp[9];
	k=inp[10];
	l=inp[11];

	det_p1=a*(f*k-j*g);
	det_p2=b*(e*k-i*g);
	det_p3=c*(e*j-i*f);
	mydet=1/(det_p1-det_p2+det_p3);


	outp[0]=((f*k)-(g*j))*mydet;  	//index 0
	outp[4]=(-(e*k)+(g*i))*mydet; 	//index 4
	outp[8]=((e*j)-(i*f))*mydet;  	//index 8
	outp[12]=0;		            	//index 12

	outp[1]=(-(b*k)+(c*j))*mydet;   //index 1
	outp[5]=((a*k)-(c*i))*mydet;    //index 5
	outp[9]=(-(a*j)+(b*i))*mydet;   //index 9
	outp[13]=0;     		        //index 13

	outp[2]=((b*g)-(f*c))*mydet;    //index 2
	outp[6]=(-(a*g)+(c*e))*mydet;   //index 6
	outp[10]=((a*f)-(b*e))*mydet;   //index 10
	outp[14]=0;              		//index 14

	outp[3]=(-(b*((g*l)-(k*h)))+(c*((f*l)-(h*j)))-(d*((f*k)-(g*j))))*mydet;  //index3
	outp[7]=((a*((g*l)-(k*h)))-(c*((e*l)-(i*h)))+(d*((e*k)-(g*i))))*mydet;   //index7
	outp[11]=(-(a*((f*l)-(h*j)))+(b*((e*l)-(h*i)))-(d*((e*j)-(f*i))))*mydet;  //index11
	outp[15]=((a*((f*k)-(g*j)))-(b*((e*k)-(g*i)))+(c*((e*j)-(f*i))))*mydet;   //index15
}
void ik(double* inp,double* outp)
{

	double T_0_p[16];
	double T_0_6r[16];
	double T_0_6l[16];
	double T_3r_6r[16];
	double T_3l_6l[16];
	double inv1[16];
	double inv2[16];
	double q1_r,q2_r,q3_r,q4_r,q5_r,q6_r;
	double q1_l,q2_l,q3_l,q4_l,q5_l,q6_l;
	double Sai_r,Sai_l;

	double alpha_p = inp[3];
	double beta_p = inp[4];
	double gamma_p = inp[5];
	double alpha_fr = inp[12];
	double beta_fr = inp[13];
	double gamma_fr = inp[14];
	double alpha_fl = inp[15];
	double beta_fl = inp[16];
	double gamma_fl = inp[17];


	// Pelvis
	//ostumized matrix multiplication
	double a=cos(gamma_p);
	double b=sin(gamma_p);
	double c=cos(beta_p);
	double d=sin(beta_p);
	double e=cos(alpha_p);
	double f=sin(alpha_p);

	T_0_p[0]=a*c;
	T_0_p[1]=(a*d*f)-(b*e);
	T_0_p[2]=(a*d*e)+(b*f);
	T_0_p[3]=inp[0];

	T_0_p[4]=b*c;
	T_0_p[5]=(b*d*f)+(a*e);
	T_0_p[6]=(b*d*e)-(a*f);
	T_0_p[7]=inp[1];

	T_0_p[8]=-d;
	T_0_p[9]=c*f;
	T_0_p[10]=c*e;
	T_0_p[11]=inp[2];

	T_0_p[12]=0;
	T_0_p[13]=0;
	T_0_p[14]=0;
	T_0_p[15]=1;


	// Ankle
	//ostumized matrix multiplication
	a=cos(gamma_fr);
	b=sin(gamma_fr);
	c=cos(beta_fr);
	d=sin(beta_fr);
	e=cos(alpha_fr);
	f=sin(alpha_fr);

	T_0_6r[0]=a*c;
	T_0_6r[1]=(a*d*f)-(b*e);
	T_0_6r[2]=(a*d*e)+(b*f);
	T_0_6r[3]=inp[6];

	T_0_6r[4]=b*c;
	T_0_6r[5]=(b*d*f)+(a*e);
	T_0_6r[6]=(b*d*e)-(a*f);
	T_0_6r[7]=inp[7];

	T_0_6r[8]=-d;
	T_0_6r[9]=c*f;
	T_0_6r[10]=c*e;
	T_0_6r[11]=inp[8];

	T_0_6r[12]=0;
	T_0_6r[13]=0;
	T_0_6r[14]=0;
	T_0_6r[15]=1;

	// costumized matrix multiplication
	a=cos(gamma_fl);
	b=sin(gamma_fl);
	c=cos(beta_fl);
	d=sin(beta_fl);
	e=cos(alpha_fl);
	f=sin(alpha_fl);


	T_0_6l[0]=a*c;
	T_0_6l[1]=(a*d*f)-(b*e);
	T_0_6l[2]=(a*d*e)+(b*f);
	T_0_6l[3]=inp[9];

	T_0_6l[4]=b*c;
	T_0_6l[5]=(b*d*f)+(a*e);
	T_0_6l[6]=(b*d*e)-(a*f);
	T_0_6l[7]=inp[10];

	T_0_6l[8]=-d;
	T_0_6l[9]=c*f;
	T_0_6l[10]=c*e;
	T_0_6l[11]=inp[11];

	T_0_6l[12]=0;
	T_0_6l[13]=0;
	T_0_6l[14]=0;
	T_0_6l[15]=1;

	fast_inv(T_0_6r,inv1);
	fast_inv(T_0_6l,inv2);

	a=T_0_p[3]-0.093*T_0_p[1];
	b=T_0_p[7]-0.093*T_0_p[5];
	c=T_0_p[11]-0.093*T_0_p[9];

	d=inv1[0]*a+inv1[1]*b+inv1[2]*c+inv1[3];
	e=inv1[4]*a+inv1[5]*b+inv1[6]*c+inv1[7];
	f=inv1[8]*a+inv1[9]*b+inv1[10]*c+inv1[11];
	double r_r = sqrt((d*d)+(e*e)+(f*f));


	double c4_r = ((r_r*r_r)-L_sh2-L_th2)*My_Coef;  // should me optimize during run

	if (abs(c4_r)<1)
	{
	    q4_r = atan2(sqrt(1-(c4_r*c4_r)),c4_r); // Knee Joint Pitch Y
	}
	else
	{
	    q4_r = 0;
	}


	q5_r=atan2(e,f); // Ankle Joint Roll X

	Sai_r=atan2(L_th*sin(q4_r),L_th*cos(q4_r)+L_sh);
	q6_r=atan2(-d,sqrt((e*e)+(f*f)))-Sai_r; // Ankle Joint Pitch Y

	//Customized matrix multiplication
	a=cos(q4_r);
	b=sin(q4_r);
	c=-L_sh*b;
	d=-(L_th+L_sh)*a;
	e=cos(q6_r);
	f=sin(q6_r);
	double g=cos(q5_r);
	double h=sin(q5_r);

	T_3r_6r[0]=a*e-b*f;
	T_3r_6r[1]=(a*f*h)+(b*e*h);
	T_3r_6r[2]=(a*f*g)+(b*e*g);
	T_3r_6r[3]=c;

	T_3r_6r[4]=0;
	T_3r_6r[5]=g;
	T_3r_6r[6]=-h;
	T_3r_6r[7]=0;

	T_3r_6r[8]=-b*e-a*f;
	T_3r_6r[9]=(a*e*h)-(b*f*h);
	T_3r_6r[10]=(a*e*g)-(b*f*g);
	T_3r_6r[11]=d;

	T_3r_6r[12]=0;
	T_3r_6r[13]=0;
	T_3r_6r[14]=0;
	T_3r_6r[15]=1;

	a= inv1[0]*T_0_p[2]+inv1[1]*T_0_p[6]+inv1[2]*T_0_p[10];  // this is index 1,3 of inv1*T_0_p
	b= inv1[4]*T_0_p[0]+inv1[5]*T_0_p[4]+inv1[6]*T_0_p[8];  // this is index 2,1 of inv1*T_0_p
	c= inv1[4]*T_0_p[1]+inv1[5]*T_0_p[5]+inv1[6]*T_0_p[9];  // this is index 2,2 of inv1*T_0_p
	d= inv1[4]*T_0_p[2]+inv1[5]*T_0_p[6]+inv1[6]*T_0_p[10];  // this is index 2,3 of inv1*T_0_p
	e= inv1[8]*T_0_p[0]+inv1[9]*T_0_p[4]+inv1[10]*T_0_p[8];  // this is index 3,1 of inv1*T_0_p
	f= inv1[8]*T_0_p[1]+inv1[9]*T_0_p[5]+inv1[10]*T_0_p[9];  // this is index 3,2 of inv1*T_0_p
	g= inv1[8]*T_0_p[2]+inv1[9]*T_0_p[6]+inv1[10]*T_0_p[10];  // this is index 3,3 of inv1*T_0_p
	h= inv1[12]*T_0_p[2]+inv1[13]*T_0_p[6]+inv1[14]*T_0_p[10];  // this is index 4,3 of inv1*T_0_p

	double aa=T_3r_6r[0]*a+T_3r_6r[1]*d+T_3r_6r[2]*g+T_3r_6r[3]*h; //this should be T_3r_0r(1,3)
	double bb=T_3r_6r[5]*b+T_3r_6r[6]*e; 							   //this should be T_3r_0r(2,1)
	double cc=T_3r_6r[5]*c+T_3r_6r[6]*f; 							   //this should be T_3r_0r(2,2)
	double dd=T_3r_6r[5]*d+T_3r_6r[6]*g; 							   //this should be T_3r_0r(2,3)
	double ee=T_3r_6r[8]*a+T_3r_6r[9]*d+T_3r_6r[10]*g+T_3r_6r[11]*h; //this should be T_3r_0r(3,3)



	q3_r = atan2(-bb,cc);
	q2_r = atan2(-aa,ee);
	q1_r = asin(dd);
	// Left

	//we just need 3 index of T_0_p*P_h_l, indexes (1,4),(2,4) and (3,4)
	a=(T_0_p[1]*0.5*L_pl)+T_0_p[3]; //index(1,4)
	b=(T_0_p[5]*0.5*L_pl)+T_0_p[7]; //index(2,4)
	c=(T_0_p[9]*0.5*L_pl)+T_0_p[11]; //index(3,4)
	d=inv2[0]*a+inv2[1]*b+inv2[2]*c+inv2[3];
	e=inv2[4]*a+inv2[5]*b+inv2[6]*c+inv2[7];
	f=inv2[8]*a+inv2[9]*b+inv2[10]*c+inv2[11];


	double r_l = sqrt((d*d)+(e*e)+(f*f));

	double c4_l = ((r_l*r_l)-L_sh2-L_th2)*My_Coef;
	if (abs(c4_l)<1)
	{
	    q4_l = atan2(sqrt(1-(c4_l*c4_l)),c4_l); // Knee Joint Y
	}
	else
	{
	    q4_l = 0;
	}


	q5_l=atan2(e,f); // Ankle Joint Roll X

	Sai_l=atan2(L_th*sin(q4_l),L_th*cos(q4_l)+L_sh);
	q6_l=atan2(-d,sqrt(e*e+f*f))-Sai_l; //Ankle Joint Pitch Y


	//costumized matrix multiplication
	a=cos(q4_l);
	b=sin(q4_l);
	c=cos(q6_l);
	d=sin(q6_l);
	e=cos(q5_l);
	f=sin(q5_l);

	T_3l_6l[0]=a*c-b*d;
	T_3l_6l[1]=f*(a*d+b*c);
	T_3l_6l[2]=e*(a*d+b*c);
	T_3l_6l[3]=b*L_sh;

	T_3l_6l[4]=0;
	T_3l_6l[5]=e;
	T_3l_6l[6]=-f;
	T_3l_6l[7]=0;

	T_3l_6l[8]=-b*c-a*d;
	T_3l_6l[9]=f*(a*c-b*d);
	T_3l_6l[10]=e*(a*c-b*d);
	T_3l_6l[11]=-a*L_sh-L_th;

	T_3l_6l[12]=0;
	T_3l_6l[13]=0;
	T_3l_6l[14]=0;
	T_3l_6l[15]=1;

	//costumized matrix multiplication

	a= inv2[0]*T_0_p[2]+inv2[1]*T_0_p[6]+inv2[2]*T_0_p[10];  // this is index 1,3 of inv2*T_0_p
	b= inv2[4]*T_0_p[0]+inv2[5]*T_0_p[4]+inv2[6]*T_0_p[8];  // this is index 2,1 of inv2*T_0_p
	c= inv2[4]*T_0_p[1]+inv2[5]*T_0_p[5]+inv2[6]*T_0_p[9];  // this is index 2,2 of inv2*T_0_p
	d= inv2[4]*T_0_p[2]+inv2[5]*T_0_p[6]+inv2[6]*T_0_p[10];  // this is index 2,3 of inv2*T_0_p
	e= inv2[8]*T_0_p[0]+inv2[9]*T_0_p[4]+inv2[10]*T_0_p[8];  // this is index 3,1 of inv2*T_0_p
	f= inv2[8]*T_0_p[1]+inv2[9]*T_0_p[5]+inv2[10]*T_0_p[9];  // this is index 3,2 of inv2*T_0_p
	g= inv2[8]*T_0_p[2]+inv2[9]*T_0_p[6]+inv2[10]*T_0_p[10];  // this is index 3,3 of inv2*T_0_p
	h= inv2[12]*T_0_p[2]+inv2[13]*T_0_p[6]+inv2[14]*T_0_p[10];  // this is index 4,3 of inv2*T_0_p

	aa=T_3l_6l[0]*a+T_3l_6l[1]*d+T_3l_6l[2]*g+T_3l_6l[3]*h; 	//this should be T_3r_0r(1,3)
	bb=T_3l_6l[5]*b+T_3l_6l[6]*e; 									//this should be T_3r_0r(2,1)
	cc=T_3l_6l[5]*c+T_3l_6l[6]*f; 									//this should be T_3r_0r(2,2)
	dd=T_3l_6l[5]*d+T_3l_6l[6]*g; 									//this should be T_3r_0r(2,3)
	ee=T_3l_6l[8]*a+T_3l_6l[9]*d+T_3l_6l[10]*g+T_3l_6l[11]*h; 	//this should be T_3r_0r(3,3)

	q3_l = atan2(-bb,cc);
	q2_l = atan2(-aa,ee);
	q1_l = asin(dd);

	outp[0]=q1_r;
	outp[1]=q2_r;
	outp[2]=q3_r;
	outp[3]=q4_r;
	outp[4]=q5_r;
	outp[5]=q6_r;

	outp[6]=q1_l;
	outp[7]=q2_l;
	outp[8]=q3_l;
	outp[9]=q4_l;
	outp[10]=q5_l;
	outp[11]=q6_l;

}
