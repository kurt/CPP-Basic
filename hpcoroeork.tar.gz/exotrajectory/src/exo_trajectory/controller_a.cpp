#include <exo_trajectory/controller_a.h>

namespace exo_trajectory {

ControllerA::ControllerA()
{
    ROS_INFO("ControllerA Constructor");
}

ControllerA::ControllerA(Sensors* sensors, bool landing_enable, bool adaptation_enable, bool zero_test_enable, ros::NodeHandle nh, ros::NodeHandle nhp) : nh_(nh), nhp_(nhp)
{
    control_state_msg_ = boost::make_shared<exo_msgs::ControlState>();
    landing_enabled_ = false;
    adaptation_enabled_ = false;
    zero_test_enabled_ = false;
    sequence_ = 0;
    for (int foot = 0; foot < 2; ++foot)
    {
        advance_params_[foot] = {};
        retard_params_[foot] = {};
        no_touched_range_sensors_[foot] = 0;
        adapt_ankle_pitch_[foot] = 0;
        adapt_ankle_roll_[foot] = 0;
    }

    ROS_INFO("ControllerA - Second Constructor");
    landing_enabled_ = landing_enable;
    adaptation_enabled_ = adaptation_enable;
    zero_test_enabled_ = zero_test_enable;
    sensors_ptr_ = sensors;
    preplanned_.loadPreplannedMotionFile();
    //TODO: Remove this
    ROS_INFO("n_release: %d", preplanned_.params.n_release);
    ROS_INFO("time_step: %f", preplanned_.params.time_step);
    //
    //TODO: Refactor this part
    double delta_t_mod_ret = 1.0;
    double mid_r = 0.3;
    double delta_t_mod_mid = mid_r * delta_t_mod_ret;
    double delta_t_mod_end = (1-mid_r) * delta_t_mod_ret;
    fastInverseMatrix(delta_t_mod_mid,retard_params_[RIGHT].a_coef_ret_inv_mid);
    fastInverseMatrix(delta_t_mod_end,retard_params_[RIGHT].a_coef_ret_inv_end);

    retard_params_[RIGHT].sequence_part1_end = (int)((mid_r * delta_t_mod_ret) / preplanned_.params.time_step) + 1;
    retard_params_[RIGHT].sequence_part2_end = (int)(delta_t_mod_ret / preplanned_.params.time_step) + 1;

    ROS_INFO("part1_end: %d", retard_params_[RIGHT].sequence_part1_end);
    ROS_INFO("part2_end: %d", retard_params_[RIGHT].sequence_part2_end);

    memcpy(&retard_params_[LEFT].a_coef_ret_inv_mid[0],&retard_params_[RIGHT].a_coef_ret_inv_mid[0],36*sizeof(double));
    memcpy(&retard_params_[LEFT].a_coef_ret_inv_end[0],&retard_params_[RIGHT].a_coef_ret_inv_end[0],36*sizeof(double));

    retard_params_[LEFT].sequence_part1_end = retard_params_[RIGHT].sequence_part1_end;
    retard_params_[LEFT].sequence_part2_end = retard_params_[RIGHT].sequence_part2_end;
    //

    control_state_publisher_ = nhp_.advertise<exo_msgs::ControlState> ("/control/states", 20);
}

ControllerA::~ControllerA()
{

}

double ControllerA::getSensorHeight(uint8_t foot_index, uint8_t sensor_index)
{
    double theta = sensors_ptr_->foot_sensors[foot_index].rangeSensors[sensor_index] / RANGE_SENSOR_CPR * 2 * PI_NUMBER;
    return (2 * RANGE_SENSOR_ARM_LENGTH * sin(theta / 2) * cos(THETA_0 + (theta / 2)));
}

double ControllerA::getFootHeight(int average_distance_in_count)
{
    double theta = average_distance_in_count / RANGE_SENSOR_CPR * 2 * PI_NUMBER;
    return (2 * RANGE_SENSOR_ARM_LENGTH * sin(theta / 2) * cos(THETA_0 + (theta / 2)));
}

/**
 * @brief This function should be called in each step of the control.
 * @param
 * @retval Returns controlled position values for all actuators.
 *         Output memory should be deleted after getting used.
 */
int* ControllerA::step()
{
    int32_t* controlled_output = new int32_t[NO_MOTORS];
    if (zero_test_enabled_)
        for (int i = 0; i < NO_MOTORS; ++i)
            controlled_output[i] = 0;
    else if (landing_enabled_)
        controlled_output = landingControl();
    else // Need actuators' positions to do the adaptation
        controlled_output = rawMotion();

    int16_t roll_c[2] = {0}, pitch_c[2] = {0};
    footAdaptationControl(RIGHT, &roll_c[RIGHT], &pitch_c[RIGHT]);
    footAdaptationControl(LEFT, &roll_c[LEFT], &pitch_c[LEFT]);
    control_state_msg_->adaptationEnable[RIGHT] = 0.25;
    control_state_msg_->adaptationEnable[LEFT] = 0.25;
    if (adaptation_enabled_)
    {
        // Calculate adaptation values
        if (!retard_params_[RIGHT].is_retard_happend)
            cur_step_adaptation_enable_[RIGHT] = (preplanned_.cur_seq_info.advance_check_enable[RIGHT] == 1);
        else
            cur_step_adaptation_enable_[RIGHT] = preplanned_.adaptation_enable[RIGHT][sequence_];
        if (cur_step_adaptation_enable_[RIGHT])
        {
            // Pitch, Right
            adapt_ankle_pitch_[RIGHT] += -pitch_c[RIGHT];
            // Roll, Right
            adapt_ankle_roll_[RIGHT] += -roll_c[RIGHT];
        }
        if (!retard_params_[LEFT].is_retard_happend)
            cur_step_adaptation_enable_[LEFT] = (preplanned_.cur_seq_info.advance_check_enable[LEFT] == 1);
        else
            cur_step_adaptation_enable_[LEFT] = preplanned_.adaptation_enable[LEFT][sequence_];
        if (cur_step_adaptation_enable_[LEFT])
        {
            // Pitch, Left
            adapt_ankle_pitch_[LEFT] += -pitch_c[LEFT];
            // Roll, Left
            adapt_ankle_roll_[LEFT] += roll_c[LEFT];
        }
        controlled_output[4] += adapt_ankle_pitch_[RIGHT];
        controlled_output[5] += adapt_ankle_roll_[RIGHT];
        controlled_output[10] += adapt_ankle_pitch_[LEFT];
        controlled_output[11] += adapt_ankle_roll_[LEFT];
    }

    for (int foot = 0; foot < 2; ++foot)
    {
        control_state_msg_->adaptAnklePitch[foot] = adapt_ankle_pitch_[foot];
        control_state_msg_->adaptAnkleRoll[foot] = adapt_ankle_roll_[foot];
        control_state_msg_->advanceCheckEnable[foot] = (float)(preplanned_.cur_seq_info.advance_check_enable[foot]) + 0.15;
        control_state_msg_->retardCheckEnable[foot] = (float)(preplanned_.cur_seq_info.retard_check_enable[foot]) + 0.2;
        control_state_msg_->adaptationEnable[foot] = (float)(cur_step_adaptation_enable_[foot]) + 0.25;
    }

    control_state_msg_->header.stamp = ros::Time::now();
    control_state_publisher_.publish(control_state_msg_);
    preplanned_.step();
    sequence_++;
    return controlled_output;
}

int* ControllerA::getCurrentSeqRowOutputs()
{
    int32_t* output = new int32_t[NO_MOTORS];
    output = rawMotion();
    return output;
}

void ControllerA::fastInverseMatrix(double t,double outp[36])
{
    //step1 1 calculate 12 vals
    double cofactor[36];

    double val1=pow(t,5);
    double val2=pow(t,4);
    double val3=pow(t,3);
    double val4=pow(t,2);
    double val5=t;
    double val6=5*val2;
    double val7=4*val3;
    double val8=3*val4;
    double val9=2*val5;
    double val10=20*val3;
    double val11=12*val4;
    double val12=6*val5;

    double total_det=2* det33(val1,val2,val3,val6,val7,val8,val10,val11,val12);
    memset(&outp[0],0,36*sizeof(double));
    if(total_det==0)
    {
        printf("\ndeterminane is zero, can not inverse the matrix");
        return;
    }
    cofactor[0]=-2*((val7*val12)-(val8*val11));
    cofactor[6]=2*((val6*val12)-(val8*val10));
    cofactor[12]=-2*((val6*val11)-(val7*val10));
    cofactor[18]=0;
    cofactor[24]=0;
    cofactor[30]=total_det;

    cofactor[1]=-2*((val5*((val7*val12)-(val8*val11)))-((val2*val12)-(val3*val11)));
    cofactor[7]=2*((val5*((val6*val12)-(val8*val10)))-((val1*val12)-(val3*val10)));
    cofactor[13]=-2*((val5*((val6*val11)-(val7*val10)))-((val1*val11)-(val2*val10)));
    cofactor[19]=0;
    cofactor[25]=total_det;
    cofactor[31]=0;

    cofactor[2]=-det33(val2,val3,val4,val7,val8,val9,val11,val12,2);
    cofactor[8]=det33(val1,val3,val4,val6,val8,val9,val10,val12,2);
    cofactor[14]=-det33(val1,val2,val4,val6,val7,val9,val10,val11,2);
    cofactor[20]=total_det/2;
    cofactor[26]=0;
    cofactor[32]=0;

    cofactor[3]=2*((val7*val12)-(val8*val11));
    cofactor[9]=-2*((val6*val12)-(val8*val10));
    cofactor[15]=2*((val6*val11)-(val7*val10));
    cofactor[21]=0;
    cofactor[27]=0;
    cofactor[33]=0;

    cofactor[4]=-2*((val2*val12)-(val3*val11));
    cofactor[10]=2*((val1*val12)-(val3*val10));
    cofactor[16]=-2*((val1*val11)-(val2*val10));;
    cofactor[22]=0;
    cofactor[28]=0;
    cofactor[34]=0;

    cofactor[5]=2*((val2*val8)-(val3*val7));
    cofactor[11]=-2*((val1*val8)-(val3*val6));
    cofactor[17]=2*((val1*val7)-(val2*val6));
    cofactor[23]=0;
    cofactor[29]=0;
    cofactor[35]=0;
    // now it is ready to multiply matrix
    int i;

    for(i=0;i<36;i++)
    {
        outp[i]=cofactor[i]/total_det;
    }
}

int ControllerA::isTheFootParallel(uint8_t foot_index)
{
    int sum_sensors = 0;
    if (no_touched_range_sensors_[foot_index] > 2)
    {
        for (int i = 0; i < 4; ++i)
            sum_sensors += sensors_ptr_->foot_sensors[foot_index].rangeSensors[i];
        for (int i = 0; i < 4; ++i)
            if (abs(sensors_ptr_->foot_sensors[foot_index].rangeSensors[i] - sum_sensors / 4) > PARALLEL_THRESHOLD)
                return -1;
        return (sum_sensors / 4);
    }
    return -1;
}

// State estimation - Status monitor
void ControllerA::sensorProcess()
{
    int sensor_switch[2] = {0};
    int delta_n;
    double delta_t;
    double temp_matrix[36];
    double z_rls;
    double b_coef[6];
    int i,j;
    double temp,h;
    int endseq_index, endsequence2;
    int foot_height = 0;

    for (uint8_t foot = 0; foot < 2; ++foot)
    {
        foot_height = isTheFootParallel(foot);
        if (foot_height != -1)
        {
            sensor_switch[foot] = 1;
        }
        if (no_touched_range_sensors_[foot] == 0)
        {
            sensor_switch[foot] = 0;
        }
        // Process for foot1
        // managing advance process enable
        if (advance_params_[foot].is_advance_happend == true)
        {
            //manage disabling advance process
            if(sequence_>advance_params_[foot].sequence_phase3_end)
            {
                advance_params_[foot].is_advance_happend = false;
            }
        }
        else
        {
           //manage enabling advance process
           // check only in check enable region
           if((preplanned_.cur_seq_info.advance_check_enable[foot] == 1) && (advance_params_[foot].prev_sensor_value == 0) && (sensor_switch[foot] == 1))// % this is the moment of advance
           {
               advance_params_[foot].is_advance_happend = true;
               advance_params_[foot].z_expected_at_advance = preplanned_.cur_seq_info.z_preplanned[foot];//save touchdown at the advance moment
               advance_params_[foot].sequence_advance = sequence_;
               advance_params_[foot].z_touched = getFootHeight(foot_height);
               preplanned_.params.delta_z = advance_params_[foot].z_touched;
//               ROS_INFO("SEQ: %d, z_touched: %f, HEIGHT_CNT: %d", sequence_, advance_params_[foot].z_touched, foot_height);
               //generating matrix
               // TODO: DO IT WHEN THE FOOT IS PARALLEL
               delta_n = preplanned_.footplates_state_changes[foot][2 * preplanned_.cur_seq_info.current_steps[foot] - 1].foot_state_changed_seqs - sequence_;
               if ((delta_n) > 70)
               {
                   delta_n = 70;
                   advance_params_[foot].sequence_phase1_end = sequence_ + 70;
               }
               else
                   advance_params_[foot].sequence_phase1_end = preplanned_.footplates_state_changes[foot][2 * preplanned_.cur_seq_info.current_steps[foot] - 1].foot_state_changed_seqs;//% this is preplanned rising edge of foot1 sensor switch
               advance_params_[foot].sequence_phase2_end = preplanned_.footplates_state_changes[foot^1][2 * preplanned_.cur_seq_info.current_steps[foot^1]].foot_state_changed_seqs;// this is preplaned falling edge of foot2 sensor switch
               advance_params_[foot].sequence_phase3_end = preplanned_.params.n_release + advance_params_[foot].sequence_phase2_end;//%Motion.Sensor_edge_foot2(2*status.Step_Foot2+2); % this is preplaned falling edge of foot2 sensor switch

               delta_t = delta_n * preplanned_.params.time_step;
//               ROS_INFO("delta_n: %d, time_step: %f", delta_n, preplanned_.params.time_step);
               fastInverseMatrix(delta_t,advance_params_[foot].advance_coef_matrix);

               b_coef[0] = {0};
               b_coef[1] = preplanned_.cur_seq_info.dz_preplanned[foot];
               b_coef[2] = preplanned_.cur_seq_info.ddz_preplanned[foot];
               b_coef[3] = -preplanned_.params.delta_z;
               b_coef[4] = {0};
               b_coef[5] = {0};
               for(i = 0; i < 6; ++i)
               {
                  double temp = 0;
                  for(j = 0; j < 6; ++j)
                  {
                     temp += (advance_params_[foot].advance_coef_matrix[(6 * i) + j] * b_coef[j]);
                  }
                  advance_params_[foot].advance_c_coef[i] = temp;
               }
//               for(uint8_t i = 0; i < 36; i+=6)
//                   ROS_INFO("%f, %f, %f, %f, %f, %f", advance_params_[foot].advance_coef_matrix[i], advance_params_[foot].advance_coef_matrix[i+1],
//                                                      advance_params_[foot].advance_coef_matrix[i+2], advance_params_[foot].advance_coef_matrix[i+3],
//                                                      advance_params_[foot].advance_coef_matrix[i+4], advance_params_[foot].advance_coef_matrix[i+5]);
//               ROS_INFO("current_seq: %d, sequence_phase1_end: %d, delta_t:%d", sequence_, advance_params_[foot].sequence_phase1_end, advance_params_[foot].sequence_phase1_end - sequence_);
//               ROS_INFO("sequence_phase2_end: %d", advance_params_[foot].sequence_phase2_end);
//               ROS_INFO("sequence_phase3_end: %d", advance_params_[foot].sequence_phase3_end);
//               ROS_INFO("dz: %f, ddz: %f", preplanned_.cur_seq_info.dz_preplanned[foot], preplanned_.cur_seq_info.ddz_preplanned[foot]);
           }
        }
        //managing retard
        if (retard_params_[foot].is_retard_happend == true)
        {
            // manage disabling retard process
            if(sequence_>retard_params_[foot].sequence_phase3_end)
            {
                //this is start of next step
                retard_params_[foot].is_retard_happend = false;
            }

            // Stage 1: Sensors haven't touched the ground yet
            if(retard_params_[foot].retard_process_stage == 1)
            {
                if((sensor_switch[foot] == 1) && (advance_params_[foot].prev_sensor_value == 0)) //this is moment of retard
                {
                    //manage moment of stage 2
                    preplanned_.params.delta_z = getFootHeight(foot_height);
                    ROS_INFO("SEQ: %d, retard_delta_z: %f, foot: %d", sequence_, preplanned_.params.delta_z, foot);
                    retard_params_[foot].sequence_retard_happen = sequence_;

                    retard_params_[foot].retard_z_preplanned = preplanned_.cur_seq_info.z_preplanned[foot];
                    double Dfz_foot_online_ret = retard_params_[foot].z_retard;
                    double z_end_poly = Dfz_foot_online_ret - preplanned_.params.delta_z + retard_params_[foot].retard_z_preplanned;

                    ROS_INFO("sequence_num: %d, z_end_poly: %f, z_retard: %f, Retard_Z_Preplanned: %f", sequence_, z_end_poly, retard_params_[foot].z_retard, retard_params_[foot].retard_z_preplanned);

                    retard_params_[foot].retard_phase1_part1_end = retard_params_[foot].sequence_retard_happen + retard_params_[foot].sequence_part1_end;
                    retard_params_[foot].retard_phase1_part2_end = retard_params_[foot].sequence_retard_happen + retard_params_[foot].sequence_part2_end;

                    b_coef[0] = Dfz_foot_online_ret;
                    b_coef[1] = retard_params_[foot].dZ_Retard;
                    b_coef[2] = retard_params_[foot].ddZ_Retard;
                    b_coef[3] = 0.86 * z_end_poly;
                    b_coef[4] = -0.0007;
                    b_coef[5] = 0.004;
                    for(i = 0; i < 6; ++i)
                    {
                        temp=0;
                        for(j=0;j<6;j++)
                        {
                            temp += (retard_params_[foot].a_coef_ret_inv_mid[(6*i)+j]*b_coef[j]);
                        }
                        retard_params_[foot].c_coef_part1[i] = temp;
                    }
                    z_rls = z_end_poly;

                    b_coef[0] = 0.86* z_end_poly;
                    b_coef[1] = -0.0007;
                    b_coef[2] = 0.004;
                    b_coef[3] = z_end_poly;
                    b_coef[4] = 0;
                    b_coef[5] = 0;
                    for(i=0;i<6;i++)
                    {
                        temp=0;
                        for(j=0;j<6;j++)
                        {
                            temp += (retard_params_[foot].a_coef_ret_inv_end[(6*i)+j]*b_coef[j]);
                        }
                        retard_params_[foot].c_coef_part2[i]=temp;
                    }
//                    z_rls = retard_params_[foot].z_retard - preplanned_.params.delta_z;
//                    b_coef[0] = retard_params_[foot].z_retard;
//                    b_coef[1] = retard_params_[foot].dZ_Retard;
//                    b_coef[2] = retard_params_[foot].ddZ_Retard;
//                    b_coef[3] = z_rls;
//                    b_coef[4] = 0;
//                    b_coef[5] = 0;
//                    for(i = 0; i < 6; ++i)
//                    {
//                        temp = 0;
//                        for(j = 0; j < 6; ++j)
//                        {
//                            temp += (temp_matrix[(6 * i) + j] * b_coef[j]);
//                        }
//                        retard_params_[foot].retard_c_coef[i] = temp;
//                    }

                    for(i = 0; i < 6; ++i)
                    {

                        retard_params_[foot].retard_c_rls[i] = preplanned_.params.release_inv_matrix[6 * i] * z_rls;
                    }
                    retard_params_[foot].retard_process_stage = 2;
                    ROS_INFO("retard_phase1_part1_end: %d", retard_params_[foot].retard_phase1_part1_end);
                    ROS_INFO("retard_phase1_part2_end: %d", retard_params_[foot].retard_phase1_part2_end);
                }
                else //we are in stage 1, just updating a recursive buffer - sensors haven't touched the ground yet
                {
                    h = 0.0001;
                    retard_params_[foot].z_retard = -(sequence_- retard_params_[foot].sequence_retard_start) * h;
                    retard_params_[foot].dZ_Retard = (retard_params_[foot].z_retard-retard_params_[foot].z_buffer[0]) / preplanned_.params.time_step;
                    retard_params_[foot].ddZ_Retard = (retard_params_[foot].z_retard - 2 * retard_params_[foot].z_buffer[0] + retard_params_[foot].z_buffer[1]) / (preplanned_.params.time_step * preplanned_.params.time_step);
                    retard_params_[foot].z_buffer[1] = retard_params_[foot].z_buffer[0];
                    retard_params_[foot].z_buffer[0] = retard_params_[foot].z_retard;
                    ROS_INFO("retard_stage1_sequence_num: %d, z_retard: %f", sequence_, retard_params_[foot].z_retard);
                }
            }
        }
        else if (!advance_params_[foot].is_advance_happend)
        {
            // manage enabling retard process
            // check only in check enable region
            // Check to see if retard is happend or not.
            if((preplanned_.cur_seq_info.retard_check_enable[foot] == 1) && (sensor_switch[foot] == 0)) // this is first stage of retard
            {
                retard_params_[foot].is_retard_happend = true;
                retard_params_[foot].retard_process_stage = 1;
                retard_params_[foot].z_retard = 0;
                retard_params_[foot].dZ_Retard = 0;
                retard_params_[foot].ddZ_Retard = 0;

                retard_params_[foot].z_buffer[0] = 0;
                retard_params_[foot].z_buffer[1] = 0;
                retard_params_[foot].sequence_retard_start = sequence_;
               //generating matrix
                endseq_index = 2 * preplanned_.cur_seq_info.current_steps[foot^1];
                if (endseq_index < preplanned_.params.feet_state_change_len[foot^1])
                {
                    endsequence2 = preplanned_.footplates_state_changes[foot^1][endseq_index].sensor_triggered_seqs;
                }
                else
                {
                    // The motion is going to be finished
                    endsequence2 = preplanned_.params.motion_len - 1;
                    ROS_ERROR("warning!!! index overflow in finding foot2 release sequence");
                }
                retard_params_[foot].retard_phase1_part1_end = 0;
                retard_params_[foot].retard_phase1_part2_end = 0;
                retard_params_[foot].sequence_phase2_end = endsequence2;
                retard_params_[foot].sequence_phase3_end = preplanned_.params.n_release + retard_params_[foot].sequence_phase2_end;
                ROS_INFO("retard is happened at seq: %d", sequence_);
                ROS_INFO("retard_sequence_phase2_end: %d", retard_params_[foot].sequence_phase2_end);
                ROS_INFO("retard_sequence_phase3_end: %d", retard_params_[foot].sequence_phase3_end);
            }
        }
    }
    // Process for foot2
    // managing advance process enable
    advance_params_[RIGHT].prev_sensor_value = sensor_switch[RIGHT];
    advance_params_[LEFT].prev_sensor_value = sensor_switch[LEFT];
}

// Index: LEFT or RIGHT foot
double ControllerA::advancedLandingControl(int foot)
{
      double outp;
      double coef[6] = {0};
      double Dfz_foot_online;
      int i,j;
      int ds;
      double dt;
      outp = 0;

      Dfz_foot_online = advance_params_[foot].z_expected_at_advance - preplanned_.cur_seq_info.z_preplanned[foot];
      if (sequence_ < advance_params_[foot].sequence_phase1_end)
      {
          ds = sequence_ - advance_params_[foot].sequence_advance;
          dt = ds * preplanned_.params.time_step;
          double val[5] = {0};
          val[0] = pow(dt,5);
          val[1] = pow(dt,4);
          val[2] = pow(dt,3);
          val[3] = pow(dt,2);
          val[4] = dt;

          double z_mod1 = advance_params_[foot].advance_c_coef[0]*val[0] + advance_params_[foot].advance_c_coef[1]*val[1] + advance_params_[foot].advance_c_coef[2]*val[2] + advance_params_[foot].advance_c_coef[3]*val[3] + advance_params_[foot].advance_c_coef[4]*val[4] + advance_params_[foot].advance_c_coef[5];
          outp = Dfz_foot_online + z_mod1;
      }
      else if (sequence_ <= advance_params_[foot].sequence_phase2_end)
      {
          outp = Dfz_foot_online - preplanned_.params.delta_z;
      }
      else if (sequence_ < advance_params_[foot].sequence_phase3_end)
      {
          double z_rls = Dfz_foot_online - preplanned_.params.delta_z;
          for(i = 0; i < 6; ++i)
             coef[i] = preplanned_.params.release_inv_matrix[6 * i] * z_rls;

          ds = sequence_ - advance_params_[foot].sequence_phase2_end;
          dt = ds*preplanned_.params.time_step;
          double val1 = pow(dt,5);
          double val2 = pow(dt,4);
          double val3 = pow(dt,3);
          double val4 = pow(dt,2);
          double val5 = dt;

          outp = coef[0]*val1 + coef[1]*val2 + coef[2]*val3 + coef[3]*val4 + coef[4]*val5 + coef[5];
      }
      else
      {
          outp = 0;
      }
      return outp;
}

double ControllerA::retardLandingControl(int foot)
{
    double outp;
    double dt;
    outp = 0;
    if (retard_params_[foot].retard_process_stage == 1)
    {
       outp = retard_params_[foot].z_retard;

    }
    else if (retard_params_[foot].retard_process_stage == 2)
    {
       if  (sequence_ < retard_params_[foot].retard_phase1_part1_end)
       {
           dt = (sequence_-retard_params_[foot].sequence_retard_happen) * preplanned_.params.time_step;
           double val1 = pow(dt,5);
           double val2 = pow(dt,4);
           double val3 = pow(dt,3);
           double val4 = pow(dt,2);
           double val5 = dt;

           outp = retard_params_[foot].c_coef_part1[0]*val1 + retard_params_[foot].c_coef_part1[1]*val2 + retard_params_[foot].c_coef_part1[2]*val3+ retard_params_[foot].c_coef_part1[3]*val4 + retard_params_[foot].c_coef_part1[4]*val5 + retard_params_[foot].c_coef_part1[5];
       }
       else if (sequence_ <= retard_params_[foot].retard_phase1_part2_end)
       {
           dt = (sequence_ - retard_params_[foot].sequence_retard_happen) * preplanned_.params.time_step-0.3;
           double val1=pow(dt,5);
           double val2=pow(dt,4);
           double val3=pow(dt,3);
           double val4=pow(dt,2);
           double val5=dt;

           outp = retard_params_[foot].c_coef_part2[0]*val1 + retard_params_[foot].c_coef_part2[1]*val2 + retard_params_[foot].c_coef_part2[2]*val3+ retard_params_[foot].c_coef_part2[3]*val4 + retard_params_[foot].c_coef_part2[4]*val5 + retard_params_[foot].c_coef_part2[5];
       }
       else if (sequence_ <= retard_params_[foot].sequence_phase2_end)
       {
           outp = retard_params_[foot].retard_z_preplanned + retard_params_[foot].z_retard - preplanned_.params.delta_z;
       }
       else if (sequence_ <= retard_params_[foot].sequence_phase3_end)
       {
           dt=(sequence_-retard_params_[foot].sequence_phase2_end)*preplanned_.params.time_step;
           double val1=pow(dt,5);
           double val2=pow(dt,4);
           double val3=pow(dt,3);
           double val4=pow(dt,2);
           double val5=dt;
           outp = retard_params_[foot].retard_c_rls[0]*val1 + retard_params_[foot].retard_c_rls[1]*val2 + retard_params_[foot].retard_c_rls[2]*val3 + retard_params_[foot].retard_c_rls[3]*val4 + retard_params_[foot].retard_c_rls[4]*val5 + retard_params_[foot].retard_c_rls[5];
       }
    }

   return outp;
}

int* ControllerA::landingControl()
{
    double outp[NO_MOTORS] = {0};
    int* outp_incounts = new int[NO_MOTORS];

    double ik_out[12];
    memset(&ik_out[0],0,sizeof(ik_out));
    double z_adv[2] = {0},z_ret[2] = {0};

    sensorProcess();

    if(advance_params_[RIGHT].is_advance_happend == true)
    {
        z_adv[RIGHT] = advancedLandingControl(RIGHT);
    }
    if(advance_params_[LEFT].is_advance_happend == true)
    {
        z_adv[LEFT] = advancedLandingControl(LEFT);
    }
    if(retard_params_[RIGHT].is_retard_happend == true)
    {
        z_ret[RIGHT] = retardLandingControl(RIGHT);
    }
    if(retard_params_[LEFT].is_retard_happend == true)
    {
        z_ret[LEFT] = retardLandingControl(LEFT);
    }

    for (int foot = 0; foot < 2; ++foot)
    {
        control_state_msg_->advanceIsHappened[foot] = (float)(advance_params_[foot].is_advance_happend) + 0.05;
        control_state_msg_->retardIsHappened[foot] = (float)(retard_params_[foot].is_retard_happend) + 0.1;
        control_state_msg_->z_preplanned[foot] = preplanned_.cur_seq_info.z_preplanned[foot];
        control_state_msg_->z_controlled[foot] = preplanned_.cur_seq_info.z_preplanned[foot] + z_adv[foot] + z_ret[foot];
        control_state_msg_->z_advance[foot] = z_adv[foot];
        control_state_msg_->z_retard[foot] = z_ret[foot];
    }

    // calling inverse kinematics
    doInverseKinematic(z_adv[RIGHT],z_ret[RIGHT],z_adv[LEFT],z_ret[LEFT],ik_out);

    // Make it compliant with the robot
    outp[0] = ik_out[0];
    outp[1] = -ik_out[1];
    outp[2] = -ik_out[2];
    outp[3] = -ik_out[3];
    outp[4] = -ik_out[5];
    outp[5] = -ik_out[4];

    outp[6] = -ik_out[6];
    outp[7] = ik_out[7];
    outp[8] = -ik_out[8];
    outp[9] = -ik_out[9];
    outp[10] = -ik_out[11];
    outp[11] = ik_out[10];

    for (int i = 0; i < NO_MOTORS; i++)
    {
        outp_incounts[i] = (outp[i] * INCREMENTAL_ENCODER_CPR * GEARHEAD_RATIO) / (2. * PI_NUMBER);
    }

    return outp_incounts;
}

int* ControllerA::rawMotion()
{
    double outp[NO_MOTORS] = {0};
    int* outp_incounts = new int[NO_MOTORS];
    double ik_out[12];
    memset(&ik_out[0],0,sizeof(ik_out));

    doInverseKinematic(0,0,0,0,ik_out);
    // Make it compliant with the robot
    outp[0] = ik_out[0];
    outp[1] = -ik_out[1];
    outp[2] = -ik_out[2];
    outp[3] = -ik_out[3];
    outp[4] = -ik_out[5];
    outp[5] = -ik_out[4];

    outp[6]  = -ik_out[6];
    outp[7]  = ik_out[7];
    outp[8]  = -ik_out[8];
    outp[9]  = -ik_out[9];
    outp[10] = -ik_out[11];
    outp[11] = ik_out[10];

    for (int i = 0; i < NO_MOTORS; i++)
    {
        outp_incounts[i] = (outp[i] * INCREMENTAL_ENCODER_CPR * GEARHEAD_RATIO) / (2. * PI_NUMBER);
    }
    return outp_incounts;
}

void ControllerA::doInverseKinematic(double z1_adv,double z1_ret,double z2_adv,double z2_ret,double outp[12])
{
    double ik_in[18];
    double hip_output[8];
    ik_in[0] = preplanned_.cur_seq_info.x_pelvis_preplanned;
    ik_in[1] = preplanned_.cur_seq_info.y_pelvis_preplanned;
    ik_in[2] = preplanned_.cur_seq_info.z_pelvis_preplanned+z1_ret+z2_ret;

    ik_in[3] = preplanned_.cur_seq_info.alpha_pelvis_preplanned;
    ik_in[4] = preplanned_.cur_seq_info.beta_pelvis_preplanned;
    ik_in[5] = preplanned_.cur_seq_info.gamma_pelvis_preplanned;

    ik_in[6] = preplanned_.cur_seq_info.x_preplanned[RIGHT];
    ik_in[7] = preplanned_.cur_seq_info.y_preplanned[RIGHT];
    ik_in[8] = preplanned_.cur_seq_info.z_preplanned_w_correction[RIGHT] + z1_adv + z1_ret + 0.113 + 0.05097;

    ik_in[9] = preplanned_.cur_seq_info.x_preplanned[LEFT];
    ik_in[10] = preplanned_.cur_seq_info.y_preplanned[LEFT];
    ik_in[11] = preplanned_.cur_seq_info.z_preplanned_w_correction[LEFT] + z2_adv + z2_ret + 0.113 + 0.05097;

    ik_in[12] = preplanned_.cur_seq_info.alpha_preplanned[RIGHT];
    ik_in[13] = preplanned_.cur_seq_info.beta_preplanned[RIGHT];
    ik_in[14] = preplanned_.cur_seq_info.gamma_preplanned[RIGHT];

    ik_in[15] = preplanned_.cur_seq_info.alpha_preplanned[LEFT];
    ik_in[16] = preplanned_.cur_seq_info.beta_preplanned[LEFT];
    ik_in[17] = preplanned_.cur_seq_info.gamma_preplanned[LEFT];

    ik(ik_in,outp);

    Hip_Joints_IK(&outp[0],&hip_output[0],1);
    Hip_Joints_IK(&outp[6],&hip_output[4],2);

    for(int i=0;i<3;i++)
    {
        outp[i]=hip_output[i];
        outp[i+6]=hip_output[i+4];
    }

}

void ControllerA::footAdaptationControl(uint8_t right_left, int16_t* roll_c, int16_t* pitch_c)
{
    int8_t fr_state;//front right
    int8_t fl_state;
    int8_t rr_state;
    int8_t rl_state;//rear left
    int16_t diff;

    int16_t * inp;
    if (right_left == RIGHT)
        inp = sensors_ptr_->foot_sensors[RIGHT].rangeSensors;
    else
        inp = sensors_ptr_->foot_sensors[LEFT].rangeSensors;;
    // put zero to outputs
    *roll_c = 0;
    *pitch_c = 0;

    // finding state front right
    diff = Z_Off_The_Ground - inp[INDX_FR];
    if (diff > CONTACT_THR)
        fr_state = 1;
    else
        fr_state = 0;

    // finding state front left
    diff = Z_Off_The_Ground - inp[INDX_FL];
    if (diff > CONTACT_THR)
        fl_state = 1;
    else
        fl_state = 0;

    // finding state rear right
    diff = Z_Off_The_Ground - inp[INDX_RR];
    if (diff > CONTACT_THR)
        rr_state = 1;
    else
        rr_state = 0;

    // finding state rear left
    diff = Z_Off_The_Ground - inp[INDX_RL];
    if (diff > CONTACT_THR)
        rl_state = 1;
    else
        rl_state = 0;

    no_touched_range_sensors_[right_left] = fr_state + fl_state + rr_state + rl_state;

    switch (no_touched_range_sensors_[right_left])
    {
        case 1: //contact in one sensor trying to contact the other sensor reach to next cases
            if (fr_state == 1)
            {
                *roll_c = -Roll_Step;
                *pitch_c = -Pitch_Step;
            }
            else if (fl_state == 1)
            {
                *roll_c = Roll_Step;
                *pitch_c = -Pitch_Step;
            }
            else if (rr_state == 1)
            {
                *roll_c = -Roll_Step;
                *pitch_c = Pitch_Step;
            }
            else if (rl_state == 1)
            {
                *roll_c = Roll_Step;
                *pitch_c = Pitch_Step;
            }
            break;

        case 2: //contact in two sensor, first trying to make contactes sensor value equal and secondly trying to reach case 3 and case 4
            if ((fr_state == 1) && (fl_state == 1))
            {
                *roll_c = K_Roll_Gain * (inp[INDX_FR] - inp[INDX_FL]);
                *pitch_c = -Pitch_Step;
            }
            else if ((rr_state == 1) && (rl_state == 1))
            {
                *roll_c = K_Roll_Gain * (inp[INDX_RR] - inp[INDX_RL]);
                *pitch_c = Pitch_Step;
            }
            else if ((fr_state == 1) && (rr_state == 1))
            {
                if (right_left == RIGHT)
                    *roll_c = -Roll_Step;
                else
                    *roll_c = Roll_Step;
                *pitch_c = K_Pitch_Gain * (inp[INDX_FR] - inp[INDX_RR]);
            }
            else if ((fl_state == 1) && (rl_state == 1))
            {
                *roll_c = Roll_Step;
                *pitch_c = K_Pitch_Gain * (inp[INDX_FL] - inp[INDX_RL]);
            }
            else  // invalid position for two contacts just return zero
            {
                *roll_c = 0;
                *pitch_c = 0;
                //optional: sending warning message
            }
            break;

        case 3:
            if (rl_state == 0)  //should be verified by Ahmadreza
            {
                *roll_c = K_Roll_Gain * (inp[INDX_FR] - inp[INDX_FL]);
                *pitch_c = K_Pitch_Gain * (inp[INDX_FR] - inp[INDX_RR]);
            }
            else if (rr_state == 0)
            {
                *roll_c = K_Roll_Gain * (inp[INDX_FR] - inp[INDX_FL]);
                *pitch_c = K_Pitch_Gain * (inp[INDX_FL] - inp[INDX_RL]);
            }
            else if (fr_state == 0)
            {
                *roll_c = K_Roll_Gain * (inp[INDX_RR] - inp[INDX_RL]);
                *pitch_c = K_Pitch_Gain * (inp[INDX_FL] - inp[INDX_RL]);
            }
            else if (fr_state == 0)
            {
                *roll_c = K_Roll_Gain * (inp[INDX_RR] - inp[INDX_RL]);
                *pitch_c = K_Pitch_Gain * (inp[INDX_FR] - inp[INDX_RR]);
            }
            break;

        case 4:
            *roll_c = K_Roll_Gain * 0.5 * (inp[INDX_FR] + inp[INDX_RR] - inp[INDX_FL] - inp[INDX_RL]);
            *pitch_c = K_Pitch_Gain * (inp[INDX_FL] + inp[INDX_FR] - inp[INDX_RL] - inp[INDX_RR]);
            break;
        default:
            break;
    }
}

void ControllerA::zmpControl(uint8_t right_left, int16_t* roll, int16_t* pitch)
{
    ZMPPhaseType zmp_phase = calculateZMP();

    Point2DType d_zmp;

    bool con_sw[2] = {false};
    con_sw[RIGHT] = (sensors_ptr_->foot_sensors[RIGHT].forceTorqueSensor.fz > FT_SENSOR_LANDED_THRESHOLD);


    d_zmp.x = abs(zmp_.x) - ZMP_REGION_L * (FOOTPLATE_L/2);
    d_zmp.y = abs(zmp_.y) - ZMP_REGION_W * (FOOTPLATE_W/2);

    if (d_zmp.x < 0)
        d_zmp.x = 0;
    if (d_zmp.y < 0)
        d_zmp.y = 0;

    if (zmp_.x > 0)
        d_zmp.x = -d_zmp.x;
    if (zmp_.y < 0)
        d_zmp.y = -d_zmp.y;

    //if ()

}

double ControllerA::integral(double x, double f)
{
    return (x + f * preplanned_.params.time_step);
}

// returns a flag
ZMPPhaseType ControllerA::calculateZMP()
{
    ZMPPhaseType phase = ZMP_PHASE_TRS;
    ForceTorqueSensor ft[2] = {0};
    Point2DType zmp_all[2] = {0};
    ft[RIGHT] = sensors_ptr_->foot_sensors[RIGHT].forceTorqueSensor;
    ft[LEFT] = sensors_ptr_->foot_sensors[LEFT].forceTorqueSensor;

    zmp_.x = 0;
    zmp_.y = 0;

    for (int foot = 0; foot < 2; ++foot)
    {
        ft[foot] = sensors_ptr_->foot_sensors[foot].forceTorqueSensor;

        if (ft[foot].fz > FT_SENSOR_LANDED_THRESHOLD)
        {
            zmp_all[foot].x = (ft[foot].fz * FT_SENSOR_X_LOC - ft[foot].fx * FT_SENSOR_Z_LOC - ft[foot].ty) / ft[foot].fz;
            zmp_all[foot].y = (ft[foot].fz * FT_SENSOR_Y_LOC - ft[foot].fy * FT_SENSOR_Z_LOC + ft[foot].tx) / ft[foot].fz;
        }
    }

    for (int foot = 0; foot < 2; ++foot)
    {
        if (ft[foot].fz > FT_SENSOR_LANDED_THRESHOLD && ft[foot^1].fz < FT_SENSOR_LIFTED_THRESHOLD) // SSP for [foot]
        {
            zmp_.x = zmp_all[foot].x;
            zmp_.y = zmp_all[foot].y;
            if (foot == RIGHT)
                phase = ZMP_PHASE_SS_RIGHT;
            else
                phase = ZMP_PHASE_SS_LEFT;
        }
    }
    if (ft[RIGHT].fz > FT_SENSOR_LANDED_THRESHOLD && ft[LEFT].fz > FT_SENSOR_LANDED_THRESHOLD) // DSP
    {
        zmp_.x = (zmp_all[RIGHT].x * ft[RIGHT].fz + zmp_all[LEFT].x * ft[LEFT].fz ) / (ft[RIGHT].fz + ft[LEFT].fz);
        zmp_.y = (zmp_all[RIGHT].y * ft[RIGHT].fz + zmp_all[LEFT].y * ft[LEFT].fz ) / (ft[RIGHT].fz + ft[LEFT].fz);
        phase = ZMP_PHASE_DS;
    }
    return phase;
}

double ControllerA::det33(double inp1,double inp2,double inp3,double inp4,double inp5,double inp6,double inp7,double inp8,double inp9)
{
    double outp=0;
    outp=inp1*((inp5*inp9)-(inp6*inp8));
    outp-=inp2*((inp4*inp9)-(inp6*inp7));
    outp+=inp3*((inp4*inp8)-(inp5*inp7));
    return outp;
}

}
