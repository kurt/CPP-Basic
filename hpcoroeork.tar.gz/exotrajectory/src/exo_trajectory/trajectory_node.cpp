#include <ros/ros.h>
#include <exo_trajectory/trajectory.h>

/**
    Starting point where the application (node) starts, instantiating exotrajectory object that registers services, nodes, publishers and advertisers.

    @param int args
    @param char** argv
    @return success
*/
int main(int argc, char** argv)
{
    ros::init(argc, argv, "trajectory_generator_node");

    exo_trajectory::TrajectoryGenerator trajectoryGenerator(ros::NodeHandle(), ros::NodeHandle("~"));
    ROS_INFO("Before spin()");
    ros::spin();
    ROS_INFO("After spin()");
    return 0;
}
