#include <exo_trajectory/preplanned_info.h>

namespace exo_trajectory {

PreplannedInformation::PreplannedInformation()
{
    cur_seq_ = 0;
    sequences_info_.clear();
    params = {};
    ROS_INFO("PreplanendInfo Constructor!");
}

PreplannedInformation::~PreplannedInformation()
{

}

void PreplannedInformation::step()
{
//    ROS_INFO("PreplannedInfo Step!");
    prev_seq_info = sequences_info_.at(cur_seq_);
    cur_seq_++;
    if (cur_seq_ == sequences_info_.size() - 1)
    {
        ROS_INFO("Motion is finished");
        exit(0);
    }
//    ROS_INFO("seq: %d", cur_seq_);
//    ROS_INFO("step:PELVIS:%f", sequences_info_.at(cur_seq_).x_pelvis_preplanned);
    cur_seq_info = sequences_info_.at(cur_seq_);
}

int PreplannedInformation::loadPreplannedMotionFile()
{
    FILE *ptr;
    uint32_t file_header, file_footer;
    // reading fixed point  input arrays
    uint32_t temp;
    ptr = fopen("/tmp/mp.bin","rb");
    if(ptr == NULL)
    {
        ROS_ERROR("Couldn't able to open /tmp/mp.bin  \n");
        exit(1);
    }
    fread(&file_header,1,sizeof(uint32_t), ptr);
    if (file_header == 0x12345678)
    {
        fread(&params.motion_len,1,sizeof(uint32_t), ptr);
        fread(&params.feet_state_change_len[0],1,sizeof(uint32_t), ptr);
        fread(&params.feet_state_change_len[1],1,sizeof(uint32_t), ptr);
        fread(&params.n_release,1,sizeof(uint32_t), ptr);
        fread(&params.release_inv_matrix,36,sizeof(double), ptr);
        fread(&params.time_step,1,sizeof(double), ptr);
        fread(&params.delta_z,1,sizeof(double), ptr);
        ROS_INFO("delta_z: %f", params.delta_z);
        fread(&params.Sensor_Thr,1,sizeof(double), ptr);
        fread(&params.delta_t_safety_factor,1,sizeof(double), ptr);

        for(int i = 0; i < params.motion_len;i++)
        {
            SequenceInfoType info;
            fread(&info,1,sizeof(SequenceInfoType), ptr);
            //printf("loadFile:info_to_push_back:%f, vector_size:%d\n", info.x_pelvis_preplanned, (int)sequences_info_.size());
            sequences_info_.push_back(info);
        }

        // Adaptation vector initialization
        for (int i = 0; i < params.motion_len; ++i)
        {
            for (uint8_t foot = 0; foot < 2; ++foot)
                if (sequences_info_[i].advance_check_enable[foot])
                    adaptation_enable[foot].push_back(true);
                else if (sequences_info_[i].retard_check_enable[foot])
                {
                    adaptation_enable[foot].push_back(true);
                    if (i < params.motion_len - 1 && sequences_info_[i+1].retard_check_enable[foot] == 0)
                    {
                        for (int d = 0; d < 40; ++d)
                            adaptation_enable[foot].pop_back();
                        for (int d = 0; d < 40; ++d)
                            adaptation_enable[foot].push_back(false);
                    }
                }
                else
                    adaptation_enable[foot].push_back(false);
        }
        ROS_INFO("seq_info_size: %d, adaptation_size: %d", (int)sequences_info_.size(), (int)adaptation_enable[RIGHT].size());

        for(uint8_t foot = 0; foot < 2; ++foot)
        {
            for(int i = 0; i < params.feet_state_change_len[foot];i++)
            {
                FootStateChangesType foot_state;
                fread(&foot_state,1,sizeof(FootStateChangesType), ptr);
                footplates_state_changes[foot].push_back(foot_state);
            }
        }

        fread(&file_footer,1,sizeof(uint32_t), ptr);
        fclose(ptr);
        //reducing edge values because of zero start index in C
        for(uint8_t foot = 0; foot < 2; ++foot)
            for(int i = 0; i < params.feet_state_change_len[foot]; ++i)
            {
                footplates_state_changes[foot][i].sensor_triggered_seqs--;
                footplates_state_changes[foot][i].foot_state_changed_seqs--;
            }

        if(file_footer == 0x87654321)
        {
            cur_seq_info = sequences_info_.at(cur_seq_);
            prev_seq_info = sequences_info_.at(cur_seq_);
            ROS_INFO("Motion data is read successfully from files");
            return 0;
        }
        else
        {
            ROS_INFO("%X", file_footer);
            ROS_ERROR("The footer in binary file is wrong");
            exit(2);
        }
    }
    else
    {
        ROS_ERROR("The header in binary file is wrong");
        fclose(ptr);
        exit(2);
    }
}

}
