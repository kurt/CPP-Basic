/*
 * Copyright 2016-2019 CNRS-UM LIRMM, CNRS-AIST JRL
 */

#include "ContactForcePublisher.h"

#include <mc_control/mc_global_controller.h>
#include <mc_rtc/config.h>
#include <mc_rtc/logging.h>
#include <mc_rtc/ros.h>
#include <std_msgs/String.h>

#include <ros/ros.h>

#include <chrono>
#include <iostream>
#include <mc_rbdyn/rpy_utils.h>
#include <exo_msgs/ForceTorqueSensors.h>
#include <exo_msgs/ForceTorqueSensor.h>
#include <exo_msgs/JointPos.h>
#include <exo_msgs/MotorCommand.h>
#include <exo_msgs/IMUSensor.h>
#include <exo_msgs/JointsState.h>
#include <exo_msgs/JointsState.h>
#include <exo_interface/common/data_conversion.h>

namespace
{
template<typename T>
T getParam(ros::NodeHandle & n, const std::string & param)
{
  T out;
  std::string true_param;
  n.searchParam(param, true_param);
  n.getParam(true_param, out);
  return out;
}

template<typename T>
T getParam(ros::NodeHandle & n, const std::string & param, const T & def)
{
  if(n.hasParam(param))
  {
    return getParam<T>(n, param);
  }
  return def;
}
} // namespace


std::map<std::string, sva::ForceVecd> m_wrenches;
std::vector<double> qEnc;
Eigen::Vector3d rpyIMU;
Eigen::Vector3d accIMU;
Eigen::Vector3d rateIMU;
std::vector<double> qOut;

//Define Callbacks

void OrientationCallback(const exo_msgs::IMUSensor::ConstPtr& OrientationData)
{


  double rpy[3];
  double ypr[3];

  ypr[0] = OrientationData->yaw;
  ypr[1] = OrientationData->pitch;
  ypr[2] = OrientationData->roll;

  exo_interface::YPR_to_RPY(rpy, ypr);

  for (int i = 0; i < 3; ++i)
  {
    rpyIMU(i) = rpy[i];
  }

}

void FootGRFCallback(const exo_msgs::ForceTorqueSensors::ConstPtr& FTData)
{

  m_wrenches["LeftFootForceSensor"].force() = Eigen::Vector3d(FTData->left.fx, FTData->left.fy, FTData->left.fz);
  m_wrenches["LeftFootForceSensor"].couple() = Eigen::Vector3d(FTData->left.tx, FTData->left.ty, FTData->left.tz);


  m_wrenches["RightFootForceSensor"].force() = Eigen::Vector3d(FTData->right.fx, FTData->right.fy, FTData->right.fz);
  m_wrenches["RightFootForceSensor"].couple() = Eigen::Vector3d(FTData->right.tx, FTData->right.ty, FTData->right.tz);

}

void EncoderCallback(const exo_msgs::JointsState::ConstPtr& EncoderData)
{

  double encoder_data[12];
  for (int i = 0; i < 12; ++i)
  {
    encoder_data[i] = EncoderData->states[i].position_incounts;
  }  
  qEnc = exo_interface::b11_angles_to_sim_angles(encoder_data);
}

int main()
{
  auto nh_p = mc_rtc::ROSBridge::get_node_handle();
  if(!nh_p)
  {
    return 1;
  }
  auto nh = *nh_p;

  std::string conf = "";
  if(nh.hasParam("mc_rtc_ticker/conf"))
  {
    conf = getParam<std::string>(nh, "mc_rtc_ticker/conf");
    LOG_INFO("Configuring mc_rtc with " << conf)
  }

  mc_control::MCGlobalController controller(conf);
  double dt = controller.timestep();
  LOG_INFO("time stamp is : " << dt);
  std::vector<double> q;
  if(nh.hasParam("mc_rtc_ticker/init_state"))
  {
    q = getParam<std::vector<double>>(nh, "mc_rtc_ticker/init_state");
  }
  else
  {
    auto & mbc = controller.robot().mbc();
    const auto & rjo = controller.ref_joint_order();
    for(const auto & jn : rjo)
    {
      if(controller.robot().hasJoint(jn))
      {
        for(auto & qj : mbc.q[controller.robot().jointIndexByName(jn)])
        {
          q.push_back(qj);
        }
      }
      else
      {
        // FIXME This assumes that a joint that is in ref_joint_order but missing from the robot is of size 1 (very
        // likely to be true)
        q.push_back(0);
      }
    }
  }
  controller.setEncoderValues(q);
  if(nh.hasParam("mc_rtc_ticker/init_pos"))
  {
    LOG_INFO("Using initial pos from ROS param")
    std::vector<double> pos = getParam<std::vector<double>>(nh, "mc_rtc_ticker/init_pos");
    for(const auto & pi : pos)
    {
      std::cout << pi << " ";
    }
    std::cout << std::endl;
    std::array<double, 7> p;
    std::copy_n(pos.begin(), 7, p.begin());
    controller.init(q, p);
  }
  else
  {
    controller.init(q);
  }
  controller.running = true;

  const bool bench = getParam(nh, "mc_rtc_ticker/bench", false);
  std::chrono::time_point<std::chrono::system_clock> begin, end;
  std::vector<std::chrono::duration<double>> solve_dt(0);
  if(bench)
  {
    /* Reserve a million entry */
    solve_dt.reserve(1000000);
  }
  auto report_dt = [&solve_dt](bool partial) {
    std::cout << "Ran for " << solve_dt.size() << " iterations: ";
    size_t start_i = partial ? solve_dt.size() - 1000 : 0;
    auto min_t = solve_dt[start_i];
    auto max_t = solve_dt[start_i];
    auto second_max_t = solve_dt[start_i];
    std::chrono::duration<double> average_t(0);
    for(size_t i = start_i; i < solve_dt.size(); ++i)
    {
      const auto & t = solve_dt[i];
      if(t > max_t)
      {
        second_max_t = max_t;
        max_t = t;
      }
      if(t < min_t)
      {
        min_t = t;
      }
      average_t += t;
    }
    if(partial)
    {
      average_t = average_t / 1000;
    }
    else
    {
      average_t = average_t / solve_dt.size();
    }
    std::cout << " avg: " << average_t.count() * 1000 << "ms, min: " << min_t.count() * 1000
              << "ms, max: " << max_t.count() * 1000 << "ms, second max: " << second_max_t.count() * 1000 << std::endl;
  };

  const bool publish_contact_forces = getParam(nh, "mc_rtc_ticker/publish_contact_forces", true);
  std::unique_ptr<mc_rtc_ros::ContactForcePublisher> cfp_ptr = nullptr;
  if(publish_contact_forces)
  {
    cfp_ptr.reset(new mc_rtc_ros::ContactForcePublisher(nh, controller));
  }

  //Testing out adding publications... nh
  ros::Publisher command_pub = nh.advertise<exo_msgs::MotorCommand>("/robot/command", 1000);
  ros::Subscriber wrench_sub = nh.subscribe<exo_msgs::ForceTorqueSensors>("/robot/sensors/foot/force", 1000, FootGRFCallback);
  ros::Subscriber encoder_sub = nh.subscribe<exo_msgs::JointsState>("/robot/joints/state", 1000, EncoderCallback);
  ros::Subscriber orientation_sub = nh.subscribe<exo_msgs::IMUSensor>("/robot/sensors/backpack/imu", 1000, OrientationCallback);
  //Initialize Variables
  m_wrenches["LeftFootForceSensor"].force() = Eigen::Vector3d(0, 0, 0);
  m_wrenches["LeftFootForceSensor"].couple() = Eigen::Vector3d(0, 0, 0);

  m_wrenches["RightFootForceSensor"].force() = Eigen::Vector3d(0, 0, 0);
  m_wrenches["RightFootForceSensor"].couple() = Eigen::Vector3d(0, 0, 0);

  qEnc.resize(12);
  qOut.resize(12);

  for(int i = 0; i < 12; i++)
  {
    qEnc[i] = 0.0;
    qOut[i] = 0.0;
  } 

  rpyIMU(0) = 0.0;
  rpyIMU(1) = 0.0/180.0*3.14159;
  rpyIMU(2) = 0.0;

  accIMU(0) = 0.0;
  accIMU(1) = 0.0;
  accIMU(2) = 0.0;

  rateIMU(0) = 0.0;
  rateIMU(1) = 0.0;
  rateIMU(2) = 0.0;

  ros::Rate rt(1 / dt);
  std::thread spin_th;
  if(bench)
  {
    spin_th = std::thread([&rt]() {
      while(ros::ok())
      {
        ros::spinOnce();
        rt.sleep();
      }
    });
  }
  while(ros::ok())
  {
    //Test publications in loop
    //std_msgs::String msg_test;
    //msg_test.data = controller.robot().name();
    //test_pub.publish(msg_test);
    

    if(bench)
    {
      begin = std::chrono::system_clock::now();
    }
    auto & mbc = controller.robot().mbc();
    const auto & rjo = controller.ref_joint_order();
    size_t index = 0;
    for(size_t i = 0; i < rjo.size(); ++i)
    {
      const auto & jn = rjo[i];
      if(controller.robot().hasJoint(jn))
      {
        for(auto & qj : mbc.q[controller.robot().jointIndexByName(jn)])
        {
          q[index] = qj;
          index++;
        }
      }
    }
    controller.setSensorOrientation( Eigen::Quaterniond(mc_rbdyn::rpyToMat(rpyIMU)).normalized() );
    controller.setEncoderValues(qEnc);
    controller.setWrenches(m_wrenches);
    if(controller.run())
    {
      //LOG_SUCCESS("Executing Here");
      //controlRobot().mbc().q[1][0];
      std::map<std::string, std::vector<double>> gAQs; // will store only the active joints values
      std::map<std::string, std::vector<double>> gQs = controller.gripperQ();
      //LOG_SUCCESS("Executing Here");
      int position_array[12];
      double command_position[12];
      for(int i = 0; i <= 11; i++)
      { 
        //LOG_SUCCESS("Executing Here");
        qOut[i] = controller.robot().mbc().q[i+1][0];
        //LOG_SUCCESS("Executing Here");
        command_position[i] = qOut[i];
      }
      //LOG_SUCCESS("Executing Here");
      LOG_INFO("command position_array : " << command_position);
      boost::array<int,12ul> motor_position = exo_interface::sim_angles_to_b11_angles(command_position);
      //LOG_SUCCESS("Executing Here");
      int dis_max_ = 1000000;
      //Check for displacement violation
      for(int i = 0; i<12; i++)
      {

        if (  ((motor_position[i] - exo_interface::radiant_to_incounts(qEnc[i])) >= dis_max_) || (-(motor_position[i] - exo_interface::radiant_to_incounts(qEnc[i])) >= dis_max_)  )
        {

          
          while(1)
          {
            printf("Command Violated Displacement Constraint. Freezing Process...\n");
          }

        }

      }


      ros::Time now = ros::Time::now();
      //LOG_SUCCESS("Executing Here");
      exo_msgs::MotorCommand::Ptr jointPosition = boost::make_shared<exo_msgs::MotorCommand>();
      jointPosition->header.stamp = now;
      jointPosition->positions = motor_position;
      jointPosition->hypo_positions = motor_position;

      command_pub.publish(jointPosition);
	
      for(const auto & g : controller.gripperActiveJoints())
      {
        const auto & gn = g.first;
        const auto & gAJs = g.second;
        auto gJs = controller.gripperJoints()[gn];
        const auto & gQ = gQs[gn];
        gAQs[gn] = {};
        for(const auto & gAJ : gAJs)
        {
          for(size_t i = 0; i < gJs.size(); ++i)
          {
            if(gJs[i] == gAJ)
            {
              gAQs[gn].push_back(gQ[i]);
              break;
            }
          }
        }
      }
      controller.setActualGripperQ(gAQs);
      if(cfp_ptr)
      {
        cfp_ptr->update();
      }
    }
    if(bench)
    {
      end = std::chrono::system_clock::now();
      solve_dt.push_back(end - begin);
      if(solve_dt.size() % 1000 == 0)
      {
        report_dt(true);
      }
    }
    else
    {
      ros::spinOnce();
      rt.sleep();
    }
  }

  if(bench)
  {
    report_dt(false);
    spin_th.join();
  }
  if(cfp_ptr)
  {
    cfp_ptr->stop();
  }

  return 0;
}

